# RilzMusic

Dengarkan. Unduh. Nikmati.

Aplikasi musik Flutter (Android). Sumber musik: Jamendo API v3.0 (`https://api.jamendo.com/v3.0/tracks/`).

## Fitur

- **Login**: Google Sign-In + mode tamu. Sesi dipulihkan saat aplikasi dibuka ulang. Keluar dari akun atau mode tamu tersedia di Pengaturan.
- **Beranda**: rekomendasi (berdasarkan artis di riwayat, atau daftar populer bila belum ada riwayat) dan daftar populer dengan paginasi.
- **Cari**: pencarian judul dan artis, dijalankan saat menekan enter, dengan paginasi.
- **Pemutar**: play/pause, seek bar, durasi saat ini dan total, mini player di semua tab, full player dengan artwork, antrean (hapus, lompat, next/previous), status buffering, dan error dengan tombol coba lagi.
- **Perpustakaan**: favorit, riwayat pemutaran (bisa dihapus), unduhan offline, dan playlist.
- **Playlist**: buat, ganti nama, dan hapus. Track disimpan lengkap di dalam playlist, sehingga tetap bisa diputar setelah aplikasi ditutup.
- **Unduhan offline**: hanya untuk track yang field `audiodownload_allowed` bernilai `true` dari API. Progres, pembatalan, dan error ruang penyimpanan penuh ditangani. Lagu yang diunduh diputar dari file lokal, termasuk saat offline.

Catatan batasan: field `audio` dari API dipakai sebagai sumber stream. Respons API yang dipakai di sini tidak memuat penanda "preview", jadi aplikasi tidak menampilkan label preview. Bila Jamendo mengembalikan URL kosong, lagu ditandai tidak bisa diputar.

## Konfigurasi (wajib sebelum menjalankan)

Tidak ada secret di source code. Semua kredensial diisi lewat `--dart-define`.

| Variabel | Fungsi | Wajib untuk |
|---|---|---|
| `JAMENDO_CLIENT_ID` | Client ID dari devportal.jamendo.com | Pencarian, popular, rekomendasi, pemutaran dari API |
| `GOOGLE_WEB_CLIENT_ID` | Web OAuth Client ID untuk Google Sign-In | Login Google (mode tamu tetap jalan tanpa ini) |

Tanpa `JAMENDO_CLIENT_ID`, layar Beranda dan Cari menampilkan pesan yang menjelaskan cara mengatur Client ID. Pemutaran dari unduhan offline tetap berfungsi.

### Google Sign-In

1. Buka Google Cloud Console, buat project, dan atur **OAuth consent screen**.
2. **Android**: buat OAuth Client ID tipe *Android*.
   - Package name: `com.example.helloworld` (`applicationId` di `android/app/build.gradle.kts`). Ganti dulu jika ingin ID sendiri, lalu sesuaikan Client ID ini.
   - SHA-1: jalankan `cd android && ./gradlew signingReport`, lalu salin SHA-1 varian debug (dan release bila sudah punya keystore).
3. **Web Client ID**: buat OAuth Client ID tipe *Web application*. Nilai ini dipakai sebagai `GOOGLE_WEB_CLIENT_ID`.
4. **iOS** (belum dikonfigurasi): buat OAuth Client ID tipe *iOS*, lalu tambahkan `GIDClientID` dan URL scheme (reversed client ID) ke `ios/Runner/Info.plist`.
5. **Web**: belum didukung untuk build ini (lihat catatan di bawah).

Jika login gagal dengan `ApiException 10`, SHA-1 atau package name belum cocok dengan Client ID Android.

## Menjalankan

```bash
flutter pub get
flutter run --dart-define=JAMENDO_CLIENT_ID=XXXX --dart-define=GOOGLE_WEB_CLIENT_ID=XXXX.apps.googleusercontent.com
```

## Validasi dan build

Urutan validasi yang dipakai oleh bot Telegram:

```bash
flutter pub get
dart format --set-exit-if-changed lib test
flutter analyze
flutter test
flutter build apk --release --dart-define=JAMENDO_CLIENT_ID=CLIENT_ID --dart-define=GOOGLE_WEB_CLIENT_ID=WEB_CLIENT_ID
```

Output: `build/app/outputs/flutter-apk/app-release.apk`.

Catatan: release masih memakai signing debug (`android/app/build.gradle.kts`). Buat keystore sendiri sebelum distribusi.

## Struktur

```
lib/
  main.dart                       # composition root: AppServices dibuat sekali di sini
  app.dart                        # MaterialApp + gerbang login/shell
  core/
    app_scope.dart                # InheritedWidget untuk AppServices
    config/app_config.dart        # JAMENDO_CLIENT_ID dari --dart-define
    constants/, theme/            # konstanta dan tema gelap neon mint
  data/
    models/                       # Track, Playlist, DownloadedTrack
    repositories/                 # MusicRepository, LibraryRepository, DownloadRepository
  services/
    api/                          # JamendoApiClient (timeout, retry), parser respons, exception
    audio/                        # AudioEngine (just_audio), PlaybackQueue, PlayerController
    download/                     # DownloadService (stream + progres), DownloadManager
    storage/                      # KeyValueStore (SharedPreferences / memori untuk tes)
    auth/                         # AuthService (Google Sign-In + tamu)
    app_services.dart             # perakitan dependensi
  features/
    authentication/ home/ search/ player/ library/ downloads/ playlist/ settings/ shell/
  shared/widgets/                 # artwork, track tile, paged list, menu aksi, state views
test/
  support/fake_audio_engine.dart  # engine palsu, tanpa platform
  *_test.dart                     # model, parser, klien API (MockClient), repository, antrean, player, unduhan
```

## Catatan platform

- Web: kode unduhan memakai `dart:io`, jadi target web belum didukung. Build Android adalah target yang dimaksud.
- iOS: folder ada, tetapi belum dikonfigurasi (OAuth dan build belum diverifikasi).

## Ikon aplikasi

Sumber: `assets/icon/icon.png`. Ikon Android (`mipmap-*`), iOS (`AppIcon.appiconset`), dan web sudah dibuat dari sumber ini. Untuk mengganti logo, timpa `assets/icon/icon.png` lalu buat ulang ukuran-ukurannya.
