# Flutter Create

Create, edit, preview, and build Flutter applications directly from Android.

Flutter Create adalah mini IDE Flutter untuk Android: buat/buka project, edit
source Dart dengan syntax highlighting, tekan **RUN**, dan lihat hasil UI
Flutter di Preview.

## Struktur

```
lib/
├── main.dart
├── models/        # ProjectModel, FileModel, ConsoleMessage, BuildJob
├── services/       # storage, project, analyzer, compiler, runtime, preview,
│                     build, build-server (remote), settings, inspector
├── screens/        # Home, Projects, Explorer, Editor, Preview, Build, Settings
├── widgets/        # FileTree, EditorToolbar, ConsolePanel, PreviewPanel, dll
├── theme/          # Material 3 dark IDE theme
└── state/          # AppState (project & file aktif lintas tab)
```

## Penting: Build Server

Android tidak bisa menjalankan Flutter SDK + Gradle di dalam sebuah app biasa.
Karena itu tombol **RUN**, **PREVIEW**, dan **BUILD APK** memerlukan sebuah
*Build Server* eksternal (URL diatur di Settings > Build) yang mengekspos API:

```
POST /api/project/upload
POST /api/project/preview
POST /api/project/preview/{id}/reload
POST /api/project/build
GET  /api/project/build/{id}
GET  /api/project/download/{id}
POST /api/project/analyze     (opsional, remote dart analyze)
```

Tanpa Build Server dikonfigurasi, aplikasi akan **jujur** menampilkan status
"Flutter runtime belum tersedia" — bukan preview/berhasil palsu.

## Menjalankan

```bash
flutter pub get
flutter run
```

## Catatan status implementasi

- Analisis lokal (bracket matching, struktur dasar) — nyata, jalan offline.
- Analisis semantik penuh, compile, preview, dan build APK — didelegasikan ke
  Build Server (belum disertakan; lihat `lib/services/build_server_service.dart`).
- Visual Inspector — outline widget berbasis parsing teks source (read-only,
  bukan live inspector visual).

## Google Sign-In setup

Flutter Create now includes a Google login screen using `google_sign_in`.
Before production use, configure an Android OAuth 2.0 client for package
`com.fluttercreate.app` and the SHA-1/SHA-256 fingerprints of the signing key.
Do not commit client secrets or private keys to this repository.

The login UI and auth service are ready, but Google Console/Firebase project
configuration is external and must be supplied by the app owner.

## Assets

- `assets/icons/flutter_create_logo.png` — in-app/app logo
- `assets/icons/google_g.png` — Google login icon
- `assets/videos/flutter_create_intro.mp4` — local intro video used by VideoScreen

## SaaS UI v3

The app now uses a more complete SaaS-style workspace experience:
- Dashboard metrics for projects, builds, previews and storage.
- Workspace activity and resource usage panels.
- Analytics screen with build activity and runtime health.
- Team workspace screen with member roles and invite flow UI.
- Billing & Plans screen with Free, Pro and Team plan presentation.
- Workspace drawer with product/workspace navigation.
- Reusable SaaS cards, metric cards, progress rows, activity tiles and status pills.
- Existing Dart editor, preview, build and project flows remain part of the base.

The extra UI is intentionally functional and componentized rather than adding empty/comment-only lines just to inflate the code count.
