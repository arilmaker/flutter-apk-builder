package com.fluttercreate.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
