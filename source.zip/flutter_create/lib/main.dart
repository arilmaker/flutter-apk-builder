import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'services/auth_service.dart';
import 'services/build_server_service.dart';
import 'services/build_service.dart';
import 'services/compiler_service.dart';
import 'services/project_generator_service.dart';
import 'services/project_service.dart';
import 'services/preview_service.dart';
import 'services/runtime_service.dart';
import 'services/settings_service.dart';
import 'services/storage_service.dart';
import 'state/app_state.dart';
import 'theme/app_theme.dart';
import 'widgets/app_shell.dart';
import 'screens/login_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FlutterCreateApp());
}

class FlutterCreateApp extends StatelessWidget {
  const FlutterCreateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SettingsService()..load()),
        ChangeNotifierProvider(create: (_) => AuthService()..restoreSession()),
        Provider(create: (_) => StorageService()),
        Provider(create: (_) => ProjectGeneratorService()),
        ProxyProvider<SettingsService, BuildServerService>(
          update: (context, settings, previous) => previous ?? BuildServerService(settings),
        ),
        ChangeNotifierProvider(
          create: (context) => ProjectService(
            storage: context.read<StorageService>(),
            generator: context.read<ProjectGeneratorService>(),
          ),
        ),
        Provider(
          create: (context) => CompilerService(context.read<BuildServerService>()),
        ),
        Provider(
          create: (context) => RuntimeService(context.read<BuildServerService>()),
        ),
        ChangeNotifierProvider(
          create: (context) => PreviewService(
            compilerService: context.read<CompilerService>(),
            runtimeService: context.read<RuntimeService>(),
            buildServerService: context.read<BuildServerService>(),
          ),
        ),
        ChangeNotifierProvider(
          create: (context) => BuildService(context.read<BuildServerService>()),
        ),
        ChangeNotifierProvider(create: (_) => AppState()),
      ],
      child: Consumer2<SettingsService, AuthService>(
        builder: (context, settings, auth, _) {
          return MaterialApp(
            title: 'Flutter Create',
            debugShowCheckedModeBanner: false,
            themeMode: settings.darkMode ? ThemeMode.dark : ThemeMode.light,
            theme: AppTheme.light(),
            darkTheme: AppTheme.dark(),
            home: auth.isSignedIn ? const AppShell() : const _AuthGate(),
          );
        },
      ),
    );
  }
}


class _AuthGate extends StatelessWidget {
  const _AuthGate();

  @override
  Widget build(BuildContext context) => const LoginScreen();
}
