enum BuildType { debug, release, bundle }

extension BuildTypeX on BuildType {
  String get label {
    switch (this) {
      case BuildType.debug:
        return 'Debug APK';
      case BuildType.release:
        return 'Release APK';
      case BuildType.bundle:
        return 'App Bundle';
    }
  }

  String get endpointValue {
    switch (this) {
      case BuildType.debug:
        return 'debug';
      case BuildType.release:
        return 'release';
      case BuildType.bundle:
        return 'bundle';
    }
  }
}

enum BuildStatus { idle, uploading, queued, building, success, failed }

class BuildJob {
  final String id;
  final BuildType type;
  BuildStatus status;
  double progress; // 0.0 - 1.0
  List<String> logs;
  String? downloadUrl;
  String? error;

  BuildJob({
    required this.id,
    required this.type,
    this.status = BuildStatus.idle,
    this.progress = 0,
    List<String>? logs,
    this.downloadUrl,
    this.error,
  }) : logs = logs ?? [];

  BuildJob copyWith({
    BuildStatus? status,
    double? progress,
    List<String>? logs,
    String? downloadUrl,
    String? error,
  }) {
    return BuildJob(
      id: id,
      type: type,
      status: status ?? this.status,
      progress: progress ?? this.progress,
      logs: logs ?? this.logs,
      downloadUrl: downloadUrl ?? this.downloadUrl,
      error: error ?? this.error,
    );
  }
}

/// Represents a remote preview session obtained from the Build Server.
///
/// The server is expected to compile the project to Flutter Web inside an
/// isolated container and expose the result at [previewUrl]. Flutter Create
/// embeds that URL in a WebView. This keeps the on-device app honest about
/// the fact that it does not embed a Dart/Flutter compiler itself.
class PreviewSession {
  final String id;
  final String previewUrl;
  final bool supportsHotReload;

  PreviewSession({
    required this.id,
    required this.previewUrl,
    this.supportsHotReload = false,
  });
}
