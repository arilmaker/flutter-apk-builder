enum ConsoleLevel { error, warning, info, success }

class ConsoleMessage {
  final ConsoleLevel level;
  final String message;
  final String? filePath;
  final int? line;
  final DateTime timestamp;

  ConsoleMessage({
    required this.level,
    required this.message,
    this.filePath,
    this.line,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  factory ConsoleMessage.error(String message, {String? filePath, int? line}) =>
      ConsoleMessage(
          level: ConsoleLevel.error,
          message: message,
          filePath: filePath,
          line: line);

  factory ConsoleMessage.warning(String message,
          {String? filePath, int? line}) =>
      ConsoleMessage(
          level: ConsoleLevel.warning,
          message: message,
          filePath: filePath,
          line: line);

  factory ConsoleMessage.info(String message) =>
      ConsoleMessage(level: ConsoleLevel.info, message: message);

  factory ConsoleMessage.success(String message) =>
      ConsoleMessage(level: ConsoleLevel.success, message: message);

  bool get isError => level == ConsoleLevel.error;
}
