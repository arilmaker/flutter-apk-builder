/// Represents a single file that belongs to a [ProjectModel].
///
/// `path` is always stored relative to the project root, using forward
/// slashes, e.g. `lib/main.dart` or `lib/screens/home.dart`.
class FileModel {
  final String id;
  String name;
  String path;
  String content;
  bool isModified;
  DateTime updatedAt;

  FileModel({
    required this.id,
    required this.name,
    required this.path,
    required this.content,
    this.isModified = false,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  /// File extension without the leading dot, e.g. `dart`, `yaml`.
  String get extension {
    final dot = name.lastIndexOf('.');
    if (dot == -1 || dot == name.length - 1) return '';
    return name.substring(dot + 1).toLowerCase();
  }

  bool get isDart => extension == 'dart';
  bool get isPubspec => name == 'pubspec.yaml';
  bool get isFolder => content.isEmpty && extension.isEmpty && name.startsWith('#folder#');

  /// Directory portion of [path], e.g. `lib/screens` for `lib/screens/home.dart`.
  String get directory {
    final slash = path.lastIndexOf('/');
    if (slash == -1) return '';
    return path.substring(0, slash);
  }

  FileModel copyWith({
    String? name,
    String? path,
    String? content,
    bool? isModified,
    DateTime? updatedAt,
  }) {
    return FileModel(
      id: id,
      name: name ?? this.name,
      path: path ?? this.path,
      content: content ?? this.content,
      isModified: isModified ?? this.isModified,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'path': path,
        'content': content,
        'isModified': isModified,
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory FileModel.fromJson(Map<String, dynamic> json) => FileModel(
        id: json['id'] as String,
        name: json['name'] as String,
        path: json['path'] as String,
        content: json['content'] as String? ?? '',
        isModified: json['isModified'] as bool? ?? false,
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ??
            DateTime.now(),
      );
}
