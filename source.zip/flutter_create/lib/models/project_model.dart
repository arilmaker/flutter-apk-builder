import 'file_model.dart';

enum ProjectTemplate { empty, material3, counter, blankUi }

extension ProjectTemplateX on ProjectTemplate {
  String get label {
    switch (this) {
      case ProjectTemplate.empty:
        return 'Empty';
      case ProjectTemplate.material3:
        return 'Material 3';
      case ProjectTemplate.counter:
        return 'Counter';
      case ProjectTemplate.blankUi:
        return 'Blank UI';
    }
  }
}

/// Represents a Flutter project managed by Flutter Create.
///
/// `path` is the folder name under the app's projects directory on device
/// storage (see StorageService), not an absolute filesystem path.
class ProjectModel {
  final String id;
  String name;
  String packageName;
  String description;
  final String path;
  final DateTime createdAt;
  DateTime updatedAt;
  List<FileModel> files;

  ProjectModel({
    required this.id,
    required this.name,
    required this.packageName,
    required this.description,
    required this.path,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<FileModel>? files,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now(),
        files = files ?? [];

  FileModel? findFile(String relativePath) {
    for (final f in files) {
      if (f.path == relativePath) return f;
    }
    return null;
  }

  FileModel? get mainFile => findFile('lib/main.dart');

  FileModel? get pubspecFile => findFile('pubspec.yaml');

  void upsertFile(FileModel file) {
    final index = files.indexWhere((f) => f.path == file.path);
    if (index >= 0) {
      files[index] = file;
    } else {
      files.add(file);
    }
    updatedAt = DateTime.now();
  }

  void removeFile(String relativePath) {
    files.removeWhere((f) => f.path == relativePath);
    updatedAt = DateTime.now();
  }

  ProjectModel copyWith({
    String? name,
    String? packageName,
    String? description,
    List<FileModel>? files,
  }) {
    return ProjectModel(
      id: id,
      name: name ?? this.name,
      packageName: packageName ?? this.packageName,
      description: description ?? this.description,
      path: path,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
      files: files ?? this.files,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'packageName': packageName,
        'description': description,
        'path': path,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'files': files.map((f) => f.toJson()).toList(),
      };

  factory ProjectModel.fromJson(Map<String, dynamic> json) => ProjectModel(
        id: json['id'] as String,
        name: json['name'] as String,
        packageName: json['packageName'] as String? ?? 'com.example.app',
        description: json['description'] as String? ?? '',
        path: json['path'] as String,
        createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
            DateTime.now(),
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ??
            DateTime.now(),
        files: (json['files'] as List<dynamic>? ?? [])
            .map((e) => FileModel.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}
