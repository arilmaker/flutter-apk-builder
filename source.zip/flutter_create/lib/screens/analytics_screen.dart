import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/saas_ui.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Analytics'),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.download_outlined)),
          const SizedBox(width: 8),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
        children: [
          const Text('Workspace performance', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Track builds, previews, projects and workspace usage.', style: TextStyle(color: AppColors.textSecondaryDark)),
          const SizedBox(height: 22),
          LayoutBuilder(builder: (context, constraints) {
            final columns = constraints.maxWidth > 760 ? 4 : 2;
            return GridView.count(
              crossAxisCount: columns,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.35,
              children: const [
                SaaSMetricCard(title: 'Projects', value: '12', subtitle: '+3 this month', icon: Icons.folder_rounded, color: AppColors.accentAlt),
                SaaSMetricCard(title: 'Builds', value: '84', subtitle: '91% success rate', icon: Icons.rocket_launch_rounded, color: AppColors.accent),
                SaaSMetricCard(title: 'Preview runs', value: '246', subtitle: '+18% from last month', icon: Icons.play_circle_fill_rounded, color: Colors.purpleAccent),
                SaaSMetricCard(title: 'Storage', value: '1.8 GB', subtitle: '18% of workspace', icon: Icons.cloud_rounded, color: AppColors.warn, progress: .18),
              ],
            );
          }),
          const SizedBox(height: 18),
          const SaaSPanel(
            title: 'Build activity',
            subtitle: 'Successful and failed builds over the last 7 days.',
            child: _BuildChart(),
          ),
          const SizedBox(height: 18),
          const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: SaaSPanel(title: 'Language usage', child: _LanguageUsage())),
              SizedBox(width: 12),
              Expanded(child: SaaSPanel(title: 'Runtime health', child: _RuntimeHealth())),
            ],
          ),
        ],
      ),
    );
  }
}

class _BuildChart extends StatelessWidget {
  const _BuildChart();

  @override
  Widget build(BuildContext context) {
    final values = [0.35, 0.62, 0.44, 0.82, 0.56, 0.92, 0.71];
    final labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return SizedBox(
      height: 220,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: List.generate(values.length, (index) {
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text('${(values[index] * 100).round()}', style: const TextStyle(fontSize: 9, color: AppColors.textSecondaryDark)),
                  const SizedBox(height: 7),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 500),
                    height: 150 * values[index],
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [AppColors.accentAlt, AppColors.accent],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(labels[index], style: const TextStyle(fontSize: 9, color: AppColors.textSecondaryDark)),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _LanguageUsage extends StatelessWidget {
  const _LanguageUsage();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        SaaSProgressRow(title: 'Dart', value: '82%', progress: .82, color: AppColors.accentAlt),
        SaaSProgressRow(title: 'YAML', value: '9%', progress: .09, color: AppColors.warn),
        SaaSProgressRow(title: 'JSON', value: '6%', progress: .06, color: AppColors.accent),
        SaaSProgressRow(title: 'Other', value: '3%', progress: .03, color: AppColors.danger),
      ],
    );
  }
}

class _RuntimeHealth extends StatelessWidget {
  const _RuntimeHealth();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        SaaSActivityTile(icon: Icons.check_circle_rounded, color: AppColors.accent, title: 'Preview service', subtitle: 'Operational • 99.9% uptime', time: 'now'),
        SaaSActivityTile(icon: Icons.cloud_done_rounded, color: AppColors.accentAlt, title: 'Build server', subtitle: 'Connected • 42ms latency', time: '1m'),
        SaaSActivityTile(icon: Icons.security_rounded, color: AppColors.warn, title: 'Workspace security', subtitle: 'No active warnings', time: '2m'),
      ],
    );
  }
}
