import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/saas_ui.dart';

class BillingScreen extends StatelessWidget {
  const BillingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Billing & Plans')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
        children: [
          const Text('Choose your workspace plan', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Scale from personal projects to team development.', style: TextStyle(color: AppColors.textSecondaryDark)),
          const SizedBox(height: 22),
          LayoutBuilder(builder: (context, constraints) {
            final vertical = constraints.maxWidth < 760;
            final cards = const [
              _PlanCard(name: 'Free', price: '\$0', description: 'For learning and small experiments.', features: ['3 projects', '500 MB storage', 'Local editor', 'Basic preview'], color: AppColors.textSecondaryDark),
              _PlanCard(name: 'Pro', price: '\$9', description: 'For serious Flutter builders.', features: ['Unlimited projects', '20 GB storage', 'Remote builds', 'Priority preview', 'Version history'], color: AppColors.accentAlt, highlighted: true),
              _PlanCard(name: 'Team', price: '\$29', description: 'For collaborative product teams.', features: ['Everything in Pro', 'Team workspace', 'Role permissions', 'Shared builds', 'Workspace analytics'], color: AppColors.accent),
            ];
            if (vertical) return Column(children: cards.map((e) => Padding(padding: const EdgeInsets.only(bottom: 12), child: e)).toList());
            return Row(crossAxisAlignment: CrossAxisAlignment.start, children: cards.map((e) => Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 6), child: e))).toList());
          }),
          const SizedBox(height: 20),
          const SaaSPanel(
            title: 'Usage this month',
            subtitle: 'Your current workspace consumption.',
            child: Column(
              children: [
                SaaSProgressRow(title: 'Storage', value: '1.8 / 10 GB', progress: .18, color: AppColors.accentAlt),
                SaaSProgressRow(title: 'Build minutes', value: '42 / 120 min', progress: .35, color: AppColors.accent),
                SaaSProgressRow(title: 'Preview runs', value: '246 / 1,000', progress: .246, color: Colors.purpleAccent),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final String name;
  final String price;
  final String description;
  final List<String> features;
  final Color color;
  final bool highlighted;

  const _PlanCard({required this.name, required this.price, required this.description, required this.features, required this.color, this.highlighted = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: highlighted ? color.withValues(alpha: .65) : AppColors.borderDark, width: highlighted ? 1.5 : 1),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)), const Spacer(), if (highlighted) const SaaSStatusPill(text: 'Popular', color: AppColors.accentAlt, icon: Icons.star_rounded)]),
        const SizedBox(height: 18),
        RichText(text: TextSpan(style: const TextStyle(color: AppColors.textPrimaryDark), children: [TextSpan(text: price, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900)), const TextSpan(text: ' / month', style: TextStyle(color: AppColors.textSecondaryDark, fontSize: 11))])),
        const SizedBox(height: 8),
        Text(description, style: const TextStyle(fontSize: 11, color: AppColors.textSecondaryDark, height: 1.4)),
        const SizedBox(height: 18),
        ...features.map((feature) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Row(children: [Icon(Icons.check_circle_rounded, color: color, size: 17), const SizedBox(width: 8), Expanded(child: Text(feature, style: const TextStyle(fontSize: 11)))]))),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: highlighted ? FilledButton(onPressed: () {}, child: const Text('Upgrade')) : OutlinedButton(onPressed: () {}, child: const Text('Select'))),
      ]),
    );
  }
}
