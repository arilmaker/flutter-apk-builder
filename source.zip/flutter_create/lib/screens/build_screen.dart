import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/build_job.dart';
import '../services/build_service.dart';
import '../services/settings_service.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';

class BuildScreen extends StatelessWidget {
  const BuildScreen({super.key});

  Color _statusColor(BuildStatus s) {
    switch (s) {
      case BuildStatus.success:
        return AppColors.run;
      case BuildStatus.failed:
        return AppColors.danger;
      case BuildStatus.idle:
        return AppColors.textSecondaryDark;
      default:
        return AppColors.accentAlt;
    }
  }

  String _statusLabel(BuildStatus s) {
    switch (s) {
      case BuildStatus.idle:
        return 'Idle';
      case BuildStatus.uploading:
        return 'Uploading project...';
      case BuildStatus.queued:
        return 'Queued';
      case BuildStatus.building:
        return 'Building...';
      case BuildStatus.success:
        return 'Build completed';
      case BuildStatus.failed:
        return 'Build failed';
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final buildService = context.watch<BuildService>();
    final settings = context.watch<SettingsService>();
    final project = appState.currentProject;
    final job = buildService.currentJob;

    return Scaffold(
      appBar: AppBar(title: const Text('Build')),
      body: project == null
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Belum ada project aktif.\nBuka project terlebih dahulu dari tab Projects.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.textSecondaryDark),
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                if (!settings.isBuildServerConfigured)
                  Card(
                    color: AppColors.surfaceDarkAlt,
                    child: const Padding(
                      padding: EdgeInsets.all(14),
                      child: Text(
                        'Build Server URL belum diatur. Atur di Settings > Build sebelum membangun APK.',
                        style: TextStyle(color: AppColors.warn, fontSize: 13),
                      ),
                    ),
                  ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _BuildButton(
                        label: 'DEBUG APK',
                        icon: Icons.bug_report_outlined,
                        enabled: settings.isBuildServerConfigured,
                        onTap: () => buildService.startBuild(project, BuildType.debug),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _BuildButton(
                        label: 'RELEASE APK',
                        icon: Icons.rocket_launch_outlined,
                        enabled: settings.isBuildServerConfigured,
                        onTap: () => buildService.startBuild(project, BuildType.release),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _BuildButton(
                        label: 'APP BUNDLE',
                        icon: Icons.inventory_2_outlined,
                        enabled: settings.isBuildServerConfigured,
                        onTap: () => buildService.startBuild(project, BuildType.bundle),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                if (job != null) ...[
                  Row(
                    children: [
                      Icon(Icons.circle, size: 10, color: _statusColor(job.status)),
                      const SizedBox(width: 8),
                      Text(_statusLabel(job.status),
                          style: TextStyle(color: _statusColor(job.status), fontWeight: FontWeight.w600)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: job.status == BuildStatus.success
                          ? 1
                          : (job.progress > 0 ? job.progress : null),
                      minHeight: 8,
                      backgroundColor: AppColors.surfaceDarkAlt,
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (job.error != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(job.error!, style: const TextStyle(color: AppColors.danger)),
                    ),
                  if (job.status == BuildStatus.success)
                    FilledButton.icon(
                      onPressed: () async {
                        final path = await buildService.downloadCurrentBuild();
                        if (path != null) {
                          await Share.shareXFiles([XFile(path)]);
                        }
                      },
                      icon: const Icon(Icons.download_rounded),
                      label: const Text('Download & Share'),
                    ),
                  const SizedBox(height: 16),
                  Text('Build Logs', style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceDark,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.borderDark),
                    ),
                    child: job.logs.isEmpty
                        ? const Text('No logs yet.',
                            style: TextStyle(color: AppColors.textSecondaryDark, fontSize: 12))
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: job.logs
                                .map((l) => Text(l,
                                    style: const TextStyle(
                                        fontFamily: 'monospace', fontSize: 12)))
                                .toList(),
                          ),
                  ),
                ],
              ],
            ),
    );
  }
}

class _BuildButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool enabled;
  final VoidCallback onTap;

  const _BuildButton({
    required this.label,
    required this.icon,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: enabled ? onTap : null,
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 14),
        side: const BorderSide(color: AppColors.borderDark),
      ),
    );
  }
}
