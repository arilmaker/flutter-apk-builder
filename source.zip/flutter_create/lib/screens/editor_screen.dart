import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_code_editor/flutter_code_editor.dart';
import 'package:flutter_highlight/themes/atom-one-dark.dart';
import 'package:highlight/languages/dart.dart';
import 'package:highlight/languages/yaml.dart';
import 'package:provider/provider.dart';

import '../services/project_service.dart';
import '../services/settings_service.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/app_shell.dart';
import '../widgets/console_panel.dart';
import '../widgets/editor_toolbar.dart';
import '../models/console_message.dart';
import 'preview_screen.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  CodeController? _controller;
  String? _boundFilePath;
  final List<String> _undoStack = [];
  final List<String> _redoStack = [];
  Timer? _historyDebounce;
  bool _searchOpen = false;
  final _searchController = TextEditingController();
  final _replaceController = TextEditingController();
  List<ConsoleMessage> _localConsole = [];

  void _bindController(String path, String content, bool isDart) {
    _controller?.dispose();
    _controller = CodeController(
      text: content,
      language: isDart ? dart : yaml,
    );
    _boundFilePath = path;
    _undoStack.clear();
    _redoStack.clear();
    _undoStack.add(content);
    _controller!.addListener(_onChanged);
  }

  void _onChanged() {
    final appState = context.read<AppState>();
    final text = _controller!.text;
    appState.updateActiveFileContent(text);

    _historyDebounce?.cancel();
    _historyDebounce = Timer(const Duration(milliseconds: 500), () {
      if (_undoStack.isEmpty || _undoStack.last != text) {
        _undoStack.add(text);
        _redoStack.clear();
      }
    });
    setState(() {}); // refresh unsaved indicator
  }

  void _undo() {
    if (_undoStack.length < 2) return;
    _redoStack.add(_undoStack.removeLast());
    final prev = _undoStack.last;
    _controller!.text = prev;
    context.read<AppState>().updateActiveFileContent(prev);
  }

  void _redo() {
    if (_redoStack.isEmpty) return;
    final next = _redoStack.removeLast();
    _undoStack.add(next);
    _controller!.text = next;
    context.read<AppState>().updateActiveFileContent(next);
  }

  Future<void> _save() async {
    final appState = context.read<AppState>();
    final project = appState.currentProject;
    final file = appState.activeFile;
    if (project == null || file == null) return;
    await context.read<ProjectService>().saveFile(project, file);
    appState.markSaved();
    setState(() {});
  }

  void _findAll(String query) {
    if (query.isEmpty || _controller == null) return;
    final text = _controller!.text;
    final index = text.indexOf(query);
    if (index == -1) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Tidak ditemukan.')));
      return;
    }
    _controller!.selection = TextSelection(baseOffset: index, extentOffset: index + query.length);
  }

  void _replaceAll(String query, String replacement) {
    if (query.isEmpty || _controller == null) return;
    final newText = _controller!.text.replaceAll(query, replacement);
    _controller!.text = newText;
    context.read<AppState>().updateActiveFileContent(newText);
  }

  Future<void> _runFile() async {
    final appState = context.read<AppState>();
    final project = appState.currentProject;
    final file = appState.activeFile;
    if (project == null || file == null) return;

    if (file.isModified) {
      await _save();
    }

    setState(() => _localConsole = [ConsoleMessage.info('Menyimpan & menganalisis...')]);

    // Delegate the actual compile/run/preview lifecycle to the Preview tab,
    // which owns PreviewService. We just jump there and trigger RUN.
    AppShellController.of(context)?.goTo(3);
    PreviewScreenState.triggerRunFromEditor?.call();
  }

  @override
  void dispose() {
    _historyDebounce?.cancel();
    _controller?.dispose();
    _searchController.dispose();
    _replaceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final settings = context.watch<SettingsService>();
    final file = appState.activeFile;

    if (file == null) {
      return const Scaffold(
        body: Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'Belum ada file yang dibuka.\nBuka project lalu pilih file .dart dari Project Explorer.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondaryDark),
            ),
          ),
        ),
      );
    }

    if (_boundFilePath != file.path) {
      _bindController(file.path, file.content, file.isDart);
    }

    return Scaffold(
      appBar: EditorToolbar(
        fileName: file.name,
        isModified: file.isModified,
        onRun: _runFile,
        onReload: _runFile,
        onStop: () {},
        onSave: _save,
        onSearch: () => setState(() => _searchOpen = !_searchOpen),
      ),
      body: Column(
        children: [
          if (_searchOpen)
            Container(
              color: AppColors.surfaceDarkAlt,
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      decoration: const InputDecoration(isDense: true, hintText: 'Search'),
                    ),
                  ),
                  IconButton(
                      icon: const Icon(Icons.search, size: 18),
                      onPressed: () => _findAll(_searchController.text)),
                  const SizedBox(width: 6),
                  Expanded(
                    child: TextField(
                      controller: _replaceController,
                      decoration: const InputDecoration(isDense: true, hintText: 'Replace'),
                    ),
                  ),
                  IconButton(
                      icon: const Icon(Icons.find_replace, size: 18),
                      onPressed: () =>
                          _replaceAll(_searchController.text, _replaceController.text)),
                ],
              ),
            ),
          Container(
            color: AppColors.surfaceDarkAlt,
            child: Row(
              children: [
                IconButton(icon: const Icon(Icons.undo, size: 18), onPressed: _undo),
                IconButton(icon: const Icon(Icons.redo, size: 18), onPressed: _redo),
                IconButton(
                  icon: const Icon(Icons.copy_all_outlined, size: 18),
                  tooltip: 'Select all + copy',
                  onPressed: () {
                    _controller!.selection =
                        TextSelection(baseOffset: 0, extentOffset: _controller!.text.length);
                    Clipboard.setData(ClipboardData(text: _controller!.text));
                  },
                ),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Text(
                    file.path,
                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondaryDark),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: AppColors.bgDark,
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: SingleChildScrollView(
                child: CodeTheme(
                  data: CodeThemeData(styles: atomOneDarkTheme),
                  child: CodeField(
                    controller: _controller!,
                    wrap: settings.wordWrap,
                    lineNumberStyle: LineNumberStyle(
                      textStyle: TextStyle(
                        color: AppColors.textSecondaryDark,
                        fontSize: settings.editorFontSize - 1,
                      ),
                    ),
                    textStyle: TextStyle(
                      fontFamily: 'monospace',
                      fontSize: settings.editorFontSize,
                    ),
                  ),
                ),
              ),
            ),
          ),
          ConsolePanel(messages: _localConsole, height: 90),
        ],
      ),
    );
  }
}
