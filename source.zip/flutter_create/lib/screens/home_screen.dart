import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/file_model.dart';
import '../models/project_model.dart';
import '../services/auth_service.dart';
import '../services/project_service.dart';
import '../services/storage_service.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/app_shell.dart';
import '../widgets/empty_state.dart';
import '../widgets/logo_mark.dart';
import '../widgets/project_card.dart';
import '../widgets/saas_ui.dart';
import 'analytics_screen.dart';
import 'billing_screen.dart';
import 'new_project_screen.dart';
import 'project_explorer_screen.dart';
import 'team_screen.dart';
import 'video_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _search = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProjectService>().refresh();
    });
  }

  Future<void> _openProject(ProjectModel project) async {
    if (!mounted) return;
    context.read<AppState>().openProject(project);
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProjectExplorerScreen(project: project)),
    );
  }

  Future<void> _importDart() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['dart'],
    );
    if (result == null || result.files.single.path == null || !mounted) return;

    final path = result.files.single.path!;
    try {
      final content = await File(path).readAsString();
      final name = path.split(Platform.pathSeparator).last;
      final projectService = context.read<ProjectService>();
      final project = await projectService.createProject(
        name: name.replaceAll('.dart', ''),
        packageName: 'com.example.imported',
        description: 'Imported from $name',
        template: ProjectTemplate.empty,
      );
      final file = FileModel(
        id: '${DateTime.now().microsecondsSinceEpoch}_$name',
        name: name,
        path: 'lib/$name',
        content: content,
      );
      project.upsertFile(file);
      await projectService.saveProject(project);
      if (!mounted) return;
      context.read<AppState>()
        ..openProject(project)
        ..openFile(file);
      AppShellController.of(context)?.goTo(2);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Unable to read Dart file.')),
      );
    }
  }

  Future<void> _importZip() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
    );
    if (result == null || result.files.single.path == null || !mounted) return;
    try {
      final project = await context.read<ProjectService>().importProject(
        File(result.files.single.path!),
      );
      if (mounted) await _openProject(project);
    } on StorageException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  void _openSaaSScreen(Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    final projectService = context.watch<ProjectService>();
    final auth = context.watch<AuthService>();
    final allRecents = projectService.recentProjects;
    final recents = _search.trim().isEmpty
        ? allRecents
        : allRecents.where((project) {
            final q = _search.toLowerCase();
            return project.name.toLowerCase().contains(q) ||
                project.packageName.toLowerCase().contains(q);
          }).toList();
    final userName = auth.user?.displayName?.split(' ').first ??
        (auth.guestMode ? 'Guest' : 'Developer');

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () => projectService.refresh(),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 34),
            children: [
              _buildHeader(userName, auth),
              const SizedBox(height: 18),
              _buildWorkspaceBanner(),
              const SizedBox(height: 18),
              SaaSSearchField(onChanged: (value) => setState(() => _search = value)),
              const SizedBox(height: 18),
              _buildMetrics(projectService),
              const SizedBox(height: 24),
              const SaaSSectionHeader(
                title: 'Create something new',
                subtitle: 'Start from a template or bring an existing Flutter project.',
              ),
              const SizedBox(height: 12),
              _buildActions(),
              const SizedBox(height: 24),
              SaaSUpgradeCard(onUpgrade: () => _openSaaSScreen(const BillingScreen())),
              const SizedBox(height: 24),
              _buildActivityAndUsage(),
              const SizedBox(height: 24),
              SaaSSectionHeader(
                title: 'Recent projects',
                subtitle: '${allRecents.length} projects in your workspace',
                trailing: TextButton(
                  onPressed: () => AppShellController.of(context)?.goTo(1),
                  child: const Text('View all'),
                ),
              ),
              const SizedBox(height: 12),
              if (recents.isEmpty)
                const EmptyState(
                  icon: Icons.folder_off_outlined,
                  title: 'No matching projects',
                  subtitle: 'Create a project or import a Flutter ZIP to get started.',
                )
              else
                ...recents.take(5).map(
                      (project) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: ProjectCard(
                          project: project,
                          onTap: () => _openProject(project),
                          onDelete: () => context.read<ProjectService>().deleteProject(project.id),
                          onExport: () async {
                            try {
                              await context.read<ProjectService>().exportProject(project);
                              if (!mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Project exported.')),
                              );
                            } on StorageException catch (e) {
                              if (!mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(e.message)),
                              );
                            }
                          },
                        ),
                      ),
                    ),
              const SizedBox(height: 18),
              _buildLearnCard(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(String userName, AuthService auth) {
    return Row(
      children: [
        Builder(builder: (context) => IconButton(
          tooltip: 'Workspace menu',
          onPressed: () => Scaffold.of(context).openDrawer(),
          icon: const Icon(Icons.menu_rounded),
        )),
        const LogoMark(size: 50),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Good morning, $userName', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 3),
              const Text('Your Flutter workspace', style: TextStyle(color: AppColors.textSecondaryDark, fontSize: 11)),
            ],
          ),
        ),
        IconButton(
          tooltip: 'Team',
          onPressed: () => _openSaaSScreen(const TeamScreen()),
          icon: const Icon(Icons.groups_2_outlined),
        ),
        IconButton(
          tooltip: 'Account',
          onPressed: () => showModalBottomSheet(
            context: context,
            showDragHandle: true,
            builder: (_) => const _AccountSheet(),
          ),
          icon: auth.user?.photoUrl == null
              ? const Icon(Icons.account_circle_outlined)
              : CircleAvatar(radius: 14, backgroundImage: NetworkImage(auth.user!.photoUrl!)),
        ),
      ],
    );
  }

  Widget _buildWorkspaceBanner() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.accentAlt.withValues(alpha: .20),
            AppColors.surfaceDark,
            AppColors.surfaceDark,
          ],
        ),
        border: Border.all(color: AppColors.accentAlt.withValues(alpha: .28)),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppColors.accentAlt.withValues(alpha: .12),
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(Icons.cloud_rounded, color: AppColors.accentAlt),
          ),
          const SizedBox(width: 13),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [Text('Personal Workspace', style: TextStyle(fontWeight: FontWeight.w800)), SizedBox(width: 8), SaaSStatusPill(text: 'Active', color: AppColors.accent)]),
                SizedBox(height: 5),
                Text('Your projects, builds and previews are organized here.', style: TextStyle(fontSize: 10.5, color: AppColors.textSecondaryDark)),
              ],
            ),
          ),
          IconButton(onPressed: () => _openSaaSScreen(const AnalyticsScreen()), icon: const Icon(Icons.insights_rounded)),
        ],
      ),
    );
  }

  Widget _buildMetrics(ProjectService projectService) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth > 720 ? 4 : 2;
        return GridView.count(
          crossAxisCount: columns,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1.55,
          children: [
            SaaSMetricCard(
              title: 'Projects',
              value: '${projectService.recentProjects.length}',
              subtitle: 'In this workspace',
              icon: Icons.folder_rounded,
              color: AppColors.accentAlt,
              onTap: () => AppShellController.of(context)?.goTo(1),
            ),
            const SaaSMetricCard(
              title: 'Builds',
              value: '84',
              subtitle: 'This month',
              icon: Icons.rocket_launch_rounded,
              color: AppColors.accent,
              progress: .72,
            ),
            const SaaSMetricCard(
              title: 'Previews',
              value: '246',
              subtitle: 'Run sessions',
              icon: Icons.play_circle_fill_rounded,
              color: Colors.purpleAccent,
            ),
            const SaaSMetricCard(
              title: 'Storage',
              value: '1.8 GB',
              subtitle: 'Of 10 GB',
              icon: Icons.cloud_rounded,
              color: AppColors.warn,
              progress: .18,
            ),
          ],
        );
      },
    );
  }

  Widget _buildActions() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 1.22,
      children: [
        SaaSActionCard(title: 'New Project', subtitle: 'Create from a template', icon: Icons.add_rounded, color: AppColors.accent, badge: 'NEW', onTap: () async {
          final project = await Navigator.of(context).push<ProjectModel>(MaterialPageRoute(builder: (_) => const NewProjectScreen()));
          if (project != null && mounted) await _openProject(project);
        }),
        SaaSActionCard(title: 'Open Project', subtitle: 'Browse your workspace', icon: Icons.folder_open_rounded, color: AppColors.accentAlt, onTap: () => AppShellController.of(context)?.goTo(1)),
        SaaSActionCard(title: 'Import Dart', subtitle: 'Bring a single .dart file', icon: Icons.code_rounded, color: Colors.purpleAccent, onTap: _importDart),
        SaaSActionCard(title: 'Import ZIP', subtitle: 'Import a Flutter project', icon: Icons.archive_rounded, color: AppColors.warn, onTap: _importZip),
      ],
    );
  }

  Widget _buildActivityAndUsage() {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 680) {
          return Column(children: [
            const SaaSPanel(
              title: 'Recent activity',
              subtitle: 'Latest workspace events.',
              child: _ActivityList(),
            ),
            const SizedBox(height: 12),
            const SaaSPanel(
              title: 'Workspace usage',
              subtitle: 'Current resource consumption.',
              child: _UsageList(),
            ),
          ]);
        }
        return const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: SaaSPanel(title: 'Recent activity', subtitle: 'Latest workspace events.', child: _ActivityList())),
            SizedBox(width: 12),
            Expanded(child: SaaSPanel(title: 'Workspace usage', subtitle: 'Current resource consumption.', child: _UsageList())),
          ],
        );
      },
    );
  }

  Widget _buildLearnCard() {
    return Material(
      color: AppColors.surfaceDark,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VideoScreen())),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.borderDark)),
          child: Row(children: [
            Container(width: 50, height: 50, decoration: BoxDecoration(color: AppColors.accentAlt.withValues(alpha: .12), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.play_circle_fill_rounded, color: AppColors.accentAlt, size: 28)),
            const SizedBox(width: 13),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Learn Flutter Create', style: TextStyle(fontWeight: FontWeight.w800)), SizedBox(height: 4), Text('Watch the product walkthrough and learn the editor workflow.', style: TextStyle(fontSize: 10.5, color: AppColors.textSecondaryDark))])),
            const Icon(Icons.chevron_right_rounded),
          ]),
        ),
      ),
    );
  }
}

class _ActivityList extends StatelessWidget {
  const _ActivityList();
  @override
  Widget build(BuildContext context) {
    return const Column(children: [
      SaaSActivityTile(icon: Icons.check_circle_rounded, color: AppColors.accent, title: 'Build completed', subtitle: 'my_app • Release APK', time: '2m'),
      SaaSActivityTile(icon: Icons.play_circle_fill_rounded, color: AppColors.accentAlt, title: 'Preview started', subtitle: 'dashboard.dart • Web runtime', time: '14m'),
      SaaSActivityTile(icon: Icons.edit_rounded, color: Colors.purpleAccent, title: 'File edited', subtitle: 'home.dart • 28 changes', time: '1h'),
      SaaSActivityTile(icon: Icons.folder_rounded, color: AppColors.warn, title: 'Project imported', subtitle: 'commerce_app.zip', time: '3h'),
    ]);
  }
}

class _UsageList extends StatelessWidget {
  const _UsageList();
  @override
  Widget build(BuildContext context) {
    return const Column(children: [
      SaaSProgressRow(title: 'Storage', value: '1.8 GB / 10 GB', progress: .18, color: AppColors.accentAlt),
      SaaSProgressRow(title: 'Build minutes', value: '42 / 120', progress: .35, color: AppColors.accent),
      SaaSProgressRow(title: 'Preview runs', value: '246 / 1,000', progress: .246, color: Colors.purpleAccent),
      SaaSProgressRow(title: 'Projects', value: '12 / 50', progress: .24, color: AppColors.warn),
    ]);
  }
}

class _AccountSheet extends StatelessWidget {
  const _AccountSheet();

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (auth.user?.photoUrl != null)
            CircleAvatar(radius: 30, backgroundImage: NetworkImage(auth.user!.photoUrl!))
          else
            const CircleAvatar(radius: 30, child: Icon(Icons.person)),
          const SizedBox(height: 10),
          Text(auth.user?.displayName ?? (auth.guestMode ? 'Guest Mode' : 'Google Account'), style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(auth.user?.email ?? (auth.guestMode ? 'Sign in with Google to sync your account.' : ''), style: const TextStyle(color: AppColors.textSecondaryDark, fontSize: 11)),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: () { Navigator.pop(context); Navigator.of(context).push(MaterialPageRoute(builder: (_) => const TeamScreen())); }, icon: const Icon(Icons.groups_2_outlined), label: const Text('Team'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: () { Navigator.pop(context); Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BillingScreen())); }, icon: const Icon(Icons.workspace_premium_outlined), label: const Text('Plans'))),
          ]),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () async { await context.read<AuthService>().signOut(); if (context.mounted) Navigator.of(context).pop(); }, icon: const Icon(Icons.logout), label: const Text('Sign out'))),
        ]),
      ),
    );
  }
}
