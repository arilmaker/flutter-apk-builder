import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/auth_service.dart';
import '../theme/app_theme.dart';
import '../widgets/logo_mark.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Column(
                children: [
                  const LogoMark(size: 104),
                  const SizedBox(height: 24),
                  Text('Flutter Create', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  const Text('Flutter IDE for Android', style: TextStyle(color: AppColors.textSecondaryDark)),
                  const SizedBox(height: 36),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        children: [
                          const Align(
                            alignment: Alignment.centerLeft,
                            child: Text('Welcome back', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                          ),
                          const SizedBox(height: 8),
                          const Align(
                            alignment: Alignment.centerLeft,
                            child: Text('Sign in to sync your Flutter Create workspace.', style: TextStyle(color: AppColors.textSecondaryDark)),
                          ),
                          const SizedBox(height: 22),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: auth.loading ? null : () => auth.signInWithGoogle(),
                              icon: Image.asset('assets/icons/google_g.png', width: 20, height: 20),
                              label: auth.loading
                                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                  : const Text('Continue with Google'),
                              style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
                            ),
                          ),
                          if (auth.errorMessage != null) ...[
                            const SizedBox(height: 14),
                            Text(auth.errorMessage!, style: const TextStyle(color: AppColors.danger, fontSize: 12), textAlign: TextAlign.center),
                          ],
                          const SizedBox(height: 12),
                          TextButton(
                            onPressed: auth.loading ? null : () => auth.continueAsGuest(),
                            child: const Text('Continue as Guest'),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  const Text('Google OAuth configuration is required before production login.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: AppColors.textSecondaryDark)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
