import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/project_model.dart';
import '../services/project_service.dart';

class NewProjectScreen extends StatefulWidget {
  const NewProjectScreen({super.key});

  @override
  State<NewProjectScreen> createState() => _NewProjectScreenState();
}

class _NewProjectScreenState extends State<NewProjectScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _packageController = TextEditingController(text: 'com.example.myapp');
  final _descController = TextEditingController();
  ProjectTemplate _template = ProjectTemplate.material3;
  bool _creating = false;

  @override
  void dispose() {
    _nameController.dispose();
    _packageController.dispose();
    _descController.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _creating = true);
    try {
      final project = await context.read<ProjectService>().createProject(
            name: _nameController.text.trim(),
            packageName: _packageController.text.trim(),
            description: _descController.text.trim(),
            template: _template,
          );
      if (!mounted) return;
      Navigator.of(context).pop(project);
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('New Flutter Project')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Project Name'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Nama project wajib diisi' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _packageController,
              decoration: const InputDecoration(labelText: 'Package Name'),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Package name wajib diisi';
                if (!RegExp(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$').hasMatch(v.trim())) {
                  return 'Format harus seperti com.example.app';
                }
                return null;
              },
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _descController,
              decoration: const InputDecoration(labelText: 'Description'),
              maxLines: 2,
            ),
            const SizedBox(height: 20),
            Text('Template', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ProjectTemplate.values.map((t) {
                return ChoiceChip(
                  label: Text(t.label),
                  selected: _template == t,
                  onSelected: (_) => setState(() => _template = t),
                );
              }).toList(),
            ),
            const SizedBox(height: 28),
            FilledButton(
              onPressed: _creating ? null : _create,
              child: _creating
                  ? const SizedBox(
                      height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('CREATE PROJECT'),
            ),
          ],
        ),
      ),
    );
  }
}
