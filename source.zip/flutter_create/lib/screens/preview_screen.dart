import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/preview_service.dart';
import '../services/settings_service.dart';
import '../services/widget_inspector_service.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/console_panel.dart';
import '../widgets/preview_panel.dart';

/// Public (non-underscore) State class so other screens — namely
/// EditorScreen's RUN button — can trigger a run in this tab via
/// [PreviewScreenState.triggerRunFromEditor] without a full routing/event
/// bus setup.
class PreviewScreenState extends State<PreviewScreen> {
  static void Function()? triggerRunFromEditor;

  @override
  void initState() {
    super.initState();
    triggerRunFromEditor = _run;
  }

  @override
  void dispose() {
    if (triggerRunFromEditor == _run) triggerRunFromEditor = null;
    super.dispose();
  }

  void _run() {
    final appState = context.read<AppState>();
    final project = appState.currentProject;
    if (project == null) return;
    context.read<PreviewService>().run(project);
  }

  void _reload() {
    final appState = context.read<AppState>();
    final project = appState.currentProject;
    if (project == null) return;
    context.read<PreviewService>().reload(project);
  }

  void _stop() {
    context.read<PreviewService>().stop();
  }

  void _showInspector() {
    final file = context.read<AppState>().activeFile;
    if (file == null) return;
    final nodes = WidgetInspectorService().buildOutline(file.content);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return DraggableScrollableSheet(
          initialChildSize: 0.6,
          expand: false,
          builder: (ctx, scrollController) => Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(14),
                child: Text('Widget Outline (best-effort, read-only)',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 14),
                child: Text(
                  'Dibaca dari source code, bukan dari live inspector visual. Mengubah nilai di sini tidak akan mengubah Dart.',
                  style: TextStyle(fontSize: 11.5, color: AppColors.textSecondaryDark),
                ),
              ),
              const Divider(height: 20),
              Expanded(
                child: nodes.isEmpty
                    ? const Center(child: Text('Tidak ada widget terdeteksi.'))
                    : ListView.builder(
                        controller: scrollController,
                        itemCount: nodes.length,
                        itemBuilder: (ctx, i) {
                          final n = nodes[i];
                          return Padding(
                            padding: EdgeInsets.only(left: 14.0 + n.depth * 14, right: 14, bottom: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('${n.widgetName}  (baris ${n.line})',
                                    style: const TextStyle(
                                        fontFamily: 'monospace', color: AppColors.accent)),
                                if (n.properties.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 2, left: 8),
                                    child: Text(
                                      n.properties.entries.map((e) => '${e.key}: ${e.value}').join('  •  '),
                                      style: const TextStyle(
                                          fontSize: 11.5, color: AppColors.textSecondaryDark),
                                    ),
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final preview = context.watch<PreviewService>();
    final settings = context.watch<SettingsService>();
    final project = appState.currentProject;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Preview'),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_tree_outlined),
            tooltip: 'Widget Outline',
            onPressed: appState.activeFile == null ? null : _showInspector,
          ),
          IconButton(
            icon: const Icon(Icons.play_arrow_rounded, color: AppColors.run),
            tooltip: 'RUN',
            onPressed: project == null ? null : _run,
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppColors.accentAlt),
            tooltip: preview.isHotReloadCapable ? 'HOT RELOAD' : 'RESTART PREVIEW',
            onPressed: project == null ? null : _reload,
          ),
          IconButton(
            icon: const Icon(Icons.stop_rounded, color: AppColors.danger),
            tooltip: 'STOP',
            onPressed: _stop,
          ),
        ],
      ),
      body: project == null
          ? const _NoProjectPlaceholder()
          : Column(
              children: [
                Expanded(
                  child: _buildBody(preview, settings),
                ),
                ConsolePanel(messages: preview.consoleMessages, height: 160),
              ],
            ),
    );
  }

  Widget _buildBody(PreviewService preview, SettingsService settings) {
    switch (preview.state) {
      case PreviewState.idle:
        return const _StatusPlaceholder(
          icon: Icons.play_circle_outline,
          text: 'Tekan RUN untuk menjalankan preview Flutter.',
        );
      case PreviewState.analyzing:
        return const _StatusPlaceholder(
          icon: Icons.search,
          text: 'Menganalisis kode...',
          loading: true,
        );
      case PreviewState.starting:
        return const _StatusPlaceholder(
          icon: Icons.cloud_upload_outlined,
          text: 'Mengirim project & menyiapkan preview...',
          loading: true,
        );
      case PreviewState.reloading:
        return PreviewPanel(previewUrl: preview.session?.previewUrl);
      case PreviewState.running:
        return PreviewPanel(previewUrl: preview.session?.previewUrl);
      case PreviewState.error:
        return const _StatusPlaceholder(
          icon: Icons.error_outline,
          text: 'RUN FAILED. Lihat detail error di console di bawah.',
          isError: true,
        );
      case PreviewState.unavailable:
        return _StatusPlaceholder(
          icon: Icons.link_off,
          text: settings.isBuildServerConfigured
              ? 'Build Server tidak dapat dihubungi.'
              : 'Flutter runtime belum tersedia pada environment ini.\nHubungkan Build Server di Settings > Build untuk preview Flutter yang sesungguhnya.',
        );
    }
  }
}

class PreviewScreen extends StatefulWidget {
  const PreviewScreen({super.key});

  @override
  State<PreviewScreen> createState() => PreviewScreenState();
}

class _NoProjectPlaceholder extends StatelessWidget {
  const _NoProjectPlaceholder();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Belum ada project aktif.\nBuka project terlebih dahulu dari tab Projects.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.textSecondaryDark),
        ),
      ),
    );
  }
}

class _StatusPlaceholder extends StatelessWidget {
  final IconData icon;
  final String text;
  final bool loading;
  final bool isError;

  const _StatusPlaceholder({
    required this.icon,
    required this.text,
    this.loading = false,
    this.isError = false,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (loading)
              const CircularProgressIndicator()
            else
              Icon(icon, size: 40, color: isError ? AppColors.danger : AppColors.textSecondaryDark),
            const SizedBox(height: 14),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(color: isError ? AppColors.danger : AppColors.textSecondaryDark),
            ),
          ],
        ),
      ),
    );
  }
}
