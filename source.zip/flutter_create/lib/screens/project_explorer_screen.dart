import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/file_model.dart';
import '../models/project_model.dart';
import '../services/project_service.dart';
import '../state/app_state.dart';
import '../widgets/app_shell.dart';
import '../widgets/file_tree.dart';
import 'pubspec_screen.dart';

class ProjectExplorerScreen extends StatefulWidget {
  final ProjectModel project;
  const ProjectExplorerScreen({super.key, required this.project});

  @override
  State<ProjectExplorerScreen> createState() => _ProjectExplorerScreenState();
}

class _ProjectExplorerScreenState extends State<ProjectExplorerScreen> {
  String _search = '';

  void _openFile(FileModel file) {
    if (file.isPubspec) {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => PubspecScreen(project: widget.project)),
      );
      return;
    }
    if (file.isDart) {
      context.read<AppState>().openFile(file);
      Navigator.of(context).pop();
      AppShellController.of(context)?.goTo(2);
      return;
    }
    context.read<AppState>().openFile(file);
  }

  Future<void> _createFile() async {
    final controller = TextEditingController();
    final path = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Create file'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'lib/new_file.dart'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, controller.text.trim()),
              child: const Text('Create')),
        ],
      ),
    );
    if (path == null || path.isEmpty) return;
    final name = path.contains('/') ? path.split('/').last : path;
    final file = FileModel(
      id: '${DateTime.now().microsecondsSinceEpoch}_$name',
      name: name,
      path: path,
      content: '',
    );
    widget.project.upsertFile(file);
    await context.read<ProjectService>().saveProject(widget.project);
    if (!mounted) return;
    setState(() {});
  }

  Future<void> _createFolder() async {
    final controller = TextEditingController();
    final folderPath = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Create folder'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'lib/widgets'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, controller.text.trim()),
              child: const Text('Create')),
        ],
      ),
    );
    if (folderPath == null || folderPath.isEmpty) return;
    // A folder is represented by a hidden placeholder file so it shows up
    // in the tree even before it contains real files.
    final placeholder = FileModel(
      id: '${DateTime.now().microsecondsSinceEpoch}_.gitkeep',
      name: '.gitkeep',
      path: '$folderPath/.gitkeep',
      content: '',
    );
    widget.project.upsertFile(placeholder);
    await context.read<ProjectService>().saveProject(widget.project);
    if (!mounted) return;
    setState(() {});
  }

  Future<void> _rename(FileModel file) async {
    final controller = TextEditingController(text: file.name);
    final newName = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename'),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, controller.text.trim()),
              child: const Text('Rename')),
        ],
      ),
    );
    if (newName == null || newName.isEmpty || newName == file.name) return;
    final dir = file.directory;
    final newPath = dir.isEmpty ? newName : '$dir/$newName';
    widget.project.removeFile(file.path);
    widget.project.upsertFile(file.copyWith(name: newName, path: newPath));
    await context.read<ProjectService>().saveProject(widget.project);
    if (!mounted) return;
    setState(() {});
  }

  Future<void> _delete(FileModel file) async {
    widget.project.removeFile(file.path);
    await context.read<ProjectService>().saveProject(widget.project);
    if (!mounted) return;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final visibleFiles = widget.project.files
        .where((f) => f.name != '.gitkeep')
        .where((f) => _search.isEmpty || f.name.toLowerCase().contains(_search.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.project.name),
        actions: [
          IconButton(icon: const Icon(Icons.create_new_folder_outlined), onPressed: _createFolder),
          IconButton(icon: const Icon(Icons.note_add_outlined), onPressed: _createFile),
          IconButton(icon: const Icon(Icons.refresh), onPressed: () => setState(() {})),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search files'),
              onChanged: (v) => setState(() => _search = v),
            ),
          ),
          Expanded(
            child: FileTree(
              files: visibleFiles,
              onOpenFile: _openFile,
              onRename: _rename,
              onDelete: _delete,
            ),
          ),
        ],
      ),
    );
  }
}
