import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/project_model.dart';
import '../services/project_service.dart';
import '../services/storage_service.dart';
import '../state/app_state.dart';
import '../widgets/empty_state.dart';
import '../widgets/project_card.dart';
import 'new_project_screen.dart';
import 'project_explorer_screen.dart';

class ProjectsScreen extends StatefulWidget {
  const ProjectsScreen({super.key});

  @override
  State<ProjectsScreen> createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen> {
  String _query = '';

  Future<void> _openProject(ProjectModel project) async {
    context.read<AppState>().openProject(project);
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProjectExplorerScreen(project: project)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final projectService = context.watch<ProjectService>();
    final filtered = projectService.projects
        .where((p) => p.name.toLowerCase().contains(_query.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Projects'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () async {
              final project = await Navigator.of(context).push<ProjectModel>(
                MaterialPageRoute(builder: (_) => const NewProjectScreen()),
              );
              if (project != null && mounted) await _openProject(project);
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => projectService.refresh(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Search projects',
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
            const SizedBox(height: 14),
            if (projectService.loading)
              const Padding(
                padding: EdgeInsets.all(32),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (filtered.isEmpty)
              const EmptyState(
                icon: Icons.folder_off_outlined,
                title: 'No recent projects',
                subtitle: 'Buat project baru untuk mulai.',
              )
            else
              ...filtered.map((p) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: ProjectCard(
                      project: p,
                      onTap: () => _openProject(p),
                      onDelete: () => projectService.deleteProject(p.id),
                      onExport: () async {
                        try {
                          await projectService.exportProject(p);
                          if (!mounted) return;
                          ScaffoldMessenger.of(context)
                              .showSnackBar(const SnackBar(content: Text('Project exported.')));
                        } on StorageException catch (e) {
                          if (!mounted) return;
                          ScaffoldMessenger.of(context)
                              .showSnackBar(SnackBar(content: Text(e.message)));
                        }
                      },
                    ),
                  )),
          ],
        ),
      ),
    );
  }
}
