import 'package:flutter/material.dart';
import 'package:yaml/yaml.dart';

import '../models/project_model.dart';
import '../theme/app_theme.dart';

/// Read-only pubspec viewer, per spec: "Untuk versi pertama boleh
/// read-only." The architecture (PubspecViewModel below) is structured so
/// add/remove/update-dependency actions can be wired to the UI later
/// without changing how this screen parses/display the data.
class PubspecScreen extends StatelessWidget {
  final ProjectModel project;
  const PubspecScreen({super.key, required this.project});

  @override
  Widget build(BuildContext context) {
    final file = project.pubspecFile;
    if (file == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('pubspec.yaml')),
        body: const Center(child: Text('pubspec.yaml tidak ditemukan pada project ini.')),
      );
    }

    Map<dynamic, dynamic>? doc;
    String? parseError;
    try {
      doc = loadYaml(file.content) as Map<dynamic, dynamic>?;
    } catch (e) {
      parseError = 'Gagal membaca pubspec.yaml: $e';
    }

    return Scaffold(
      appBar: AppBar(title: const Text('pubspec.yaml')),
      body: parseError != null || doc == null
          ? Padding(
              padding: const EdgeInsets.all(20),
              child: Text(parseError ?? 'pubspec.yaml kosong atau tidak valid.'),
            )
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _Field('Project Name', doc['name']?.toString() ?? '-'),
                _Field('Version', doc['version']?.toString() ?? '-'),
                _Field('Environment',
                    (doc['environment'] as Map?)?.entries.map((e) => '${e.key}: ${e.value}').join('\n') ?? '-'),
                const SizedBox(height: 8),
                Text('Dependencies', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                _DependencyList(deps: doc['dependencies'] as Map?),
                const SizedBox(height: 20),
                Text('Dev Dependencies', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                _DependencyList(deps: doc['dev_dependencies'] as Map?),
                const SizedBox(height: 24),
                const Text(
                  'Read-only pada versi ini. Add/remove/update dependency akan tersedia di versi berikutnya.',
                  style: TextStyle(color: AppColors.textSecondaryDark, fontSize: 12.5),
                ),
              ],
            ),
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final String value;
  const _Field(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(color: AppColors.textSecondaryDark, fontSize: 12.5)),
          const SizedBox(height: 3),
          Text(value, style: const TextStyle(fontFamily: 'monospace', fontSize: 14)),
        ],
      ),
    );
  }
}

class _DependencyList extends StatelessWidget {
  final Map? deps;
  const _DependencyList({required this.deps});

  @override
  Widget build(BuildContext context) {
    if (deps == null || deps!.isEmpty) {
      return const Text('- none -', style: TextStyle(color: AppColors.textSecondaryDark));
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: deps!.entries.map((e) {
            final value = e.value is Map ? 'sdk: flutter' : e.value.toString();
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  const Icon(Icons.circle, size: 6, color: AppColors.accent),
                  const SizedBox(width: 8),
                  Text('${e.key}: ', style: const TextStyle(fontFamily: 'monospace')),
                  Text(value,
                      style: const TextStyle(
                          fontFamily: 'monospace', color: AppColors.textSecondaryDark)),
                ],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
