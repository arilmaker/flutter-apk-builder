import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import '../services/settings_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _serverController;
  late TextEditingController _locationController;
  String _version = '';

  @override
  void initState() {
    super.initState();
    final settings = context.read<SettingsService>();
    _serverController = TextEditingController(text: settings.buildServerUrl);
    _locationController = TextEditingController(text: settings.defaultProjectLocation);
    PackageInfo.fromPlatform().then((info) {
      if (mounted) setState(() => _version = '${info.version}+${info.buildNumber}');
    });
  }

  @override
  void dispose() {
    _serverController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          const _SectionHeader('Appearance'),
          SwitchListTile(
            title: const Text('Dark Mode'),
            value: settings.darkMode,
            onChanged: settings.setDarkMode,
          ),
          ListTile(
            title: const Text('Editor Font Size'),
            subtitle: Slider(
              value: settings.editorFontSize,
              min: 10,
              max: 22,
              divisions: 12,
              label: settings.editorFontSize.toStringAsFixed(0),
              onChanged: settings.setEditorFontSize,
            ),
          ),
          ListTile(
            title: const Text('Editor Font Family'),
            trailing: DropdownButton<String>(
              value: settings.editorFontFamily,
              items: const [
                DropdownMenuItem(value: 'monospace', child: Text('monospace')),
                DropdownMenuItem(value: 'Courier', child: Text('Courier')),
              ],
              onChanged: (v) {
                if (v != null) settings.setEditorFontFamily(v);
              },
            ),
          ),
          const Divider(),
          const _SectionHeader('Editor'),
          SwitchListTile(
            title: const Text('Auto Save'),
            value: settings.autoSave,
            onChanged: settings.setAutoSave,
          ),
          SwitchListTile(
            title: const Text('Line Numbers'),
            value: settings.showLineNumbers,
            onChanged: settings.setShowLineNumbers,
          ),
          SwitchListTile(
            title: const Text('Word Wrap'),
            value: settings.wordWrap,
            onChanged: settings.setWordWrap,
          ),
          const Divider(),
          const _SectionHeader('Project'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _locationController,
              decoration: const InputDecoration(labelText: 'Default Location'),
              onSubmitted: settings.setDefaultProjectLocation,
              onTapOutside: (_) => settings.setDefaultProjectLocation(_locationController.text),
            ),
          ),
          const Divider(),
          const _SectionHeader('Build'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _serverController,
              decoration: const InputDecoration(
                labelText: 'Build Server URL',
                hintText: 'https://your-build-server.example.com',
              ),
              onSubmitted: settings.setBuildServerUrl,
              onTapOutside: (_) => settings.setBuildServerUrl(_serverController.text),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            child: Text(
              settings.isBuildServerConfigured
                  ? 'Terhubung ke: ${settings.buildServerUrl}'
                  : 'Belum diatur — fitur RUN, PREVIEW, dan BUILD APK memerlukan Build Server yang valid.',
              style: TextStyle(
                fontSize: 12,
                color: settings.isBuildServerConfigured ? AppColors.run : AppColors.warn,
              ),
            ),
          ),
          const Divider(),
          const _SectionHeader('About'),
          const ListTile(title: Text('Flutter Create')),
          ListTile(title: const Text('Version'), trailing: Text(_version)),
          const ListTile(title: Text('Developer'), trailing: Text('Flutter Create Team')),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: AppColors.accent,
          letterSpacing: 0.6,
        ),
      ),
    );
  }
}
