import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/saas_ui.dart';

class TeamScreen extends StatefulWidget {
  const TeamScreen({super.key});

  @override
  State<TeamScreen> createState() => _TeamScreenState();
}

class _TeamScreenState extends State<TeamScreen> {
  final List<_Member> _members = const [
    _Member('You', 'Owner', 'you@example.com', Icons.admin_panel_settings_rounded, AppColors.accentAlt),
    _Member('Alex', 'Developer', 'alex@example.com', Icons.code_rounded, AppColors.accent),
    _Member('Naya', 'Designer', 'naya@example.com', Icons.palette_rounded, Colors.purpleAccent),
  ];

  void _invite() {
    showDialog<void>(
      context: context,
      builder: (context) {
        final controller = TextEditingController();
        return AlertDialog(
          title: const Text('Invite teammate'),
          content: TextField(controller: controller, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email address')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Send invite')),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Team'),
        actions: [
          FilledButton.icon(onPressed: _invite, icon: const Icon(Icons.person_add_alt_1_rounded, size: 17), label: const Text('Invite')),
          const SizedBox(width: 12),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
        children: [
          const Text('Workspace members', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Collaborate on Flutter projects from one workspace.', style: TextStyle(color: AppColors.textSecondaryDark)),
          const SizedBox(height: 22),
          const SaaSUpgradeCard(),
          const SizedBox(height: 18),
          SaaSPanel(
            title: 'Members',
            subtitle: '${_members.length} active members',
            action: const SaaSStatusPill(text: 'Workspace active', color: AppColors.accent, icon: Icons.circle),
            child: Column(
              children: _members.map((member) => _MemberTile(member: member)).toList(),
            ),
          ),
          const SizedBox(height: 18),
          const SaaSPanel(
            title: 'Roles & permissions',
            subtitle: 'Control access to your workspace.',
            child: Column(
              children: [
                _PermissionRow(icon: Icons.admin_panel_settings_rounded, title: 'Owner', subtitle: 'Full access to billing, members and projects.'),
                _PermissionRow(icon: Icons.code_rounded, title: 'Developer', subtitle: 'Create, edit, preview and build projects.'),
                _PermissionRow(icon: Icons.visibility_rounded, title: 'Viewer', subtitle: 'Read-only access to projects and previews.'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Member {
  final String name;
  final String role;
  final String email;
  final IconData icon;
  final Color color;
  const _Member(this.name, this.role, this.email, this.icon, this.color);
}

class _MemberTile extends StatelessWidget {
  final _Member member;
  const _MemberTile({required this.member});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 5),
      leading: CircleAvatar(backgroundColor: member.color.withValues(alpha: .12), child: Icon(member.icon, color: member.color, size: 18)),
      title: Text(member.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
      subtitle: Text(member.email, style: const TextStyle(fontSize: 10, color: AppColors.textSecondaryDark)),
      trailing: SaaSStatusPill(text: member.role, color: member.color, icon: Icons.badge_outlined),
    );
  }
}

class _PermissionRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _PermissionRow({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AppColors.accentAlt, size: 19),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(fontSize: 10.5, color: AppColors.textSecondaryDark))])),
        ],
      ),
    );
  }
}
