import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../theme/app_theme.dart';

class VideoScreen extends StatefulWidget {
  const VideoScreen({super.key});

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  late final VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/videos/flutter_create_intro.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final initialized = _controller.value.isInitialized;
    return Scaffold(
      appBar: AppBar(title: const Text('Flutter Create Video')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            clipBehavior: Clip.antiAlias,
            child: AspectRatio(
              aspectRatio: initialized ? _controller.value.aspectRatio : 16 / 9,
              child: initialized
                  ? Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        VideoPlayer(_controller),
                        VideoProgressIndicator(_controller, allowScrubbing: true, padding: const EdgeInsets.all(8)),
                        Center(
                          child: IconButton.filled(
                            iconSize: 34,
                            onPressed: () => setState(() {
                              _controller.value.isPlaying ? _controller.pause() : _controller.play();
                            }),
                            icon: Icon(_controller.value.isPlaying ? Icons.pause : Icons.play_arrow),
                          ),
                        ),
                      ],
                    )
                  : const Center(child: CircularProgressIndicator()),
            ),
          ),
          const SizedBox(height: 18),
          Text('Welcome to Flutter Create', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Text('Video screen untuk onboarding, tutorial, atau showcase fitur editor dan Flutter Preview.', style: TextStyle(color: AppColors.textSecondaryDark)),
        ],
      ),
    );
  }
}
