import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService extends ChangeNotifier {
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: const ['email', 'profile'],
  );

  GoogleSignInAccount? user;
  bool guestMode = false;
  bool loading = false;
  String? errorMessage;

  bool get isSignedIn => user != null || guestMode;

  Future<void> restoreSession() async {
    try {
      user = await _googleSignIn.signInSilently();
      guestMode = false;
    } catch (_) {
      user = null;
      guestMode = false;
    }
    notifyListeners();
  }

  Future<bool> signInWithGoogle() async {
    if (kIsWeb) {
      errorMessage = 'Google Sign-In mobile flow hanya dikonfigurasi untuk Android.';
      notifyListeners();
      return false;
    }
    loading = true;
    errorMessage = null;
    notifyListeners();
    try {
      final account = await _googleSignIn.signIn();
      if (account == null) {
        errorMessage = 'Login dibatalkan.';
        return false;
      }
      user = account;
      guestMode = false;
      return true;
    } catch (e) {
      errorMessage = 'Google Sign-In gagal. Pastikan OAuth Android sudah dikonfigurasi.\n$e';
      user = null;
      guestMode = false;
      return false;
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> continueAsGuest() async {
    user = null;
    guestMode = true;
    errorMessage = null;
    notifyListeners();
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    user = null;
    guestMode = false;
    errorMessage = null;
    notifyListeners();
  }
}
