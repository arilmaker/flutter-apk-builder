import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../models/build_job.dart';
import '../models/project_model.dart';
import 'settings_service.dart';

/// Thrown for any Build Server communication failure. The message is always
/// safe to show directly to the user (no stack traces, no fabricated
/// success text).
class BuildServerException implements Exception {
  final String message;
  BuildServerException(this.message);
  @override
  String toString() => message;
}

/// Talks to an external Build Server over HTTP, per the REST contract:
///
///   POST /api/project/upload
///   POST /api/project/build
///   GET  /api/project/build/{id}
///   GET  /api/project/download/{id}
///   POST /api/project/preview          (compiles to a live preview session)
///   POST /api/project/preview/{id}/reload
///
/// The server URL is never hardcoded — it must be configured by the user in
/// Settings. Because real Flutter/Android/Gradle toolchains cannot run
/// inside a sandboxed Android app process, this service is how Flutter
/// Create honestly delegates "RUN" and "BUILD APK" to a real toolchain
/// instead of faking the result on-device.
class BuildServerService {
  final SettingsService settings;
  final http.Client _client;

  BuildServerService(this.settings, {http.Client? client})
      : _client = client ?? http.Client();

  Uri _uri(String path) {
    final base = settings.buildServerUrl.trim();
    if (base.isEmpty) {
      throw BuildServerException(
          'Build server belum dikonfigurasi. Atur URL-nya di Settings > Build.');
    }
    final normalizedBase = base.endsWith('/') ? base.substring(0, base.length - 1) : base;
    return Uri.parse('$normalizedBase$path');
  }

  Map<String, dynamic> _projectPayload(ProjectModel project) => {
        'id': project.id,
        'name': project.name,
        'packageName': project.packageName,
        'files': project.files
            .map((f) => {'path': f.path, 'content': f.content})
            .toList(),
      };

  /// Uploads the full project source. Returns an `uploadId` the server
  /// uses to reference this snapshot in subsequent calls.
  Future<String> uploadProject(ProjectModel project) async {
    final uri = _uri('/api/project/upload');
    try {
      final res = await _client
          .post(uri,
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode(_projectPayload(project)))
          .timeout(const Duration(seconds: 30));
      if (res.statusCode != 200 && res.statusCode != 201) {
        throw BuildServerException(
            'Upload gagal (HTTP ${res.statusCode}): ${res.body}');
      }
      final json = jsonDecode(res.body) as Map<String, dynamic>;
      final uploadId = json['uploadId'] as String?;
      if (uploadId == null) {
        throw BuildServerException('Respons server tidak berisi uploadId.');
      }
      return uploadId;
    } on SocketException {
      throw BuildServerException('Tidak dapat terhubung ke Build Server.');
    } on BuildServerException {
      rethrow;
    } catch (e) {
      throw BuildServerException('Upload gagal: $e');
    }
  }

  /// Requests a compiled preview session (e.g. the server builds the
  /// project as Flutter Web inside an isolated container and returns a URL
  /// Flutter Create can embed in a WebView).
  Future<PreviewSession> requestPreview(String uploadId) async {
    final uri = _uri('/api/project/preview');
    try {
      final res = await _client
          .post(uri,
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'uploadId': uploadId}))
          .timeout(const Duration(seconds: 60));
      if (res.statusCode != 200) {
        throw BuildServerException(
            'Preview gagal dibuat (HTTP ${res.statusCode}): ${res.body}');
      }
      final json = jsonDecode(res.body) as Map<String, dynamic>;
      final url = json['previewUrl'] as String?;
      final id = json['sessionId'] as String?;
      if (url == null || id == null) {
        throw BuildServerException('Respons preview tidak lengkap dari server.');
      }
      return PreviewSession(
        id: id,
        previewUrl: url,
        supportsHotReload: json['hotReload'] == true,
      );
    } on SocketException {
      throw BuildServerException('Tidak dapat terhubung ke Build Server.');
    } on BuildServerException {
      rethrow;
    } catch (e) {
      throw BuildServerException('Preview gagal: $e');
    }
  }

  Future<void> reloadPreview(String sessionId) async {
    final uri = _uri('/api/project/preview/$sessionId/reload');
    try {
      final res = await _client.post(uri).timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) {
        throw BuildServerException('Reload gagal (HTTP ${res.statusCode}).');
      }
    } on SocketException {
      throw BuildServerException('Tidak dapat terhubung ke Build Server.');
    }
  }

  Future<void> stopPreview(String sessionId) async {
    final uri = _uri('/api/project/preview/$sessionId');
    try {
      await _client.delete(uri).timeout(const Duration(seconds: 15));
    } catch (_) {
      // Best-effort cleanup; not fatal to the UI flow.
    }
  }

  Future<String> startBuild(String uploadId, BuildType type) async {
    final uri = _uri('/api/project/build');
    try {
      final res = await _client
          .post(uri,
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'uploadId': uploadId,
                'type': type.endpointValue,
              }))
          .timeout(const Duration(seconds: 30));
      if (res.statusCode != 200 && res.statusCode != 202) {
        throw BuildServerException(
            'Build gagal dimulai (HTTP ${res.statusCode}): ${res.body}');
      }
      final json = jsonDecode(res.body) as Map<String, dynamic>;
      final buildId = json['buildId'] as String?;
      if (buildId == null) {
        throw BuildServerException('Respons server tidak berisi buildId.');
      }
      return buildId;
    } on SocketException {
      throw BuildServerException('Tidak dapat terhubung ke Build Server.');
    } on BuildServerException {
      rethrow;
    } catch (e) {
      throw BuildServerException('Build gagal dimulai: $e');
    }
  }

  Future<BuildJob> getBuildStatus(String buildId, BuildType type) async {
    final uri = _uri('/api/project/build/$buildId');
    try {
      final res = await _client.get(uri).timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) {
        throw BuildServerException('Gagal mengambil status build (HTTP ${res.statusCode}).');
      }
      final json = jsonDecode(res.body) as Map<String, dynamic>;
      final statusStr = json['status'] as String? ?? 'building';
      final status = _statusFromString(statusStr);
      return BuildJob(
        id: buildId,
        type: type,
        status: status,
        progress: (json['progress'] as num?)?.toDouble() ?? 0,
        logs: (json['logs'] as List<dynamic>? ?? []).map((e) => e.toString()).toList(),
        downloadUrl: json['downloadUrl'] as String?,
        error: json['error'] as String?,
      );
    } on SocketException {
      throw BuildServerException('Tidak dapat terhubung ke Build Server.');
    } on BuildServerException {
      rethrow;
    } catch (e) {
      throw BuildServerException('Gagal mengambil status build: $e');
    }
  }

  BuildStatus _statusFromString(String s) {
    switch (s) {
      case 'queued':
        return BuildStatus.queued;
      case 'building':
        return BuildStatus.building;
      case 'success':
        return BuildStatus.success;
      case 'failed':
        return BuildStatus.failed;
      default:
        return BuildStatus.building;
    }
  }

  /// Downloads the finished artifact (APK/AAB) to a local temp file and
  /// returns its path. The caller decides where to move/share it from there.
  Future<String> downloadBuild(String buildId, String saveToPath) async {
    final uri = _uri('/api/project/download/$buildId');
    try {
      final res = await _client.get(uri).timeout(const Duration(minutes: 5));
      if (res.statusCode != 200) {
        throw BuildServerException('Download gagal (HTTP ${res.statusCode}).');
      }
      final file = File(saveToPath);
      await file.writeAsBytes(res.bodyBytes);
      return saveToPath;
    } on SocketException {
      throw BuildServerException('Tidak dapat terhubung ke Build Server.');
    } on BuildServerException {
      rethrow;
    } catch (e) {
      throw BuildServerException('Download gagal: $e');
    }
  }

  /// Optional: ask the server to run the real `dart analyze` toolchain for
  /// full semantic analysis (beyond the local heuristic analyzer).
  Future<List<Map<String, dynamic>>> remoteAnalyze(String uploadId) async {
    final uri = _uri('/api/project/analyze');
    try {
      final res = await _client
          .post(uri,
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'uploadId': uploadId}))
          .timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) {
        throw BuildServerException('Analisis remote gagal (HTTP ${res.statusCode}).');
      }
      final json = jsonDecode(res.body) as Map<String, dynamic>;
      return (json['issues'] as List<dynamic>? ?? [])
          .cast<Map<String, dynamic>>();
    } on SocketException {
      throw BuildServerException('Tidak dapat terhubung ke Build Server.');
    }
  }
}
