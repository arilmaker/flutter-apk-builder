import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import '../models/build_job.dart';
import '../models/project_model.dart';
import 'build_server_service.dart';

/// Coordinates the Build screen's Debug/Release/Bundle flow against the
/// remote Build Server: upload -> start build -> poll status -> download.
class BuildService extends ChangeNotifier {
  final BuildServerService _server;
  BuildJob? currentJob;
  Timer? _pollTimer;

  BuildService(this._server);

  Future<void> startBuild(ProjectModel project, BuildType type) async {
    currentJob = BuildJob(id: 'pending', type: type, status: BuildStatus.uploading);
    notifyListeners();

    try {
      final uploadId = await _server.uploadProject(project);
      currentJob = currentJob!.copyWith(status: BuildStatus.queued);
      notifyListeners();

      final buildId = await _server.startBuild(uploadId, type);
      currentJob = BuildJob(id: buildId, type: type, status: BuildStatus.queued);
      notifyListeners();

      _pollTimer?.cancel();
      _pollTimer = Timer.periodic(const Duration(seconds: 2), (_) => _poll(buildId, type));
    } on BuildServerException catch (e) {
      currentJob = currentJob?.copyWith(status: BuildStatus.failed, error: e.message);
      notifyListeners();
    }
  }

  Future<void> _poll(String buildId, BuildType type) async {
    try {
      final job = await _server.getBuildStatus(buildId, type);
      currentJob = job;
      notifyListeners();
      if (job.status == BuildStatus.success || job.status == BuildStatus.failed) {
        _pollTimer?.cancel();
      }
    } on BuildServerException catch (e) {
      currentJob = currentJob?.copyWith(status: BuildStatus.failed, error: e.message);
      _pollTimer?.cancel();
      notifyListeners();
    }
  }

  Future<String?> downloadCurrentBuild() async {
    final job = currentJob;
    if (job == null || job.status != BuildStatus.success) return null;
    final dir = await getApplicationDocumentsDirectory();
    final ext = job.type == BuildType.bundle ? 'aab' : 'apk';
    final savePath = '${dir.path}/build_${job.id}.$ext';
    return _server.downloadBuild(job.id, savePath);
  }

  void reset() {
    _pollTimer?.cancel();
    currentJob = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }
}
