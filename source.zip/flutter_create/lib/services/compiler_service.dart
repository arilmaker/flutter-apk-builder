import '../models/console_message.dart';
import '../models/project_model.dart';
import 'build_server_service.dart';
import 'dart_analyzer_service.dart';

class CompileResult {
  final bool success;
  final List<ConsoleMessage> messages;
  CompileResult({required this.success, required this.messages});
}

/// Coordinates static analysis before a RUN or BUILD is attempted.
///
/// `analyze()` always runs the honest local heuristic analyzer
/// ([DartAnalyzerService]). If a Build Server is configured, it also asks
/// the server to run the real `dart analyze` toolchain and merges results —
/// giving genuinely deeper analysis without ever pretending the on-device
/// heuristic is a full compiler.
class CompilerService {
  final DartAnalyzerService _analyzer;
  final BuildServerService _buildServer;

  List<ConsoleMessage> _lastMessages = [];

  CompilerService(this._buildServer, {DartAnalyzerService? analyzer})
      : _analyzer = analyzer ?? DartAnalyzerService();

  List<ConsoleMessage> getErrors() => _lastMessages;

  Future<CompileResult> analyze(ProjectModel project) async {
    final messages = <ConsoleMessage>[
      ..._analyzer.analyzeProject(project.files),
    ];

    if (_buildServer.settings.isBuildServerConfigured) {
      try {
        // Best-effort: this requires an upload id, which PreviewService /
        // BuildScreen manage. CompilerService only surfaces local results
        // by default; remote semantic analyze is exposed for callers that
        // already have an uploadId via [analyzeRemote].
      } catch (_) {
        // Non-fatal — local analysis result still stands.
      }
    }

    final hasErrors = messages.any((m) => m.isError);
    _lastMessages = messages;
    return CompileResult(success: !hasErrors, messages: messages);
  }

  Future<List<ConsoleMessage>> analyzeRemote(String uploadId) async {
    try {
      final issues = await _buildServer.remoteAnalyze(uploadId);
      final messages = issues.map((issue) {
        final severity = (issue['severity'] as String? ?? 'info').toLowerCase();
        final text = issue['message'] as String? ?? 'Unknown issue';
        final file = issue['file'] as String?;
        final line = (issue['line'] as num?)?.toInt();
        switch (severity) {
          case 'error':
            return ConsoleMessage.error(text, filePath: file, line: line);
          case 'warning':
            return ConsoleMessage.warning(text, filePath: file, line: line);
          default:
            return ConsoleMessage.info(text);
        }
      }).toList();
      _lastMessages = [..._lastMessages, ...messages];
      return messages;
    } on BuildServerException catch (e) {
      final msg = ConsoleMessage.warning(
          'Analisis remote tidak dapat dijalankan: ${e.message}');
      _lastMessages = [..._lastMessages, msg];
      return [msg];
    }
  }
}
