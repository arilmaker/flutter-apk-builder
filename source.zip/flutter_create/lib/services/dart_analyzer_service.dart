import '../models/console_message.dart';
import '../models/file_model.dart';

/// A lightweight, honest, on-device structural analyzer.
///
/// It does NOT perform full Dart semantic analysis (type checking, unresolved
/// symbol detection, etc.) — that requires the real Dart analyzer/SDK, which
/// this app does not embed. What it DOES do is real: bracket/paren/quote
/// balance checking and a handful of structural sanity checks, all computed
/// directly from the source text, never fabricated.
///
/// For full semantic analysis, [CompilerService] additionally calls the
/// configured Build Server (when available), which can run the real `dart
/// analyze` toolchain server-side.
class DartAnalyzerService {
  List<ConsoleMessage> analyzeFile(FileModel file) {
    if (!file.isDart) return [];
    final messages = <ConsoleMessage>[];
    messages.addAll(_checkBalance(file));
    messages.addAll(_checkBasicStructure(file));
    return messages;
  }

  List<ConsoleMessage> analyzeProject(List<FileModel> files) {
    final messages = <ConsoleMessage>[];
    final hasMain = files.any((f) => f.path == 'lib/main.dart');
    if (!hasMain) {
      messages.add(ConsoleMessage.error(
        "lib/main.dart tidak ditemukan pada project.",
      ));
    }
    for (final f in files.where((f) => f.isDart)) {
      messages.addAll(analyzeFile(f));
    }
    return messages;
  }

  List<ConsoleMessage> _checkBalance(FileModel file) {
    final messages = <ConsoleMessage>[];
    final pairs = {'(': ')', '[': ']', '{': '}'};
    final closers = {')': '(', ']': '[', '}': '{'};
    final stack = <_OpenBracket>[];

    final lines = file.content.split('\n');
    bool inString = false;
    String? stringQuote;
    bool inLineComment;
    bool inBlockComment = false;

    for (var lineIndex = 0; lineIndex < lines.length; lineIndex++) {
      final line = lines[lineIndex];
      inLineComment = false;
      for (var col = 0; col < line.length; col++) {
        if (inLineComment) break;
        final ch = line[col];
        final next = col + 1 < line.length ? line[col + 1] : '';

        if (inBlockComment) {
          if (ch == '*' && next == '/') {
            inBlockComment = false;
            col++;
          }
          continue;
        }
        if (inString) {
          if (ch == '\\') {
            col++; // skip escaped char
            continue;
          }
          if (ch == stringQuote) {
            inString = false;
            stringQuote = null;
          }
          continue;
        }

        if (ch == '/' && next == '/') {
          inLineComment = true;
          continue;
        }
        if (ch == '/' && next == '*') {
          inBlockComment = true;
          col++;
          continue;
        }
        if (ch == "'" || ch == '"') {
          inString = true;
          stringQuote = ch;
          continue;
        }
        if (pairs.containsKey(ch)) {
          stack.add(_OpenBracket(ch, lineIndex + 1));
        } else if (closers.containsKey(ch)) {
          if (stack.isEmpty || stack.last.char != closers[ch]) {
            messages.add(ConsoleMessage.error(
              "Tanda kurung tidak seimbang: ditemukan '$ch' tanpa pasangan pembuka yang sesuai.",
              filePath: file.path,
              line: lineIndex + 1,
            ));
          } else {
            stack.removeLast();
          }
        }
      }
    }

    if (inString) {
      messages.add(ConsoleMessage.error(
        'Ada string yang tidak ditutup (missing closing quote).',
        filePath: file.path,
      ));
    }
    if (inBlockComment) {
      messages.add(ConsoleMessage.warning(
        "Block comment '/*' tidak ditutup dengan '*/'.",
        filePath: file.path,
      ));
    }
    for (final open in stack) {
      messages.add(ConsoleMessage.error(
        "Tanda kurung '${open.char}' tidak pernah ditutup.",
        filePath: file.path,
        line: open.line,
      ));
    }
    return messages;
  }

  List<ConsoleMessage> _checkBasicStructure(FileModel file) {
    final messages = <ConsoleMessage>[];
    final content = file.content;

    if (file.path == 'lib/main.dart' && !content.contains('void main(')) {
      messages.add(ConsoleMessage.warning(
        "lib/main.dart tidak memiliki fungsi 'void main()'. Flutter runtime tidak akan tahu entry point aplikasi.",
        filePath: file.path,
      ));
    }
    if (content.trim().isEmpty) {
      messages.add(ConsoleMessage.warning('File kosong.', filePath: file.path));
    }
    return messages;
  }
}

class _OpenBracket {
  final String char;
  final int line;
  _OpenBracket(this.char, this.line);
}
