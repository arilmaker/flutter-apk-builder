import 'package:flutter/foundation.dart';

import '../models/build_job.dart';
import '../models/console_message.dart';
import '../models/project_model.dart';
import 'build_server_service.dart';
import 'compiler_service.dart';
import 'runtime_service.dart';

enum PreviewState { idle, analyzing, starting, running, reloading, error, unavailable }

/// Orchestrates the RUN / RELOAD / STOP flow described in the spec:
///
///   EDITOR -> SAVE -> ANALYZE -> COMPILE/RUN -> PREVIEW
///
/// It never shows a fake "Preview berhasil" when no real runtime executed
/// the code. If no runtime adapter is available (no Build Server
/// configured), state becomes [PreviewState.unavailable] with an honest
/// message instead of a fabricated success screen.
class PreviewService extends ChangeNotifier {
  final CompilerService compilerService;
  final RuntimeService runtimeService;
  final BuildServerService buildServerService;

  PreviewState state = PreviewState.idle;
  PreviewSession? session;
  List<ConsoleMessage> consoleMessages = [];
  bool get isHotReloadCapable => session?.supportsHotReload ?? false;

  PreviewService({
    required this.compilerService,
    required this.runtimeService,
    required this.buildServerService,
  });

  void _log(ConsoleMessage m) {
    consoleMessages = [...consoleMessages, m];
    notifyListeners();
  }

  Future<void> run(ProjectModel project) async {
    consoleMessages = [];
    state = PreviewState.analyzing;
    notifyListeners();

    final result = await compilerService.analyze(project);
    consoleMessages = [...result.messages];
    if (!result.success) {
      state = PreviewState.error;
      notifyListeners();
      return;
    }
    _log(ConsoleMessage.success('✓ Analisis lokal selesai, tidak ada error struktural.'));

    final adapter = await runtimeService.activeAdapter();
    if (adapter == null) {
      state = PreviewState.unavailable;
      _log(ConsoleMessage.warning(
          'Flutter runtime lokal tidak tersedia pada environment ini. Hubungkan Build Server di Settings untuk menjalankan preview Flutter yang sesungguhnya.'));
      notifyListeners();
      return;
    }

    state = PreviewState.starting;
    notifyListeners();
    try {
      _log(ConsoleMessage.info('Mengirim project ke ${adapter.name}...'));
      session = await adapter.start(project);
      state = PreviewState.running;
      _log(ConsoleMessage.success('✓ Build completed'));
    } on BuildServerException catch (e) {
      state = PreviewState.error;
      _log(ConsoleMessage.error(e.message));
    } catch (e) {
      state = PreviewState.error;
      _log(ConsoleMessage.error('RUN FAILED: $e'));
    }
    notifyListeners();
  }

  Future<void> reload(ProjectModel project) async {
    if (session == null) {
      await run(project);
      return;
    }
    state = PreviewState.reloading;
    notifyListeners();
    try {
      final adapter = await runtimeService.activeAdapter();
      if (adapter == null) {
        state = PreviewState.unavailable;
        notifyListeners();
        return;
      }
      if (session!.supportsHotReload) {
        await adapter.reload(session!);
        _log(ConsoleMessage.success('✓ HOT RELOAD selesai.'));
      } else {
        await adapter.stop(session!);
        session = await adapter.start(project);
        _log(ConsoleMessage.success('✓ RESTART PREVIEW selesai.'));
      }
      state = PreviewState.running;
    } on BuildServerException catch (e) {
      state = PreviewState.error;
      _log(ConsoleMessage.error(e.message));
    }
    notifyListeners();
  }

  Future<void> stop() async {
    final adapter = await runtimeService.activeAdapter();
    if (adapter != null && session != null) {
      await adapter.stop(session!);
    }
    session = null;
    state = PreviewState.idle;
    consoleMessages = [];
    notifyListeners();
  }

  List<ConsoleMessage> getErrors() =>
      consoleMessages.where((m) => m.isError).toList();

  PreviewSession? getPreview() => session;
}
