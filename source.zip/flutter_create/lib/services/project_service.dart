import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/file_model.dart';
import '../models/project_model.dart';
import 'project_generator_service.dart';
import 'storage_service.dart';

/// High-level project operations used by the UI. Wraps [StorageService]
/// (persistence) and [ProjectGeneratorService] (scaffolding) so screens
/// never touch dart:io or archive parsing directly.
class ProjectService extends ChangeNotifier {
  final StorageService _storage;
  final ProjectGeneratorService _generator;
  final _uuid = const Uuid();

  List<ProjectModel> _projects = [];
  bool _loading = false;
  String? _lastError;

  ProjectService({
    StorageService? storage,
    ProjectGeneratorService? generator,
  })  : _storage = storage ?? StorageService(),
        _generator = generator ?? ProjectGeneratorService();

  List<ProjectModel> get projects => List.unmodifiable(_projects);
  bool get loading => _loading;
  String? get lastError => _lastError;

  Future<void> refresh() async {
    _loading = true;
    notifyListeners();
    try {
      _projects = await _storage.listProjects();
      _lastError = null;
    } on StorageException catch (e) {
      _lastError = e.message;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<ProjectModel> createProject({
    required String name,
    required String packageName,
    required String description,
    required ProjectTemplate template,
  }) async {
    final project = _generator.createProject(
      name: name,
      packageName: packageName,
      description: description,
      template: template,
    );
    await _storage.saveProject(project);
    _projects.insert(0, project);
    notifyListeners();
    return project;
  }

  Future<ProjectModel?> openProject(String projectId) async {
    final project = await _storage.loadProject(projectId);
    return project;
  }

  Future<ProjectModel> importProject(File zipFile) async {
    final project = await _storage.importProjectZip(
      zipFile,
      newProjectId: _uuid.v4(),
    );
    _projects.insert(0, project);
    notifyListeners();
    return project;
  }

  Future<void> saveProject(ProjectModel project) async {
    await _storage.saveProject(project);
    final index = _projects.indexWhere((p) => p.id == project.id);
    if (index >= 0) {
      _projects[index] = project;
    }
    notifyListeners();
  }

  Future<void> saveFile(ProjectModel project, FileModel file) async {
    file.isModified = false;
    project.upsertFile(file);
    await _storage.writeFile(project.id, file.path, file.content);
    await _storage.saveProject(project);
    notifyListeners();
  }

  Future<void> deleteProject(String projectId) async {
    await _storage.deleteProject(projectId);
    _projects.removeWhere((p) => p.id == projectId);
    notifyListeners();
  }

  Future<File> exportProject(ProjectModel project) {
    return _storage.exportProjectAsZip(project);
  }

  List<ProjectModel> get recentProjects {
    final sorted = [..._projects]
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return sorted.take(6).toList();
  }
}
