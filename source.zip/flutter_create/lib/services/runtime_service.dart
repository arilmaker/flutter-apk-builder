import '../models/build_job.dart';
import '../models/project_model.dart';
import 'build_server_service.dart';

enum RuntimeCapability { unavailable, remoteReady }

/// Abstract adapter so RuntimeService is never locked to one implementation
/// (per spec: Option A embedded engine, Option B dedicated local
/// compilation, Option C remote build/preview server).
abstract class RuntimeAdapter {
  String get name;
  Future<bool> isAvailable();
  Future<PreviewSession> start(ProjectModel project);
  Future<void> reload(PreviewSession session);
  Future<void> stop(PreviewSession session);
}

/// Option A — an embedded Flutter engine/runtime on-device.
///
/// Stock Flutter/Android does not ship a way to compile and execute
/// arbitrary Dart/Flutter widget trees at runtime inside another Flutter
/// app. Rather than fake this, the adapter honestly reports itself as
/// unavailable. It exists so a future release can implement it behind this
/// same interface without touching the rest of the app.
class LocalEmbeddedRuntimeAdapter implements RuntimeAdapter {
  @override
  String get name => 'Local Embedded Runtime (Option A)';

  @override
  Future<bool> isAvailable() async => false;

  @override
  Future<PreviewSession> start(ProjectModel project) {
    throw UnimplementedError(
        'Flutter runtime lokal tidak tersedia pada environment Android standar.');
  }

  @override
  Future<void> reload(PreviewSession session) => throw UnimplementedError();

  @override
  Future<void> stop(PreviewSession session) => throw UnimplementedError();
}

/// Option B — a dedicated local compilation environment (e.g. a companion
/// daemon on the same device/network). Not implemented in v1; kept as an
/// honest stub behind the same interface.
class DedicatedLocalCompilerAdapter implements RuntimeAdapter {
  @override
  String get name => 'Dedicated Local Compiler (Option B)';

  @override
  Future<bool> isAvailable() async => false;

  @override
  Future<PreviewSession> start(ProjectModel project) {
    throw UnimplementedError('Dedicated local compiler belum dikonfigurasi.');
  }

  @override
  Future<void> reload(PreviewSession session) => throw UnimplementedError();

  @override
  Future<void> stop(PreviewSession session) => throw UnimplementedError();
}

/// Option C — remote build/preview server. This is the adapter that is
/// actually functional in v1, using [BuildServerService].
class RemoteBuildServerAdapter implements RuntimeAdapter {
  final BuildServerService buildServerService;
  RemoteBuildServerAdapter(this.buildServerService);

  @override
  String get name => 'Remote Build Server (Option C)';

  @override
  Future<bool> isAvailable() async =>
      buildServerService.settings.isBuildServerConfigured;

  @override
  Future<PreviewSession> start(ProjectModel project) async {
    final uploadId = await buildServerService.uploadProject(project);
    return buildServerService.requestPreview(uploadId);
  }

  @override
  Future<void> reload(PreviewSession session) {
    return buildServerService.reloadPreview(session.id);
  }

  @override
  Future<void> stop(PreviewSession session) {
    return buildServerService.stopPreview(session.id);
  }
}

/// Picks the first available adapter (remote first, since it's the only
/// one implemented today) and exposes a uniform start/reload/stop API to
/// [PreviewService]. Reports capability honestly instead of assuming.
class RuntimeService {
  final List<RuntimeAdapter> adapters;

  RuntimeService(BuildServerService buildServerService)
      : adapters = [
          RemoteBuildServerAdapter(buildServerService),
          DedicatedLocalCompilerAdapter(),
          LocalEmbeddedRuntimeAdapter(),
        ];

  Future<RuntimeAdapter?> activeAdapter() async {
    for (final adapter in adapters) {
      if (await adapter.isAvailable()) return adapter;
    }
    return null;
  }

  Future<RuntimeCapability> checkCapability() async {
    final adapter = await activeAdapter();
    return adapter == null
        ? RuntimeCapability.unavailable
        : RuntimeCapability.remoteReady;
  }
}
