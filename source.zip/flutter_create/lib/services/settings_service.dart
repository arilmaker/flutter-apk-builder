import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Persists user preferences (Settings screen) using SharedPreferences.
///
/// All reads are served from memory after [load] so the UI can bind to this
/// as a ChangeNotifier without hitting disk on every rebuild.
class SettingsService extends ChangeNotifier {
  static const _kDarkMode = 'settings.darkMode';
  static const _kFontSize = 'settings.editorFontSize';
  static const _kFontFamily = 'settings.editorFontFamily';
  static const _kAutoSave = 'settings.autoSave';
  static const _kShowLineNumbers = 'settings.showLineNumbers';
  static const _kWordWrap = 'settings.wordWrap';
  static const _kDefaultLocation = 'settings.defaultProjectLocation';
  static const _kBuildServerUrl = 'settings.buildServerUrl';

  SharedPreferences? _prefs;

  bool darkMode = true;
  double editorFontSize = 14;
  String editorFontFamily = 'monospace';
  bool autoSave = true;
  bool showLineNumbers = true;
  bool wordWrap = false;
  String defaultProjectLocation = 'FlutterCreate/projects';
  String buildServerUrl = '';

  bool get isBuildServerConfigured => buildServerUrl.trim().isNotEmpty;

  Future<void> load() async {
    _prefs ??= await SharedPreferences.getInstance();
    final p = _prefs!;
    darkMode = p.getBool(_kDarkMode) ?? true;
    editorFontSize = p.getDouble(_kFontSize) ?? 14;
    editorFontFamily = p.getString(_kFontFamily) ?? 'monospace';
    autoSave = p.getBool(_kAutoSave) ?? true;
    showLineNumbers = p.getBool(_kShowLineNumbers) ?? true;
    wordWrap = p.getBool(_kWordWrap) ?? false;
    defaultProjectLocation =
        p.getString(_kDefaultLocation) ?? 'FlutterCreate/projects';
    buildServerUrl = p.getString(_kBuildServerUrl) ?? '';
    notifyListeners();
  }

  Future<void> setDarkMode(bool value) async {
    darkMode = value;
    await _prefs?.setBool(_kDarkMode, value);
    notifyListeners();
  }

  Future<void> setEditorFontSize(double value) async {
    editorFontSize = value;
    await _prefs?.setDouble(_kFontSize, value);
    notifyListeners();
  }

  Future<void> setEditorFontFamily(String value) async {
    editorFontFamily = value;
    await _prefs?.setString(_kFontFamily, value);
    notifyListeners();
  }

  Future<void> setAutoSave(bool value) async {
    autoSave = value;
    await _prefs?.setBool(_kAutoSave, value);
    notifyListeners();
  }

  Future<void> setShowLineNumbers(bool value) async {
    showLineNumbers = value;
    await _prefs?.setBool(_kShowLineNumbers, value);
    notifyListeners();
  }

  Future<void> setWordWrap(bool value) async {
    wordWrap = value;
    await _prefs?.setBool(_kWordWrap, value);
    notifyListeners();
  }

  Future<void> setDefaultProjectLocation(String value) async {
    defaultProjectLocation = value;
    await _prefs?.setString(_kDefaultLocation, value);
    notifyListeners();
  }

  Future<void> setBuildServerUrl(String value) async {
    buildServerUrl = value.trim();
    await _prefs?.setString(_kBuildServerUrl, buildServerUrl);
    notifyListeners();
  }
}
