import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:path_provider/path_provider.dart';

import '../models/file_model.dart';
import '../models/project_model.dart';

/// Thrown for any storage-related failure so the UI can show a clear,
/// honest error message instead of silently failing or crashing.
class StorageException implements Exception {
  final String message;
  StorageException(this.message);
  @override
  String toString() => message;
}

/// Handles all on-device persistence for projects: saving, loading,
/// deleting, and importing/exporting as real ZIP archives.
///
/// Layout on device:
///   <appDocuments>/FlutterCreateProjects/<projectId>/project.json
///   <appDocuments>/FlutterCreateProjects/<projectId>/files/<relative path>
class StorageService {
  static const _rootFolderName = 'FlutterCreateProjects';

  Directory? _rootDir;

  Future<Directory> get _root async {
    if (_rootDir != null) return _rootDir!;
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/$_rootFolderName');
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    _rootDir = dir;
    return dir;
  }

  Future<Directory> _projectDir(String projectId) async {
    final root = await _root;
    final dir = Directory('${root.path}/$projectId');
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  /// Persists project metadata (project.json) and every file's content to
  /// disk. This is a real filesystem write, not an in-memory placeholder.
  Future<void> saveProject(ProjectModel project) async {
    try {
      final dir = await _projectDir(project.id);
      final metaFile = File('${dir.path}/project.json');
      await metaFile.writeAsString(jsonEncode(project.toJson()));

      final filesDir = Directory('${dir.path}/files');
      if (!await filesDir.exists()) {
        await filesDir.create(recursive: true);
      }
      for (final f in project.files) {
        final target = File('${filesDir.path}/${f.path}');
        await target.parent.create(recursive: true);
        await target.writeAsString(f.content);
      }
    } catch (e) {
      throw StorageException('Gagal menyimpan project: $e');
    }
  }

  Future<ProjectModel?> loadProject(String projectId) async {
    try {
      final root = await _root;
      final metaFile = File('${root.path}/$projectId/project.json');
      if (!await metaFile.exists()) return null;
      final json = jsonDecode(await metaFile.readAsString());
      return ProjectModel.fromJson(json as Map<String, dynamic>);
    } catch (e) {
      throw StorageException('Gagal membuka project: $e');
    }
  }

  Future<List<ProjectModel>> listProjects() async {
    try {
      final root = await _root;
      final entries = await root.list().toList();
      final projects = <ProjectModel>[];
      for (final entry in entries) {
        if (entry is Directory) {
          final metaFile = File('${entry.path}/project.json');
          if (await metaFile.exists()) {
            try {
              final json = jsonDecode(await metaFile.readAsString());
              projects.add(ProjectModel.fromJson(json as Map<String, dynamic>));
            } catch (_) {
              // Skip a corrupted project entry rather than crashing the list.
            }
          }
        }
      }
      projects.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      return projects;
    } catch (e) {
      throw StorageException('Gagal membaca daftar project: $e');
    }
  }

  Future<void> deleteProject(String projectId) async {
    try {
      final root = await _root;
      final dir = Directory('${root.path}/$projectId');
      if (await dir.exists()) {
        await dir.delete(recursive: true);
      }
    } catch (e) {
      throw StorageException('Gagal menghapus project: $e');
    }
  }

  /// Writes a single file's content to the on-disk copy immediately.
  /// Used by the editor's Save action so unsaved changes are never lost
  /// even before a full [saveProject] call.
  Future<void> writeFile(String projectId, String relativePath, String content) async {
    try {
      final dir = await _projectDir(projectId);
      final target = File('${dir.path}/files/$relativePath');
      await target.parent.create(recursive: true);
      await target.writeAsString(content);
    } catch (e) {
      throw StorageException('Gagal menyimpan file: $e');
    }
  }

  /// Exports a project as a real ZIP archive containing pubspec.yaml,
  /// lib/, and every other tracked file. Returns the resulting ZIP file.
  Future<File> exportProjectAsZip(ProjectModel project) async {
    try {
      final archive = Archive();
      for (final f in project.files) {
        final data = utf8.encode(f.content);
        archive.addFile(ArchiveFile(f.path, data.length, data));
      }
      final zipData = ZipEncoder().encode(archive);
      final root = await _root;
      final exportsDir = Directory('${root.path}/../FlutterCreateExports');
      if (!await exportsDir.exists()) {
        await exportsDir.create(recursive: true);
      }
      final outFile = File('${exportsDir.path}/${project.name}.zip');
      await outFile.writeAsBytes(zipData!);
      return outFile;
    } catch (e) {
      throw StorageException('Gagal mengekspor project: $e');
    }
  }

  /// Imports a Flutter project ZIP. Validates that it contains at least
  /// `pubspec.yaml` and a `lib/` directory before accepting it — per spec,
  /// an invalid archive must be rejected with a clear message, not crash.
  Future<ProjectModel> importProjectZip(File zipFile, {required String newProjectId}) async {
    try {
      final bytes = await zipFile.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);

      final hasPubspec = archive.files.any((f) => f.name == 'pubspec.yaml');
      final hasLib = archive.files.any((f) => f.name.startsWith('lib/'));
      if (!hasPubspec || !hasLib) {
        throw StorageException('Invalid Flutter project.');
      }

      String name = zipFile.uri.pathSegments.last.replaceAll('.zip', '');
      String packageName = 'com.example.${name.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '')}';

      final project = ProjectModel(
        id: newProjectId,
        name: name,
        packageName: packageName,
        description: 'Imported project',
        path: newProjectId,
      );

      for (final file in archive.files) {
        if (!file.isFile) continue;
        final content = file.content;
        String text;
        try {
          text = utf8.decode(content as List<int>);
        } catch (_) {
          // Skip binary / undecodable files (images, icons, etc.) — we only
          // track text source files in the editor for v1.
          continue;
        }
        final segments = file.name.split('/');
        final fileName = segments.isNotEmpty ? segments.last : file.name;
        project.upsertFile(FileModel(
          id: '${DateTime.now().microsecondsSinceEpoch}_$fileName',
          name: fileName,
          path: file.name,
          content: text,
        ));
      }

      await saveProject(project);
      return project;
    } on StorageException {
      rethrow;
    } catch (e) {
      throw StorageException('Unable to read Dart file.');
    }
  }
}
