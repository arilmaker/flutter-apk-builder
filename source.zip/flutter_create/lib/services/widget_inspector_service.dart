/// A best-effort, source-based widget outline — NOT a live visual inspector.
///
/// True click-on-pixel widget inspection would require a devtools-style
/// bridge into a running Flutter engine. Since v1's preview is rendered by
/// an external Build Server (see PreviewService/BuildServerService) rather
/// than an embedded engine, Flutter Create does not claim to offer that.
///
/// What this DOES do, honestly: parse the Dart source text and extract a
/// read-only outline of widget constructor calls (name + top-level named
/// arguments) so the user can see the structure of their UI. Editing values
/// here does NOT write back to the Dart source in v1 — that capability is
/// intentionally left unbuilt rather than faked.
class WidgetNode {
  final String widgetName;
  final Map<String, String> properties;
  final int line;
  final int depth;

  WidgetNode({
    required this.widgetName,
    required this.properties,
    required this.line,
    required this.depth,
  });
}

class WidgetInspectorService {
  static final _widgetCallRegex = RegExp(r'\b([A-Z][A-Za-z0-9_]*)\(');

  /// Returns a flat, indentation-based outline of widget constructor
  /// invocations found in [source]. This is a heuristic, not a real parse
  /// tree — it is meant for a quick structural glance, not precision
  /// refactoring.
  List<WidgetNode> buildOutline(String source) {
    final nodes = <WidgetNode>[];
    final lines = source.split('\n');
    for (var i = 0; i < lines.length; i++) {
      final line = lines[i];
      final match = _widgetCallRegex.firstMatch(line.trimLeft());
      if (match == null) continue;
      final name = match.group(1)!;
      if (_isLikelyNotWidget(name)) continue;
      final depth = (line.length - line.trimLeft().length) ~/ 2;
      nodes.add(WidgetNode(
        widgetName: name,
        properties: _extractInlineProperties(line),
        line: i + 1,
        depth: depth,
      ));
    }
    return nodes;
  }

  bool _isLikelyNotWidget(String name) {
    const nonWidgetHints = {
      'MaterialApp', // keep MaterialApp; only filter obvious non-widgets
    };
    // Filter common non-widget capitalised calls (very rough heuristic).
    const blockList = {
      'ThemeData',
      'TextStyle',
      'EdgeInsets',
      'BorderRadius',
      'Colors',
      'Duration',
      'Icon', // kept generically fine, but treated as leaf via properties
    };
    return blockList.contains(name) && !nonWidgetHints.contains(name);
  }

  Map<String, String> _extractInlineProperties(String line) {
    final props = <String, String>{};
    final propRegex = RegExp(r'(\w+)\s*:\s*([^,()]+)');
    for (final m in propRegex.allMatches(line)) {
      final key = m.group(1)!;
      final value = m.group(2)!.trim();
      if (key == 'child' || key == 'children') continue;
      props[key] = value;
    }
    return props;
  }
}
