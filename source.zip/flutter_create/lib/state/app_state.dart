import 'package:flutter/foundation.dart';

import '../models/file_model.dart';
import '../models/project_model.dart';

/// Tracks which project and which file are currently active across the
/// Home / Projects / Editor / Preview / Build tabs, so opening a file from
/// Project Explorer correctly drives the Editor tab, etc.
class AppState extends ChangeNotifier {
  ProjectModel? currentProject;
  FileModel? activeFile;

  void openProject(ProjectModel project) {
    currentProject = project;
    activeFile = project.mainFile ?? (project.files.isNotEmpty ? project.files.first : null);
    notifyListeners();
  }

  void openFile(FileModel file) {
    activeFile = file;
    notifyListeners();
  }

  void updateActiveFileContent(String content) {
    if (activeFile == null) return;
    activeFile!.content = content;
    activeFile!.isModified = true;
    notifyListeners();
  }

  void markSaved() {
    if (activeFile == null) return;
    activeFile!.isModified = false;
    notifyListeners();
  }

  void closeProject() {
    currentProject = null;
    activeFile = null;
    notifyListeners();
  }
}
