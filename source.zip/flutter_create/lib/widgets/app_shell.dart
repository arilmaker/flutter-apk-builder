import 'package:flutter/material.dart';

import '../screens/analytics_screen.dart';
import '../screens/billing_screen.dart';
import '../screens/build_screen.dart';
import '../screens/editor_screen.dart';
import '../screens/home_screen.dart';
import '../screens/preview_screen.dart';
import '../screens/projects_screen.dart';
import '../screens/settings_screen.dart';
import '../screens/team_screen.dart';
import '../theme/app_theme.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  static const _screens = <Widget>[
    HomeScreen(),
    ProjectsScreen(),
    EditorScreen(),
    PreviewScreen(),
    BuildScreen(),
    SettingsScreen(),
  ];

  static const _destinations = <NavigationDestination>[
    NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
    NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder_rounded), label: 'Projects'),
    NavigationDestination(icon: Icon(Icons.code_outlined), selectedIcon: Icon(Icons.code_rounded), label: 'Editor'),
    NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle_fill_rounded), label: 'Preview'),
    NavigationDestination(icon: Icon(Icons.build_outlined), selectedIcon: Icon(Icons.build_rounded), label: 'Build'),
    NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Settings'),
  ];

  void goTo(int index) => setState(() => _index = index);

  void _open(Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    return AppShellController(
      goTo: goTo,
      child: Scaffold(
        drawer: Drawer(
          backgroundColor: AppColors.surfaceDark,
          child: SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(12, 16, 12, 20),
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(12, 4, 12, 22),
                  child: Row(children: [Icon(Icons.bolt_rounded, color: AppColors.accentAlt, size: 28), SizedBox(width: 9), Text('Flutter Create', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18))]),
                ),
                const _DrawerLabel('Workspace'),
                _DrawerItem(icon: Icons.home_rounded, title: 'Dashboard', onTap: () { Navigator.pop(context); goTo(0); }),
                _DrawerItem(icon: Icons.folder_rounded, title: 'Projects', onTap: () { Navigator.pop(context); goTo(1); }),
                _DrawerItem(icon: Icons.insights_rounded, title: 'Analytics', onTap: () { Navigator.pop(context); _open(const AnalyticsScreen()); }),
                _DrawerItem(icon: Icons.groups_2_rounded, title: 'Team', onTap: () { Navigator.pop(context); _open(const TeamScreen()); }),
                const Divider(height: 28),
                const _DrawerLabel('Product'),
                _DrawerItem(icon: Icons.code_rounded, title: 'Dart Editor', onTap: () { Navigator.pop(context); goTo(2); }),
                _DrawerItem(icon: Icons.play_circle_fill_rounded, title: 'Preview', onTap: () { Navigator.pop(context); goTo(3); }),
                _DrawerItem(icon: Icons.rocket_launch_rounded, title: 'Builds', onTap: () { Navigator.pop(context); goTo(4); }),
                _DrawerItem(icon: Icons.workspace_premium_rounded, title: 'Plans & Billing', onTap: () { Navigator.pop(context); _open(const BillingScreen()); }),
                const Divider(height: 28),
                const _DrawerLabel('Settings'),
                _DrawerItem(icon: Icons.settings_rounded, title: 'Settings', onTap: () { Navigator.pop(context); goTo(5); }),
                _DrawerItem(icon: Icons.help_outline_rounded, title: 'Help Center', onTap: () { Navigator.pop(context); _showHelp(); }),
              ],
            ),
          ),
        ),
        body: IndexedStack(index: _index, children: _screens),
        bottomNavigationBar: NavigationBarTheme(
          data: const NavigationBarThemeData(backgroundColor: AppColors.surfaceDark, surfaceTintColor: Colors.transparent),
          child: NavigationBar(selectedIndex: _index, onDestinationSelected: goTo, destinations: _destinations),
        ),
      ),
    );
  }

  void _showHelp() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => const Padding(
        padding: EdgeInsets.fromLTRB(20, 8, 20, 30),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Help Center', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20)),
          SizedBox(height: 8),
          Text('Flutter Create helps you edit Dart, preview Flutter projects and prepare builds from Android.', style: TextStyle(color: AppColors.textSecondaryDark, height: 1.45)),
          SizedBox(height: 16),
          Text('Tip: open a project, choose a Dart file, edit it, then press RUN to start the preview workflow.', style: TextStyle(fontSize: 12)),
        ]),
      ),
    );
  }
}

class _DrawerLabel extends StatelessWidget {
  final String text;
  const _DrawerLabel(this.text);
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 8), child: Text(text.toUpperCase(), style: const TextStyle(color: AppColors.textSecondaryDark, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.1)));
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _DrawerItem({required this.icon, required this.title, required this.onTap});
  @override
  Widget build(BuildContext context) => ListTile(leading: Icon(icon, size: 20), title: Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), onTap: onTap);
}

class AppShellController extends InheritedWidget {
  final void Function(int index) goTo;
  const AppShellController({super.key, required this.goTo, required super.child});
  static AppShellController? of(BuildContext context) => context.dependOnInheritedWidgetOfExactType<AppShellController>();
  @override
  bool updateShouldNotify(AppShellController oldWidget) => false;
}
