import 'package:flutter/material.dart';

import '../models/console_message.dart';
import '../theme/app_theme.dart';

class ConsolePanel extends StatelessWidget {
  final List<ConsoleMessage> messages;
  final double height;

  const ConsolePanel({super.key, required this.messages, this.height = 180});

  Color _colorFor(ConsoleLevel level) {
    switch (level) {
      case ConsoleLevel.error:
        return AppColors.danger;
      case ConsoleLevel.warning:
        return AppColors.warn;
      case ConsoleLevel.info:
        return AppColors.accentAlt;
      case ConsoleLevel.success:
        return AppColors.run;
    }
  }

  IconData _iconFor(ConsoleLevel level) {
    switch (level) {
      case ConsoleLevel.error:
        return Icons.error_rounded;
      case ConsoleLevel.warning:
        return Icons.warning_rounded;
      case ConsoleLevel.info:
        return Icons.info_rounded;
      case ConsoleLevel.success:
        return Icons.check_circle_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: AppColors.surfaceDark,
        border: const Border(top: BorderSide(color: AppColors.borderDark)),
      ),
      child: messages.isEmpty
          ? const Center(
              child: Text(
                '✓ Build completed',
                style: TextStyle(color: AppColors.run, fontFamily: 'monospace'),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final m = messages[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(_iconFor(m.level), size: 14, color: _colorFor(m.level)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: RichText(
                          text: TextSpan(
                            style: const TextStyle(
                                fontFamily: 'monospace', fontSize: 12.5, color: AppColors.textPrimaryDark),
                            children: [
                              if (m.filePath != null)
                                TextSpan(
                                  text: '${m.filePath}${m.line != null ? ':${m.line}' : ''}\n',
                                  style: const TextStyle(color: AppColors.textSecondaryDark),
                                ),
                              TextSpan(text: m.message),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
