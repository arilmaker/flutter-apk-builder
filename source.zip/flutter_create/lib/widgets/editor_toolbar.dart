import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class EditorToolbar extends StatelessWidget implements PreferredSizeWidget {
  final String fileName;
  final bool isModified;
  final VoidCallback onRun;
  final VoidCallback onReload;
  final VoidCallback onStop;
  final VoidCallback onSave;
  final VoidCallback onSearch;
  final bool isRunning;

  const EditorToolbar({
    super.key,
    required this.fileName,
    required this.isModified,
    required this.onRun,
    required this.onReload,
    required this.onStop,
    required this.onSave,
    required this.onSearch,
    this.isRunning = false,
  });

  @override
  Size get preferredSize => const Size.fromHeight(56);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      color: AppColors.surfaceDark,
      child: Row(
        children: [
          const Icon(Icons.description_outlined, size: 18, color: AppColors.textSecondaryDark),
          const SizedBox(width: 8),
          Flexible(
            child: Text(fileName,
                style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
                overflow: TextOverflow.ellipsis),
          ),
          if (isModified) ...[
            const SizedBox(width: 6),
            const CircleAvatar(radius: 3, backgroundColor: AppColors.warn),
            const SizedBox(width: 4),
            const Text('unsaved',
                style: TextStyle(fontSize: 11, color: AppColors.warn, fontFamily: 'monospace')),
          ],
          const Spacer(),
          IconButton(
            tooltip: 'Search / Replace',
            icon: const Icon(Icons.search, size: 20),
            onPressed: onSearch,
          ),
          IconButton(
            tooltip: 'Save',
            icon: const Icon(Icons.save_outlined, size: 20),
            onPressed: onSave,
          ),
          if (isRunning) ...[
            IconButton(
              tooltip: 'Reload',
              icon: const Icon(Icons.refresh_rounded, color: AppColors.accentAlt),
              onPressed: onReload,
            ),
            IconButton(
              tooltip: 'Stop',
              icon: const Icon(Icons.stop_rounded, color: AppColors.danger),
              onPressed: onStop,
            ),
          ] else
            FilledButton.icon(
              onPressed: onRun,
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.run,
                foregroundColor: Colors.black,
              ),
              icon: const Icon(Icons.play_arrow_rounded, size: 18),
              label: const Text('RUN'),
            ),
        ],
      ),
    );
  }
}
