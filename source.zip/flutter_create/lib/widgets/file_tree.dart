import 'package:flutter/material.dart';

import '../models/file_model.dart';
import '../theme/app_theme.dart';

class _TreeNode {
  final String name;
  final bool isDir;
  final FileModel? file;
  final Map<String, _TreeNode> children = {};
  _TreeNode({required this.name, required this.isDir, this.file});
}

/// Builds a hierarchical tree from a flat list of [FileModel.path] values
/// (e.g. lib/screens/home.dart) and renders it as an expandable IDE-style
/// file explorer.
class FileTree extends StatefulWidget {
  final List<FileModel> files;
  final void Function(FileModel file) onOpenFile;
  final void Function(FileModel file)? onRename;
  final void Function(FileModel file)? onDelete;

  const FileTree({
    super.key,
    required this.files,
    required this.onOpenFile,
    this.onRename,
    this.onDelete,
  });

  @override
  State<FileTree> createState() => _FileTreeState();
}

class _FileTreeState extends State<FileTree> {
  final Set<String> _collapsed = {};

  _TreeNode _buildTree() {
    final root = _TreeNode(name: '', isDir: true);
    for (final file in widget.files) {
      final parts = file.path.split('/');
      var current = root;
      for (var i = 0; i < parts.length; i++) {
        final isLast = i == parts.length - 1;
        final part = parts[i];
        current = current.children.putIfAbsent(
          part,
          () => _TreeNode(name: part, isDir: !isLast, file: isLast ? file : null),
        );
      }
    }
    return root;
  }

  IconData _iconForExt(String ext) {
    switch (ext) {
      case 'dart':
        return Icons.code_rounded;
      case 'yaml':
      case 'yml':
        return Icons.settings_suggest_outlined;
      case 'md':
        return Icons.article_outlined;
      default:
        return Icons.insert_drive_file_outlined;
    }
  }

  List<Widget> _renderNode(_TreeNode node, String pathSoFar, int depth) {
    final entries = node.children.entries.toList()
      ..sort((a, b) {
        if (a.value.isDir != b.value.isDir) return a.value.isDir ? -1 : 1;
        return a.key.compareTo(b.key);
      });

    final widgets = <Widget>[];
    for (final entry in entries) {
      final child = entry.value;
      final fullPath = pathSoFar.isEmpty ? entry.key : '$pathSoFar/${entry.key}';
      if (child.isDir) {
        final isCollapsed = _collapsed.contains(fullPath);
        widgets.add(InkWell(
          onTap: () => setState(() {
            if (isCollapsed) {
              _collapsed.remove(fullPath);
            } else {
              _collapsed.add(fullPath);
            }
          }),
          child: Padding(
            padding: EdgeInsets.only(left: depth * 16.0, top: 6, bottom: 6),
            child: Row(
              children: [
                Icon(isCollapsed ? Icons.chevron_right : Icons.expand_more,
                    size: 18, color: AppColors.textSecondaryDark),
                const Icon(Icons.folder_rounded, size: 16, color: AppColors.accentAlt),
                const SizedBox(width: 6),
                Text(child.name, style: const TextStyle(fontSize: 13.5)),
              ],
            ),
          ),
        ));
        if (!isCollapsed) {
          widgets.addAll(_renderNode(child, fullPath, depth + 1));
        }
      } else {
        final file = child.file!;
        widgets.add(InkWell(
          onTap: () => widget.onOpenFile(file),
          onLongPress: () => _showFileActions(context, file),
          child: Padding(
            padding: EdgeInsets.only(left: depth * 16.0 + 22, top: 6, bottom: 6, right: 8),
            child: Row(
              children: [
                Icon(_iconForExt(file.extension), size: 16, color: AppColors.textSecondaryDark),
                const SizedBox(width: 6),
                Expanded(child: Text(child.name, style: const TextStyle(fontSize: 13.5))),
                if (file.isModified)
                  const CircleAvatar(radius: 3, backgroundColor: AppColors.warn),
              ],
            ),
          ),
        ));
      }
    }
    return widgets;
  }

  void _showFileActions(BuildContext context, FileModel file) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.drive_file_rename_outline),
              title: const Text('Rename'),
              onTap: () {
                Navigator.pop(ctx);
                widget.onRename?.call(file);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: AppColors.danger),
              title: const Text('Delete'),
              onTap: () {
                Navigator.pop(ctx);
                widget.onDelete?.call(file);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.files.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Text('Belum ada file di project ini.',
            style: TextStyle(color: AppColors.textSecondaryDark)),
      );
    }
    final tree = _buildTree();
    return ListView(children: _renderNode(tree, '', 0));
  }
}
