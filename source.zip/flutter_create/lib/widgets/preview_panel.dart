import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../theme/app_theme.dart';

enum DeviceOrientation2 { portrait, landscape }

/// Renders the live preview inside a simple device frame. The actual pixels
/// come from the Build Server's compiled output (loaded in a WebView) — see
/// PreviewService for how that URL is obtained. This widget only handles
/// layout/framing/zoom, it never simulates Flutter rendering itself.
class PreviewPanel extends StatefulWidget {
  final String? previewUrl;
  final Widget? placeholder;

  const PreviewPanel({super.key, this.previewUrl, this.placeholder});

  @override
  State<PreviewPanel> createState() => _PreviewPanelState();
}

class _PreviewPanelState extends State<PreviewPanel> {
  DeviceOrientation2 _orientation = DeviceOrientation2.portrait;
  double _zoom = 1.0;
  WebViewController? _controller;
  String? _loadedUrl;

  void _ensureController() {
    if (widget.previewUrl == null) return;
    if (_controller != null && _loadedUrl == widget.previewUrl) return;
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..loadRequest(Uri.parse(widget.previewUrl!));
    _loadedUrl = widget.previewUrl;
  }

  @override
  Widget build(BuildContext context) {
    _ensureController();
    final isPortrait = _orientation == DeviceOrientation2.portrait;
    final baseWidth = isPortrait ? 320.0 : 640.0;
    final baseHeight = isPortrait ? 640.0 : 320.0;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Row(
            children: [
              IconButton(
                tooltip: 'Portrait',
                icon: Icon(Icons.stay_current_portrait,
                    color: isPortrait ? AppColors.accent : AppColors.textSecondaryDark),
                onPressed: () => setState(() => _orientation = DeviceOrientation2.portrait),
              ),
              IconButton(
                tooltip: 'Landscape',
                icon: Icon(Icons.stay_current_landscape,
                    color: !isPortrait ? AppColors.accent : AppColors.textSecondaryDark),
                onPressed: () => setState(() => _orientation = DeviceOrientation2.landscape),
              ),
              const Spacer(),
              const Icon(Icons.zoom_out, size: 18, color: AppColors.textSecondaryDark),
              SizedBox(
                width: 120,
                child: Slider(
                  value: _zoom,
                  min: 0.5,
                  max: 1.5,
                  onChanged: (v) => setState(() => _zoom = v),
                ),
              ),
              const Icon(Icons.zoom_in, size: 18, color: AppColors.textSecondaryDark),
              IconButton(
                tooltip: 'Refresh',
                icon: const Icon(Icons.refresh, size: 20),
                onPressed: () => _controller?.reload(),
              ),
            ],
          ),
        ),
        Expanded(
          child: Center(
            child: SingleChildScrollView(
              child: Transform.scale(
                scale: _zoom,
                child: Container(
                  width: baseWidth,
                  height: baseHeight,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.borderDark, width: 6),
                    boxShadow: const [
                      BoxShadow(color: Colors.black54, blurRadius: 20, offset: Offset(0, 8)),
                    ],
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: widget.previewUrl != null && _controller != null
                      ? WebViewWidget(controller: _controller!)
                      : Center(
                          child: widget.placeholder ??
                              const Text('No preview', style: TextStyle(color: Colors.black45)),
                        ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
