import 'package:flutter/material.dart';

import 'core/app_scope.dart';
import 'core/constants/app_constants.dart';
import 'core/theme/app_theme.dart';
import 'features/authentication/login_screen.dart';
import 'features/shell/main_shell.dart';
import 'services/app_services.dart';
import 'services/auth/auth_service.dart';
import 'shared/widgets/splash_view.dart';

class RilzMusicApp extends StatefulWidget {
  const RilzMusicApp({super.key, required this.services});

  final AppServices services;

  @override
  State<RilzMusicApp> createState() => _RilzMusicAppState();
}

class _RilzMusicAppState extends State<RilzMusicApp> {
  final AuthService _auth = AuthService();

  @override
  void initState() {
    super.initState();
    _auth.restoreSession();
  }

  @override
  void dispose() {
    _auth.dispose();
    widget.services.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      services: widget.services,
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark(),
        home: ListenableBuilder(
          listenable: _auth,
          builder: (BuildContext context, _) {
            if (_auth.isRestoring) return const SplashView();
            if (_auth.isSignedIn) return MainShell(auth: _auth);
            return LoginScreen(auth: _auth);
          },
        ),
      ),
    );
  }
}
