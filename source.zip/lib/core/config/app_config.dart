/// Konfigurasi build. Nilai diisi lewat `--dart-define`, tidak pernah ditulis
/// sebagai secret di source code.
///
/// Contoh:
/// flutter run --dart-define=JAMENDO_CLIENT_ID=xxxx --dart-define=GOOGLE_WEB_CLIENT_ID=xxxx.apps.googleusercontent.com
abstract final class AppConfig {
  static const String jamendoClientId =
      String.fromEnvironment('JAMENDO_CLIENT_ID');

  static bool get hasJamendoClientId => jamendoClientId.trim().isNotEmpty;
}
