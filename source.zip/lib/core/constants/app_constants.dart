abstract final class AppConstants {
  static const String appName = 'RilzMusic';
  static const String tagline = 'Dengarkan. Unduh. Nikmati.';
  static const String logoAsset = 'assets/icon/icon.png';
}
