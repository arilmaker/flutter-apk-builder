import 'package:flutter/material.dart';

abstract final class AppColors {
  static const Color background = Color(0xFF0B0F0D);
  static const Color surface = Color(0xFF141B18);
  static const Color green = Color(0xFF22E07A);
  static const Color mint = Color(0xFF3DFFB5);
  static const Color textSecondary = Color(0xFF9AA8A2);
}

abstract final class AppTheme {
  static ThemeData dark() {
    final ColorScheme scheme = ColorScheme.fromSeed(
      seedColor: AppColors.green,
      brightness: Brightness.dark,
    ).copyWith(
      primary: AppColors.green,
      secondary: AppColors.mint,
      surface: AppColors.surface,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: AppColors.background,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.background,
        elevation: 0,
        centerTitle: false,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.green,
          foregroundColor: Colors.black,
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }
}
