import 'track.dart';

/// Track yang sudah tersimpan sebagai file lokal dan bisa diputar saat offline.
class DownloadedTrack {
  const DownloadedTrack({
    required this.track,
    required this.filePath,
    required this.sizeBytes,
    required this.completedAt,
  });

  final Track track;
  final String filePath;
  final int sizeBytes;
  final DateTime completedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'track': track.toJson(),
        'filePath': filePath,
        'sizeBytes': sizeBytes,
        'completedAt': completedAt.toIso8601String(),
      };

  factory DownloadedTrack.fromJson(Map<String, dynamic> json) {
    final Object? rawTrack = json['track'];
    if (rawTrack is! Map<String, dynamic>) {
      throw const FormatException('Data unduhan rusak.');
    }
    final String path = json['filePath'] as String? ?? '';
    if (path.isEmpty) throw const FormatException('Path unduhan kosong.');
    return DownloadedTrack(
      track: Track.fromStorageJson(rawTrack),
      filePath: path,
      sizeBytes: (json['sizeBytes'] as num?)?.toInt() ?? 0,
      completedAt: DateTime.tryParse(json['completedAt'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}
