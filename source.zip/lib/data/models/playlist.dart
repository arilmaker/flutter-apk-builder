import 'track.dart';

/// Playlist yang menyimpan daftar track lengkap (bukan hanya nama).
class Playlist {
  const Playlist({
    required this.id,
    required this.name,
    required this.tracks,
    required this.createdAt,
  });

  final String id;
  final String name;
  final List<Track> tracks;
  final DateTime createdAt;

  Playlist copyWith({String? name, List<Track>? tracks}) => Playlist(
        id: id,
        name: name ?? this.name,
        tracks: tracks ?? this.tracks,
        createdAt: createdAt,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'createdAt': createdAt.toIso8601String(),
        'tracks': tracks.map((Track t) => t.toJson()).toList(),
      };

  factory Playlist.fromJson(Map<String, dynamic> json) {
    final Object? rawTracks = json['tracks'];
    final List<Track> tracks = <Track>[];
    if (rawTracks is List<dynamic>) {
      for (final Object? item in rawTracks) {
        if (item is Map<String, dynamic>) {
          try {
            tracks.add(Track.fromStorageJson(item));
          } on FormatException {
            continue;
          }
        }
      }
    }
    final String id = json['id'] as String? ?? '';
    final String name = json['name'] as String? ?? '';
    if (id.isEmpty || name.isEmpty) {
      throw const FormatException('Data playlist rusak.');
    }
    return Playlist(
      id: id,
      name: name,
      tracks: tracks,
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}
