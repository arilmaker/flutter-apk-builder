/// Model track musik. Dibentuk dari respons Jamendo API atau dari penyimpanan lokal.
class Track {
  const Track({
    required this.id,
    required this.name,
    required this.artistName,
    required this.durationSeconds,
    this.artistId,
    this.albumName,
    this.artworkUrl,
    this.audioUrl,
    this.downloadUrl,
    this.downloadAllowed = false,
  });

  final String id;
  final String name;
  final String artistName;
  final String? artistId;
  final String? albumName;
  final int durationSeconds;
  final String? artworkUrl;

  /// URL stream dari field `audio` respons API. Null bila API tidak memberikannya.
  final String? audioUrl;

  /// URL unduhan dari field `audiodownload`. Hanya dipakai bila [downloadAllowed] true.
  final String? downloadUrl;

  /// Field `audiodownload_allowed` dari API. Download hanya boleh bila true.
  final bool downloadAllowed;

  bool get canDownload => downloadAllowed && (downloadUrl ?? '').isNotEmpty;

  /// Parsing satu objek track dari JSON. Melempar [FormatException] bila
  /// field wajib (id, name) tidak valid.
  factory Track.fromJson(Map<String, dynamic> json) {
    final String id = _readString(json['id']) ?? '';
    final String name = _readString(json['name']) ?? '';
    if (id.isEmpty || name.isEmpty) {
      throw const FormatException('Data track tidak lengkap (id/name kosong).');
    }
    return Track(
      id: id,
      name: name,
      artistName: _readString(json['artist_name']) ?? 'Artis tidak diketahui',
      artistId: _readString(json['artist_id']),
      albumName: _readString(json['album_name']),
      durationSeconds: _readInt(json['duration']) ?? 0,
      artworkUrl: _readString(json['album_image']) ?? _readString(json['image']),
      audioUrl: _readString(json['audio']),
      downloadUrl: _readString(json['audiodownload']),
      downloadAllowed: json['audiodownload_allowed'] == true,
    );
  }

  /// Format penyimpanan lokal. Dipakai juga untuk favorit, riwayat, dan playlist.
  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'artistName': artistName,
        'artistId': artistId,
        'albumName': albumName,
        'durationSeconds': durationSeconds,
        'artworkUrl': artworkUrl,
        'audioUrl': audioUrl,
        'downloadUrl': downloadUrl,
        'downloadAllowed': downloadAllowed,
      };

  factory Track.fromStorageJson(Map<String, dynamic> json) {
    final String id = _readString(json['id']) ?? '';
    final String name = _readString(json['name']) ?? '';
    if (id.isEmpty || name.isEmpty) {
      throw const FormatException('Data tersimpan rusak (id/name kosong).');
    }
    return Track(
      id: id,
      name: name,
      artistName: _readString(json['artistName']) ?? 'Artis tidak diketahui',
      artistId: _readString(json['artistId']),
      albumName: _readString(json['albumName']),
      durationSeconds: _readInt(json['durationSeconds']) ?? 0,
      artworkUrl: _readString(json['artworkUrl']),
      audioUrl: _readString(json['audioUrl']),
      downloadUrl: _readString(json['downloadUrl']),
      downloadAllowed: json['downloadAllowed'] == true,
    );
  }

  @override
  bool operator ==(Object other) => other is Track && other.id == id;

  @override
  int get hashCode => id.hashCode;

  static String? _readString(Object? value) {
    if (value is String) {
      final String trimmed = value.trim();
      return trimmed.isEmpty ? null : trimmed;
    }
    if (value is num) return value.toString();
    return null;
  }

  static int? _readInt(Object? value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }
}
