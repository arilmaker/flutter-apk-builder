import 'dart:convert';
import 'dart:io';

import '../../services/download/download_service.dart';
import '../../services/storage/key_value_store.dart';
import '../models/downloaded_track.dart';
import '../models/track.dart';

/// Indeks unduhan offline. File audio disimpan oleh [DownloadService]; repository ini
/// menyimpan daftarnya dan membersihkan entri yang file-nya sudah hilang.
class DownloadRepository {
  DownloadRepository(this._store, this._downloads);

  static const String _key = 'downloads.index.v1';

  final KeyValueStore _store;
  final DownloadService _downloads;

  /// Daftar unduhan yang file-nya masih ada. Entri yatim dihapus otomatis.
  Future<List<DownloadedTrack>> list() async {
    final List<DownloadedTrack> all = await _readAll();
    final List<DownloadedTrack> alive = <DownloadedTrack>[];
    for (final DownloadedTrack item in all) {
      if (await File(item.filePath).exists()) {
        alive.add(item);
      }
    }
    if (alive.length != all.length) await _writeAll(alive);
    return alive;
  }

  Future<DownloadedTrack?> find(String trackId) async {
    for (final DownloadedTrack item in await list()) {
      if (item.track.id == trackId) return item;
    }
    return null;
  }

  Future<void> add(DownloadedTrack entry) async {
    final List<DownloadedTrack> all = await _readAll();
    final List<DownloadedTrack> next = <DownloadedTrack>[
      entry,
      ...all.where((DownloadedTrack d) => d.track.id != entry.track.id),
    ];
    await _writeAll(next);
  }

  /// Menghapus entri dan file-nya dari disk.
  Future<void> remove(String trackId) async {
    final List<DownloadedTrack> all = await _readAll();
    for (final DownloadedTrack item in all) {
      if (item.track.id == trackId) {
        await _downloads.deleteFile(item.filePath);
      }
    }
    await _writeAll(
      all.where((DownloadedTrack d) => d.track.id != trackId).toList(),
    );
  }

  /// Track yang diunduh adalah track yang sama dengan [track] dan file-nya masih ada.
  Future<String?> localPathFor(Track track) async {
    final DownloadedTrack? item = await find(track.id);
    return item?.filePath;
  }

  Future<List<DownloadedTrack>> _readAll() async {
    final String? raw = await _store.read(_key);
    if (raw == null || raw.isEmpty) return <DownloadedTrack>[];
    try {
      final Object? decoded = jsonDecode(raw);
      if (decoded is! List<dynamic>) return <DownloadedTrack>[];
      final List<DownloadedTrack> result = <DownloadedTrack>[];
      for (final Object? item in decoded) {
        if (item is Map<String, dynamic>) {
          try {
            result.add(DownloadedTrack.fromJson(item));
          } on FormatException {
            continue;
          }
        }
      }
      return result;
    } on FormatException {
      return <DownloadedTrack>[];
    }
  }

  Future<void> _writeAll(List<DownloadedTrack> list) => _store.write(
        _key,
        jsonEncode(list.map((DownloadedTrack d) => d.toJson()).toList()),
      );
}
