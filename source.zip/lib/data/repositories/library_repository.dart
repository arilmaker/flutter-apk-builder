import 'dart:convert';

import '../../services/storage/key_value_store.dart';
import '../models/playlist.dart';
import '../models/track.dart';

/// Favorit, riwayat pemutaran, dan playlist yang tersimpan lokal dan bertahan
/// setelah aplikasi ditutup.
class LibraryRepository {
  LibraryRepository(this._store, {DateTime Function()? clock})
      : _clock = clock ?? DateTime.now;

  static const String _favoritesKey = 'library.favorites.v1';
  static const String _historyKey = 'library.history.v1';
  static const String _playlistsKey = 'library.playlists.v1';

  /// Batas riwayat agar penyimpanan tidak membengkak.
  static const int maxHistory = 100;
  static const int maxPlaylistNameLength = 60;

  final KeyValueStore _store;
  final DateTime Function() _clock;

  // ---------- Favorit ----------

  Future<List<Track>> favorites() async => _readTracks(_favoritesKey);

  Future<bool> isFavorite(String trackId) async =>
      (await favorites()).any((Track t) => t.id == trackId);

  Future<void> addFavorite(Track track) async {
    final List<Track> list = await favorites();
    if (list.any((Track t) => t.id == track.id)) return;
    await _writeTracks(_favoritesKey, <Track>[track, ...list]);
  }

  Future<void> removeFavorite(String trackId) async {
    final List<Track> list = await favorites();
    await _writeTracks(
      _favoritesKey,
      list.where((Track t) => t.id != trackId).toList(),
    );
  }

  /// Mengembalikan status favorit terbaru setelah toggle.
  Future<bool> toggleFavorite(Track track) async {
    if (await isFavorite(track.id)) {
      await removeFavorite(track.id);
      return false;
    }
    await addFavorite(track);
    return true;
  }

  // ---------- Riwayat ----------

  /// Riwayat terbaru di urutan pertama.
  Future<List<Track>> history() async => _readTracks(_historyKey);

  Future<void> recordPlayed(Track track) async {
    final List<Track> list = await history();
    final List<Track> next = <Track>[
      track,
      ...list.where((Track t) => t.id != track.id),
    ].take(maxHistory).toList();
    await _writeTracks(_historyKey, next);
  }

  Future<void> clearHistory() => _store.remove(_historyKey);

  // ---------- Playlist ----------

  Future<List<Playlist>> playlists() async {
    final String? raw = await _store.read(_playlistsKey);
    if (raw == null || raw.isEmpty) return <Playlist>[];
    try {
      final Object? decoded = jsonDecode(raw);
      if (decoded is! List<dynamic>) return <Playlist>[];
      final List<Playlist> result = <Playlist>[];
      for (final Object? item in decoded) {
        if (item is Map<String, dynamic>) {
          try {
            result.add(Playlist.fromJson(item));
          } on FormatException {
            continue;
          }
        }
      }
      return result;
    } on FormatException {
      // Data rusak: anggap kosong daripada membuat aplikasi crash.
      return <Playlist>[];
    }
  }

  Future<Playlist> createPlaylist(String name) async {
    final String clean = _validateName(name);
    final List<Playlist> list = await playlists();
    final Playlist created = Playlist(
      id: _clock().microsecondsSinceEpoch.toString(),
      name: clean,
      tracks: const <Track>[],
      createdAt: _clock(),
    );
    await _writePlaylists(<Playlist>[...list, created]);
    return created;
  }

  Future<void> renamePlaylist(String playlistId, String name) async {
    final String clean = _validateName(name);
    final List<Playlist> list = await playlists();
    await _writePlaylists(<Playlist>[
      for (final Playlist p in list)
        if (p.id == playlistId) p.copyWith(name: clean) else p,
    ]);
  }

  Future<void> deletePlaylist(String playlistId) async {
    final List<Playlist> list = await playlists();
    await _writePlaylists(
      list.where((Playlist p) => p.id != playlistId).toList(),
    );
  }

  /// Menambah track ke playlist. Track yang sudah ada tidak diduplikasi.
  Future<void> addTrackToPlaylist(String playlistId, Track track) async {
    final List<Playlist> list = await playlists();
    await _writePlaylists(<Playlist>[
      for (final Playlist p in list)
        if (p.id == playlistId && !p.tracks.any((Track t) => t.id == track.id))
          p.copyWith(tracks: <Track>[...p.tracks, track])
        else
          p,
    ]);
  }

  Future<void> removeTrackFromPlaylist(String playlistId, String trackId) async {
    final List<Playlist> list = await playlists();
    await _writePlaylists(<Playlist>[
      for (final Playlist p in list)
        if (p.id == playlistId)
          p.copyWith(tracks: p.tracks.where((Track t) => t.id != trackId).toList())
        else
          p,
    ]);
  }

  // ---------- Helpers ----------

  String _validateName(String name) {
    final String clean = name.trim();
    if (clean.isEmpty) {
      throw ArgumentError('Nama playlist tidak boleh kosong.');
    }
    if (clean.length > maxPlaylistNameLength) {
      throw ArgumentError(
        'Nama playlist maksimal $maxPlaylistNameLength karakter.',
      );
    }
    return clean;
  }

  Future<List<Track>> _readTracks(String key) async {
    final String? raw = await _store.read(key);
    if (raw == null || raw.isEmpty) return <Track>[];
    try {
      final Object? decoded = jsonDecode(raw);
      if (decoded is! List<dynamic>) return <Track>[];
      final List<Track> result = <Track>[];
      for (final Object? item in decoded) {
        if (item is Map<String, dynamic>) {
          try {
            result.add(Track.fromStorageJson(item));
          } on FormatException {
            continue;
          }
        }
      }
      return result;
    } on FormatException {
      return <Track>[];
    }
  }

  Future<void> _writeTracks(String key, List<Track> tracks) => _store.write(
        key,
        jsonEncode(tracks.map((Track t) => t.toJson()).toList()),
      );

  Future<void> _writePlaylists(List<Playlist> list) => _store.write(
        _playlistsKey,
        jsonEncode(list.map((Playlist p) => p.toJson()).toList()),
      );
}
