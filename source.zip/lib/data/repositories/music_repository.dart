import '../../services/api/jamendo_api_client.dart';
import '../../services/api/jamendo_response_parser.dart';
import '../models/track.dart';

/// Sumber data musik untuk UI. Implementasi nyata memakai Jamendo; tes memakai fake.
abstract interface class MusicRepository {
  bool get isConfigured;

  Future<TrackPage> popular({required int offset, int limit = 20});

  Future<TrackPage> search(String query, {required int offset, int limit = 20});

  /// Rekomendasi. Bila [seedArtistId] ada, memakai artis itu sebagai dasar;
  /// jika tidak, memakai daftar populer bulanan dengan offset berbeda.
  Future<List<Track>> recommendations({String? seedArtistId, int limit = 10});
}

class JamendoMusicRepository implements MusicRepository {
  JamendoMusicRepository(this._client);

  final JamendoApiClient _client;

  /// Parameter yang sama untuk semua permintaan: audio mp3 dan artwork 300px.
  static const Map<String, String> _common = <String, String>{
    'audioformat': 'mp32',
    'audiodlformat': 'mp32',
    'imagesize': '300',
  };

  @override
  bool get isConfigured => _client.isConfigured;

  @override
  Future<TrackPage> popular({required int offset, int limit = 20}) {
    return _client.fetchTracks(
      <String, String>{..._common, 'order': 'popularity_week'},
      offset: offset,
      limit: limit,
    );
  }

  @override
  Future<TrackPage> search(String query, {required int offset, int limit = 20}) {
    final String q = query.trim();
    return _client.fetchTracks(
      <String, String>{..._common, 'search': q},
      offset: offset,
      limit: limit,
    );
  }

  @override
  Future<List<Track>> recommendations({String? seedArtistId, int limit = 10}) async {
    final bool hasSeed = seedArtistId != null && seedArtistId.isNotEmpty;
    final TrackPage page = hasSeed
        ? await _client.fetchTracks(
            <String, String>{
              ..._common,
              'artist_id': seedArtistId,
              'order': 'popularity_month',
            },
            offset: 0,
            limit: limit,
          )
        : await _client.fetchTracks(
            <String, String>{..._common, 'order': 'popularity_month'},
            offset: 10,
            limit: limit,
          );
    return page.tracks;
  }
}
