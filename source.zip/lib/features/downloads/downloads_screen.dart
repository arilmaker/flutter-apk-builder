import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/downloaded_track.dart';
import '../../data/models/track.dart';
import '../../services/app_services.dart';
import '../../shared/widgets/state_views.dart';
import '../../shared/widgets/track_tile.dart';

/// Daftar lagu yang sudah diunduh. Bisa diputar tanpa internet karena memakai file lokal.
class DownloadsScreen extends StatefulWidget {
  const DownloadsScreen({super.key});

  @override
  State<DownloadsScreen> createState() => _DownloadsScreenState();
}

class _DownloadsScreenState extends State<DownloadsScreen> {
  AppServices? _services;
  Future<List<DownloadedTrack>>? _future;
  int _lastActive = 0;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_services != null) return;
    final AppServices services = AppScope.of(context);
    _services = services;
    _lastActive = services.downloadManager.activeCount;
    _future = services.downloads.list();
    services.downloadManager.addListener(_onDownloadsChanged);
  }

  @override
  void dispose() {
    _services?.downloadManager.removeListener(_onDownloadsChanged);
    super.dispose();
  }

  /// Muat ulang hanya ketika sebuah unduhan selesai/gagal (jumlah aktif turun), bukan setiap tick progres.
  void _onDownloadsChanged() {
    final int active = _services?.downloadManager.activeCount ?? 0;
    if (active < _lastActive && mounted) _refresh();
    _lastActive = active;
  }

  void _refresh() {
    setState(() => _future = _services!.downloads.list());
  }

  Future<void> _delete(DownloadedTrack item) async {
    await _services!.downloadManager.remove(item.track.id);
    if (mounted) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final AppServices services = _services ?? AppScope.of(context);
    final player = services.player;

    return Scaffold(
      appBar: AppBar(title: const Text('Unduhan')),
      body: FutureBuilder<List<DownloadedTrack>>(
        future: _future,
        builder: (BuildContext context, AsyncSnapshot<List<DownloadedTrack>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const LoadingView();
          }
          if (snapshot.hasError) {
            return ErrorView(message: 'Daftar unduhan tidak bisa dibuka.', onRetry: _refresh);
          }
          final List<DownloadedTrack> items = snapshot.data ?? <DownloadedTrack>[];
          if (items.isEmpty) {
            return const EmptyView(
              icon: Icons.download_for_offline_rounded,
              title: 'Belum ada unduhan',
              subtitle:
                  'Buka menu lagu lalu pilih "Unduh untuk offline". Hanya lagu yang mengizinkan unduhan yang bisa diunduh.',
            );
          }
          final List<Track> tracks = items.map((DownloadedTrack d) => d.track).toList();
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (BuildContext context, int index) {
              final DownloadedTrack item = items[index];
              final Track track = item.track;
              return TrackTile(
                track: track,
                isActive: player.currentTrack?.id == track.id,
                onTap: () => player.playQueue(tracks, startIndex: index),
                trailingBadge: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(_formatSize(item.sizeBytes),
                        style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                    IconButton(
                      tooltip: 'Hapus unduhan',
                      icon: const Icon(Icons.delete_outline_rounded),
                      onPressed: () => _delete(item),
                    ),
                  ],
                ),
                onMore: null,
              );
            },
          );
        },
      ),
    );
  }

  static String _formatSize(int bytes) {
    if (bytes <= 0) return '';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}
