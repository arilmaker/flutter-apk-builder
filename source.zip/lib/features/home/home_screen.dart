import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/track.dart';
import '../../services/api/music_api_exception.dart';
import '../../shared/widgets/app_logo.dart';
import '../../shared/widgets/artwork.dart';
import '../../shared/widgets/paged_track_list.dart';
import '../../shared/widgets/state_views.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final services = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Row(children: <Widget>[
          const AppLogo(size: 32),
          const SizedBox(width: 10),
          Text(AppConstants.appName),
        ]),
      ),
      body: PagedTrackList(
        emptyIcon: Icons.library_music_rounded,
        emptyTitle: 'Belum ada lagu populer',
        emptySubtitle: 'Coba lagi nanti.',
        loadPage: (int offset) => services.music.popular(offset: offset),
        header: const _HomeHeader(),
      ),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  const _HomeHeader();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text('Rekomendasi untukmu',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ),
        const _RecommendationsRow(),
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 20, 16, 4),
          child: Text('Populer minggu ini',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ),
      ],
    );
  }
}

/// Rekomendasi: bila ada riwayat, memakai artis terakhir yang diputar sebagai dasar.
class _RecommendationsRow extends StatefulWidget {
  const _RecommendationsRow();

  @override
  State<_RecommendationsRow> createState() => _RecommendationsRowState();
}

class _RecommendationsRowState extends State<_RecommendationsRow> {
  Future<List<Track>>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future ??= _load();
  }

  Future<List<Track>> _load() async {
    final services = AppScope.of(context);
    final List<Track> history = await services.library.history();
    final String? seed = history.isEmpty ? null : history.first.artistId;
    return services.music.recommendations(seedArtistId: seed);
  }

  void _retry() => setState(() => _future = _load());

  @override
  Widget build(BuildContext context) {
    final player = AppScope.of(context).player;
    return SizedBox(
      height: 190,
      child: FutureBuilder<List<Track>>(
        future: _future,
        builder: (BuildContext context, AsyncSnapshot<List<Track>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator(color: AppColors.green));
          }
          if (snapshot.hasError) {
            final Object error = snapshot.error!;
            final String message = error is MusicApiException
                ? error.message
                : 'Rekomendasi belum bisa dimuat.';
            return ErrorView(message: message, onRetry: _retry);
          }
          final List<Track> items = snapshot.data ?? <Track>[];
          if (items.isEmpty) {
            return const EmptyView(
              icon: Icons.auto_awesome_rounded,
              title: 'Belum ada rekomendasi',
            );
          }
          return ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (BuildContext context, int index) {
              final Track track = items[index];
              return InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => player.playQueue(items, startIndex: index),
                child: SizedBox(
                  width: 120,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Artwork(url: track.artworkUrl, size: 120, radius: 16),
                      const SizedBox(height: 6),
                      Text(track.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      Text(track.artistName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: AppColors.textSecondary, fontSize: 12)),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
