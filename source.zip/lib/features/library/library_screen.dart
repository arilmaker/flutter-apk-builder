import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../data/models/track.dart';
import '../../services/app_services.dart';
import '../downloads/downloads_screen.dart';
import '../playlist/playlists_screen.dart';
import 'stored_track_list_screen.dart';

/// Hub perpustakaan: pintu masuk ke favorit, riwayat, unduhan, dan playlist.
class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Perpustakaan')),
      body: ListView(
        children: <Widget>[
          _LibraryTile(
            icon: Icons.favorite_rounded,
            title: 'Favorit',
            builder: (_) => StoredTrackListScreen(
              title: 'Favorit',
              loader: (AppServices s) => s.library.favorites(),
              emptyIcon: Icons.favorite_border_rounded,
              emptyTitle: 'Belum ada lagu favorit',
              emptySubtitle: 'Tekan ikon ♥ atau menu lagu untuk menambah favorit.',
              onRemove: (AppServices s, Track t) => s.library.removeFavorite(t.id),
            ),
          ),
          _LibraryTile(
            icon: Icons.history_rounded,
            title: 'Riwayat pemutaran',
            builder: (_) => StoredTrackListScreen(
              title: 'Riwayat',
              loader: (AppServices s) => s.library.history(),
              emptyIcon: Icons.history_toggle_off_rounded,
              emptyTitle: 'Belum ada riwayat',
              emptySubtitle: 'Lagu yang Anda putar akan muncul di sini.',
              clearAllTitle: 'Hapus riwayat?',
              clearAllMessage:
                  'Riwayat pemutaran akan dihapus. Favorit dan playlist tidak terpengaruh.',
              onClearAll: (AppServices s) => s.library.clearHistory(),
            ),
          ),
          _LibraryTile(
            icon: Icons.download_done_rounded,
            title: 'Unduhan',
            builder: (_) => const DownloadsScreen(),
          ),
          _LibraryTile(
            icon: Icons.queue_music_rounded,
            title: 'Playlist',
            builder: (_) => const PlaylistsScreen(),
          ),
        ],
      ),
    );
  }

}

class _LibraryTile extends StatelessWidget {
  const _LibraryTile({required this.icon, required this.title, required this.builder});

  final IconData icon;
  final String title;
  final WidgetBuilder builder;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.green),
      title: Text(title),
      trailing: const Icon(Icons.chevron_right_rounded),
      onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: builder)),
    );
  }
}
