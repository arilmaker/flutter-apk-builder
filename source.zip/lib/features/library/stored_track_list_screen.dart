import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/track.dart';
import '../../services/app_services.dart';
import '../../shared/widgets/state_views.dart';
import '../../shared/widgets/track_actions_sheet.dart';
import '../../shared/widgets/track_tile.dart';

/// Daftar track yang tersimpan lokal (favorit, riwayat). Bisa diputar, dan opsional bisa dihapus.
class StoredTrackListScreen extends StatefulWidget {
  const StoredTrackListScreen({
    super.key,
    required this.title,
    required this.loader,
    required this.emptyIcon,
    required this.emptyTitle,
    this.emptySubtitle,
    this.onRemove,
    this.onClearAll,
    this.clearAllTitle = 'Hapus semua?',
    this.clearAllMessage = '',
  });

  final String title;
  final Future<List<Track>> Function(AppServices services) loader;
  final IconData emptyIcon;
  final String emptyTitle;
  final String? emptySubtitle;

  /// Bila diisi, setiap baris punya tombol hapus yang memanggil fungsi ini.
  final Future<void> Function(AppServices services, Track track)? onRemove;

  /// Bila diisi, AppBar menampilkan tombol "hapus semua" (dengan konfirmasi).
  final Future<void> Function(AppServices services)? onClearAll;
  final String clearAllTitle;
  final String clearAllMessage;

  @override
  State<StoredTrackListScreen> createState() => _StoredTrackListScreenState();
}

class _StoredTrackListScreenState extends State<StoredTrackListScreen> {
  Future<List<Track>>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future ??= widget.loader(AppScope.of(context));
  }

  void _refresh() {
    setState(() => _future = widget.loader(AppScope.of(context)));
  }

  Future<void> _confirmClearAll(AppServices services) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text(widget.clearAllTitle),
        content: Text(widget.clearAllMessage),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    await widget.onClearAll!(services);
    if (mounted) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final AppServices services = AppScope.of(context);
    final player = services.player;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: <Widget>[
          if (widget.onClearAll != null)
            IconButton(
              tooltip: 'Hapus semua',
              icon: const Icon(Icons.delete_sweep_rounded),
              onPressed: () => _confirmClearAll(services),
            ),
        ],
      ),
      body: FutureBuilder<List<Track>>(
        future: _future,
        builder: (BuildContext context, AsyncSnapshot<List<Track>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const LoadingView();
          }
          if (snapshot.hasError) {
            return ErrorView(
              message: 'Data tersimpan tidak bisa dibuka.',
              onRetry: _refresh,
            );
          }
          final List<Track> items = snapshot.data ?? <Track>[];
          if (items.isEmpty) {
            return EmptyView(
              icon: widget.emptyIcon,
              title: widget.emptyTitle,
              subtitle: widget.emptySubtitle,
            );
          }
          return RefreshIndicator(
            color: AppColors.green,
            onRefresh: () async => _refresh(),
            child: ListView.builder(
              itemCount: items.length,
              itemBuilder: (BuildContext context, int index) {
                final Track track = items[index];
                return TrackTile(
                  track: track,
                  isActive: player.currentTrack?.id == track.id,
                  onTap: () => player.playQueue(items, startIndex: index),
                  onMore: () async {
                    await showTrackActions(context, track);
                    if (mounted) _refresh();
                  },
                  trailingBadge: widget.onRemove == null
                      ? null
                      : IconButton(
                          tooltip: 'Hapus',
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () async {
                            await widget.onRemove!(services, track);
                            if (mounted) _refresh();
                          },
                        ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
