import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/artwork.dart';
import 'player_screen.dart';

/// Bar pemutar kecil di atas navigasi bawah. Terlihat di semua tab selama ada lagu.
class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final player = AppScope.of(context).player;
    return ListenableBuilder(
      listenable: player,
      builder: (BuildContext context, _) {
        final track = player.currentTrack;
        if (track == null) return const SizedBox.shrink();

        return Material(
          color: AppColors.surface,
          child: InkWell(
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const PlayerScreen()),
            ),
            child: SizedBox(
              height: 64,
              child: Row(
                children: <Widget>[
                  const SizedBox(width: 12),
                  Artwork(url: track.artworkUrl, size: 44, radius: 8),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          track.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        Text(
                          player.errorMessage ??
                              (player.isBuffering ? 'Memuat…' : track.artistName),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: player.errorMessage != null
                                ? Colors.redAccent
                                : AppColors.textSecondary,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  PlayPauseButton(
                    isPlaying: player.isPlaying,
                    isBuffering: player.isBuffering,
                    onPressed: player.togglePlayPause,
                    size: 36,
                  ),
                  IconButton(
                    tooltip: 'Lagu berikutnya',
                    onPressed: player.hasNext ? player.next : null,
                    icon: const Icon(Icons.skip_next_rounded),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Tombol play/pause dengan indikator buffering. Dipakai di mini dan full player.
class PlayPauseButton extends StatelessWidget {
  const PlayPauseButton({
    super.key,
    required this.isPlaying,
    required this.isBuffering,
    required this.onPressed,
    this.size = 40,
  });

  final bool isPlaying;
  final bool isBuffering;
  final VoidCallback onPressed;
  final double size;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: isPlaying ? 'Jeda' : 'Putar',
      iconSize: size,
      onPressed: onPressed,
      icon: isBuffering
          ? SizedBox(
              width: size,
              height: size,
              child: const Padding(
                padding: EdgeInsets.all(6),
                child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.green),
              ),
            )
          : Icon(
              isPlaying ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded,
              color: AppColors.green,
            ),
    );
  }
}
