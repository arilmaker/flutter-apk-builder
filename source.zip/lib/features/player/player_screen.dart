import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/track.dart';
import '../../services/audio/player_controller.dart';
import '../../shared/widgets/artwork.dart';
import '../../shared/widgets/track_actions_sheet.dart';
import '../../shared/widgets/track_tile.dart';
import 'mini_player.dart';

/// Full player: artwork, seek bar, kontrol, status error/buffering, dan antrean.
class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  /// Nilai slider saat pengguna sedang menggeser. Null = ikut posisi pemutar.
  double? _dragMs;

  @override
  Widget build(BuildContext context) {
    final services = AppScope.of(context);
    final PlayerController player = services.player;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          tooltip: 'Tutup',
          icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Sedang diputar'),
        actions: <Widget>[
          if (player.currentTrack != null)
            IconButton(
              tooltip: 'Opsi lagu',
              icon: const Icon(Icons.more_vert_rounded),
              onPressed: () => showTrackActions(context, player.currentTrack!),
            ),
        ],
      ),
      body: ListenableBuilder(
        listenable: player,
        builder: (BuildContext context, _) {
          final Track? track = player.currentTrack;
          if (track == null) {
            return const Center(
              child: Text('Tidak ada lagu yang diputar.',
                  style: TextStyle(color: AppColors.textSecondary)),
            );
          }
          return Column(
            children: <Widget>[
              if (player.errorMessage != null)
                _ErrorBanner(
                  message: player.errorMessage!,
                  onRetry: player.togglePlayPause,
                ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
                  children: <Widget>[
                    const SizedBox(height: 8),
                    Center(
                      child: Artwork(
                        url: track.artworkUrl,
                        size: _artworkSize(context),
                        radius: 20,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(track.name,
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(track.artistName,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: AppColors.textSecondary)),
                    const SizedBox(height: 20),
                    _buildSeekBar(player),
                    const SizedBox(height: 12),
                    _buildControls(player),
                    const SizedBox(height: 24),
                    const Text('Antrean', style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    _buildQueue(player),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  double _artworkSize(BuildContext context) {
    final double width = MediaQuery.sizeOf(context).width;
    return (width - 48).clamp(180.0, 320.0);
  }

  Widget _buildSeekBar(PlayerController player) {
    final double totalMs = (player.duration?.inMilliseconds ?? 0).toDouble();
    final double posMs = player.position.inMilliseconds.toDouble();
    final bool canSeek = totalMs > 0 && player.errorMessage == null;
    final double rawValue = _dragMs ?? (totalMs > 0 ? posMs : 0.0);
    final double value = rawValue.clamp(0.0, totalMs > 0 ? totalMs : 1.0).toDouble();

    return Column(
      children: <Widget>[
        Slider(
          value: value,
          max: totalMs > 0 ? totalMs : 1.0,
          activeColor: AppColors.green,
          onChanged: canSeek ? (double v) => setState(() => _dragMs = v) : null,
          onChangeEnd: canSeek
              ? (double v) {
                  setState(() => _dragMs = null);
                  player.seek(Duration(milliseconds: v.round()));
                }
              : null,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(_fmt(Duration(milliseconds: value.round()))),
            Text(totalMs > 0
                ? _fmt(Duration(milliseconds: totalMs.round()))
                : '--:--'),
          ],
        ),
      ],
    );
  }

  Widget _buildControls(PlayerController player) {
    final services = AppScope.of(context);
    final Track track = player.currentTrack!;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        FutureBuilder<bool>(
          future: services.library.isFavorite(track.id),
          builder: (BuildContext context, AsyncSnapshot<bool> snap) {
            final bool fav = snap.data ?? false;
            return IconButton(
              tooltip: fav ? 'Hapus dari favorit' : 'Tambah ke favorit',
              iconSize: 28,
              icon: Icon(
                fav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: AppColors.green,
              ),
              onPressed: () async {
                await services.library.toggleFavorite(track);
                if (mounted) setState(() {});
              },
            );
          },
        ),
        IconButton(
          tooltip: 'Sebelumnya',
          iconSize: 36,
          onPressed: player.hasQueue ? player.previous : null,
          icon: const Icon(Icons.skip_previous_rounded),
        ),
        PlayPauseButton(
          isPlaying: player.isPlaying,
          isBuffering: player.isBuffering,
          onPressed: player.togglePlayPause,
          size: 64,
        ),
        IconButton(
          tooltip: 'Berikutnya',
          iconSize: 36,
          onPressed: player.hasNext ? player.next : null,
          icon: const Icon(Icons.skip_next_rounded),
        ),
      ],
    );
  }

  Widget _buildQueue(PlayerController player) {
    final List<Track> queue = player.queue;
    if (queue.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text('Antrean kosong.', style: TextStyle(color: AppColors.textSecondary)),
      );
    }
    return Column(
      children: <Widget>[
        for (int i = 0; i < queue.length; i++)
          TrackTile(
            track: queue[i],
            isActive: i == player.queueIndex,
            onTap: () => player.playAt(i),
            onMore: () => showTrackActions(context, queue[i]),
            trailingBadge: IconButton(
              tooltip: 'Hapus dari antrean',
              icon: const Icon(Icons.close_rounded),
              onPressed: () => player.removeFromQueue(i),
            ),
          ),
      ],
    );
  }

  static String _fmt(Duration d) {
    final String formatted = formatDuration(d);
    return formatted.isEmpty ? '0:00' : formatted;
  }
}

class _ErrorBanner extends StatelessWidget {
  const _ErrorBanner({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Colors.red.withOpacity(0.15),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: <Widget>[
          const Icon(Icons.error_outline_rounded, color: Colors.redAccent),
          const SizedBox(width: 8),
          Expanded(child: Text(message)),
          TextButton(onPressed: onRetry, child: const Text('Coba lagi')),
        ],
      ),
    );
  }
}
