import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/playlist.dart';
import '../../data/models/track.dart';
import '../../data/repositories/library_repository.dart';

/// Sheet untuk menambah [track] ke playlist yang ada, atau membuat playlist baru.
Future<void> showAddToPlaylistSheet(BuildContext context, Track track) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppColors.surface,
    isScrollControlled: true,
    builder: (BuildContext sheetContext) => _AddToPlaylistSheet(track: track),
  );
}

class _AddToPlaylistSheet extends StatefulWidget {
  const _AddToPlaylistSheet({required this.track});

  final Track track;

  @override
  State<_AddToPlaylistSheet> createState() => _AddToPlaylistSheetState();
}

class _AddToPlaylistSheetState extends State<_AddToPlaylistSheet> {
  Future<List<Playlist>>? _playlists;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _playlists ??= AppScope.of(context).library.playlists();
  }

  void _reload() {
    setState(() {
      _playlists = AppScope.of(context).library.playlists();
    });
  }

  Future<void> _addTo(Playlist playlist) async {
    final services = AppScope.of(context);
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final bool alreadyIn = playlist.tracks.any((Track t) => t.id == widget.track.id);
    await services.library.addTrackToPlaylist(playlist.id, widget.track);
    if (!mounted) return;
    Navigator.of(context).pop();
    messenger.showSnackBar(SnackBar(
      content: Text(alreadyIn
          ? 'Sudah ada di "${playlist.name}"'
          : 'Ditambahkan ke "${playlist.name}"'),
    ));
  }

  Future<void> _createNew() async {
    final String? name = await showDialog<String>(
      context: context,
      builder: (BuildContext dialogContext) => const _NamePlaylistDialog(),
    );
    if (name == null || !mounted) return;
    final services = AppScope.of(context);
    try {
      final Playlist created = await services.library.createPlaylist(name);
      await _addTo(created);
    } on ArgumentError catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message.toString())));
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('Tambah ke playlist', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(widget.track.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.add_rounded, color: AppColors.green),
              title: const Text('Buat playlist baru'),
              onTap: _createNew,
            ),
            FutureBuilder<List<Playlist>>(
              future: _playlists,
              builder: (BuildContext context, AsyncSnapshot<List<Playlist>> snapshot) {
                if (snapshot.connectionState != ConnectionState.done) {
                  return const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(child: CircularProgressIndicator(color: AppColors.green)),
                  );
                }
                if (snapshot.hasError) {
                  return ListTile(
                    title: const Text('Gagal memuat playlist'),
                    trailing: IconButton(
                      icon: const Icon(Icons.refresh_rounded),
                      onPressed: _reload,
                    ),
                  );
                }
                final List<Playlist> list = snapshot.data ?? <Playlist>[];
                if (list.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('Belum ada playlist.',
                        style: TextStyle(color: AppColors.textSecondary)),
                  );
                }
                return ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 320),
                  child: ListView(
                    shrinkWrap: true,
                    children: <Widget>[
                      for (final Playlist p in list)
                        ListTile(
                          leading: const Icon(Icons.queue_music_rounded, color: AppColors.green),
                          title: Text(p.name),
                          subtitle: Text('${p.tracks.length} lagu',
                              style: const TextStyle(color: AppColors.textSecondary)),
                          onTap: () => _addTo(p),
                        ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _NamePlaylistDialog extends StatefulWidget {
  const _NamePlaylistDialog({this.initialName = ''});

  final String initialName;

  @override
  State<_NamePlaylistDialog> createState() => _NamePlaylistDialogState();
}

class _NamePlaylistDialogState extends State<_NamePlaylistDialog> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.initialName);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.surface,
      title: const Text('Nama playlist'),
      content: TextField(
        controller: _controller,
        autofocus: true,
        maxLength: LibraryRepository.maxPlaylistNameLength,
        decoration: const InputDecoration(hintText: 'Contoh: Lagu favorit malam'),
        onSubmitted: (String v) => Navigator.of(context).pop(v),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Batal'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(_controller.text),
          child: const Text('Simpan'),
        ),
      ],
    );
  }
}

/// Dialog nama playlist dipakai juga untuk rename; ekspor agar bisa dipakai layar playlist.
Future<String?> showPlaylistNameDialog(BuildContext context, {String initialName = ''}) {
  return showDialog<String>(
    context: context,
    builder: (_) => _NamePlaylistDialog(initialName: initialName),
  );
}
