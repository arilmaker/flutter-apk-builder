import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/playlist.dart';
import '../../data/models/track.dart';
import '../../services/audio/player_controller.dart';
import '../../shared/widgets/state_views.dart';
import '../../shared/widgets/track_actions_sheet.dart';
import '../../shared/widgets/track_tile.dart';

/// Isi playlist: lagu bisa diputar, dan dihapus dari playlist.
class PlaylistDetailScreen extends StatefulWidget {
  const PlaylistDetailScreen({super.key, required this.playlistId});

  final String playlistId;

  @override
  State<PlaylistDetailScreen> createState() => _PlaylistDetailScreenState();
}

class _PlaylistDetailScreenState extends State<PlaylistDetailScreen> {
  Future<Playlist?>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future ??= _load();
  }

  Future<Playlist?> _load() async {
    final List<Playlist> all = await AppScope.of(context).library.playlists();
    for (final Playlist p in all) {
      if (p.id == widget.playlistId) return p;
    }
    return null;
  }

  void _refresh() => setState(() => _future = _load());

  Future<void> _removeTrack(Track track) async {
    await AppScope.of(context).library.removeTrackFromPlaylist(widget.playlistId, track.id);
    if (mounted) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final player = AppScope.of(context).player;

    return FutureBuilder<Playlist?>(
      future: _future,
      builder: (BuildContext context, AsyncSnapshot<Playlist?> snapshot) {
        final Playlist? playlist = snapshot.data;
        return Scaffold(
          appBar: AppBar(
            title: Text(playlist?.name ?? 'Playlist'),
            actions: <Widget>[
              if (playlist != null && playlist.tracks.isNotEmpty)
                IconButton(
                  tooltip: 'Putar semua',
                  icon: const Icon(Icons.play_arrow_rounded),
                  onPressed: () => player.playQueue(playlist.tracks, startIndex: 0),
                ),
            ],
          ),
          body: _buildBody(context, snapshot, playlist, player),
        );
      },
    );
  }

  Widget _buildBody(
    BuildContext context,
    AsyncSnapshot<Playlist?> snapshot,
    Playlist? playlist,
    PlayerController player,
  ) {
    if (snapshot.connectionState != ConnectionState.done) {
      return const LoadingView();
    }
    if (snapshot.hasError) {
      return ErrorView(message: 'Playlist tidak bisa dibuka.', onRetry: _refresh);
    }
    if (playlist == null) {
      return const EmptyView(
        icon: Icons.error_outline_rounded,
        title: 'Playlist sudah tidak ada',
      );
    }
    if (playlist.tracks.isEmpty) {
      return const EmptyView(
        icon: Icons.music_off_rounded,
        title: 'Playlist ini masih kosong',
        subtitle: 'Tambahkan lagu dari menu lagu (⋮) di daftar lagu.',
      );
    }
    return ListView.builder(
      itemCount: playlist.tracks.length,
      itemBuilder: (BuildContext context, int index) {
        final Track track = playlist.tracks[index];
        return TrackTile(
          track: track,
          isActive: player.currentTrack?.id == track.id,
          onTap: () => player.playQueue(playlist.tracks, startIndex: index),
          onMore: () async {
            await showTrackActions(context, track);
            if (mounted) _refresh();
          },
          trailingBadge: IconButton(
            tooltip: 'Hapus dari playlist',
            icon: const Icon(Icons.remove_circle_outline_rounded),
            onPressed: () => _removeTrack(track),
          ),
        );
      },
    );
  }
}
