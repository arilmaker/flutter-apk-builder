import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/playlist.dart';
import '../../shared/widgets/state_views.dart';
import 'add_to_playlist_sheet.dart';
import 'playlist_detail_screen.dart';

/// Daftar playlist: buat, ganti nama, dan hapus. Ketuk untuk membuka isinya.
class PlaylistsScreen extends StatefulWidget {
  const PlaylistsScreen({super.key});

  @override
  State<PlaylistsScreen> createState() => _PlaylistsScreenState();
}

class _PlaylistsScreenState extends State<PlaylistsScreen> {
  Future<List<Playlist>>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future ??= AppScope.of(context).library.playlists();
  }

  void _refresh() {
    setState(() => _future = AppScope.of(context).library.playlists());
  }

  Future<void> _create() async {
    final String? name = await showPlaylistNameDialog(context);
    if (name == null || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      await AppScope.of(context).library.createPlaylist(name);
      _refresh();
    } on ArgumentError catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message.toString())));
    }
  }

  Future<void> _rename(Playlist playlist) async {
    final String? name = await showPlaylistNameDialog(context, initialName: playlist.name);
    if (name == null || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      await AppScope.of(context).library.renamePlaylist(playlist.id, name);
      _refresh();
    } on ArgumentError catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message.toString())));
    }
  }

  Future<void> _delete(Playlist playlist) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Hapus playlist?'),
        content: Text('"${playlist.name}" dan ${playlist.tracks.length} lagu di dalamnya akan dihapus dari daftar.'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    await AppScope.of(context).library.deletePlaylist(playlist.id);
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Playlist')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.green,
        foregroundColor: Colors.black,
        onPressed: _create,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Buat playlist'),
      ),
      body: FutureBuilder<List<Playlist>>(
        future: _future,
        builder: (BuildContext context, AsyncSnapshot<List<Playlist>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const LoadingView();
          }
          if (snapshot.hasError) {
            return ErrorView(message: 'Playlist tidak bisa dibuka.', onRetry: _refresh);
          }
          final List<Playlist> items = snapshot.data ?? <Playlist>[];
          if (items.isEmpty) {
            return const EmptyView(
              icon: Icons.queue_music_rounded,
              title: 'Belum ada playlist',
              subtitle: 'Buat playlist, lalu tambahkan lagu dari menu lagu.',
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 96),
            itemCount: items.length,
            itemBuilder: (BuildContext context, int index) {
              final Playlist playlist = items[index];
              return ListTile(
                leading: const Icon(Icons.queue_music_rounded, color: AppColors.green),
                title: Text(playlist.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${playlist.tracks.length} lagu',
                    style: const TextStyle(color: AppColors.textSecondary)),
                trailing: PopupMenuButton<String>(
                  tooltip: 'Opsi playlist',
                  onSelected: (String action) {
                    if (action == 'rename') _rename(playlist);
                    if (action == 'delete') _delete(playlist);
                  },
                  itemBuilder: (BuildContext context) => const <PopupMenuEntry<String>>[
                    PopupMenuItem<String>(value: 'rename', child: Text('Ganti nama')),
                    PopupMenuItem<String>(value: 'delete', child: Text('Hapus')),
                  ],
                ),
                onTap: () async {
                  await Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) => PlaylistDetailScreen(playlistId: playlist.id),
                  ));
                  if (mounted) _refresh();
                },
              );
            },
          );
        },
      ),
    );
  }
}
