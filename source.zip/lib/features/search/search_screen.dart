import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/paged_track_list.dart';

/// Pencarian berdasarkan judul dan artis. Pencarian dijalankan saat pengguna menekan enter/tombol,
/// bukan setiap huruf, agar tidak membuang kuota API.
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();
  String _submitted = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit(String raw) {
    final String query = raw.trim();
    if (query.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() => _submitted = query);
  }

  @override
  Widget build(BuildContext context) {
    final services = AppScope.of(context);

    final Widget searchField = Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: TextField(
        controller: _controller,
        textInputAction: TextInputAction.search,
        onSubmitted: _submit,
        decoration: InputDecoration(
          hintText: 'Cari judul lagu atau artis',
          prefixIcon: const Icon(Icons.search_rounded),
          filled: true,
          fillColor: AppColors.surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          suffixIcon: IconButton(
            tooltip: 'Cari',
            icon: const Icon(Icons.arrow_forward_rounded, color: AppColors.green),
            onPressed: () => _submit(_controller.text),
          ),
        ),
      ),
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Cari')),
      body: _submitted.isEmpty
          ? Column(children: <Widget>[
              searchField,
              const Expanded(
                child: Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      'Ketik judul lagu atau nama artis, lalu tekan enter.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.textSecondary),
                    ),
                  ),
                ),
              ),
            ])
          : PagedTrackList(
              key: ValueKey<String>(_submitted),
              header: searchField,
              emptyIcon: Icons.search_off_rounded,
              emptyTitle: 'Tidak ada hasil untuk "$_submitted"',
              emptySubtitle: 'Coba kata kunci lain.',
              loadPage: (int offset) => services.music.search(_submitted, offset: offset),
            ),
    );
  }
}
