import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/config/app_config.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../services/auth/auth_service.dart';
import '../../shared/widgets/app_logo.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.auth});

  final AuthService auth;

  Future<void> _signOut(BuildContext context) async {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    try {
      await auth.signOut();
    } on AuthException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final services = AppScope.of(context);
    final user = auth.user;
    final bool isGuest = user == null || user.isGuest;

    return Scaffold(
      appBar: AppBar(title: const Text('Pengaturan')),
      body: ListView(
        children: <Widget>[
          ListTile(
            leading: const AppLogo(size: 44),
            title: Text(isGuest ? 'Mode tamu' : (user?.displayName ?? 'Pengguna')),
            subtitle: Text(isGuest ? 'Login Google belum dilakukan' : (user?.email ?? ''),
                style: const TextStyle(color: AppColors.textSecondary)),
          ),
          const Divider(),
          ListTile(
            leading: Icon(
              services.isJamendoConfigured ? Icons.check_circle_rounded : Icons.error_outline_rounded,
              color: services.isJamendoConfigured ? AppColors.green : Colors.orangeAccent,
            ),
            title: const Text('Sumber musik (Jamendo)'),
            subtitle: Text(
              services.isJamendoConfigured
                  ? 'Client ID sudah diatur lewat build configuration.'
                  : 'Client ID belum diatur. Lihat README untuk JAMENDO_CLIENT_ID.',
              style: const TextStyle(color: AppColors.textSecondary),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.info_outline_rounded, color: AppColors.green),
            title: const Text('Tentang'),
            subtitle: Text('${AppConstants.appName} • ${AppConstants.tagline}',
                style: const TextStyle(color: AppColors.textSecondary)),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout_rounded, color: Colors.redAccent),
            title: Text(isGuest ? 'Keluar dari mode tamu' : 'Keluar akun'),
            onTap: auth.isBusy ? null : () => _signOut(context),
          ),
          if (!AppConfig.hasJamendoClientId)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Catatan: pencarian dan pemutaran dari Jamendo membutuhkan JAMENDO_CLIENT_ID saat build.',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
              ),
            ),
        ],
      ),
    );
  }
}
