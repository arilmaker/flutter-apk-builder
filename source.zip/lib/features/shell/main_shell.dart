import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../services/auth/auth_service.dart';
import '../home/home_screen.dart';
import '../library/library_screen.dart';
import '../player/mini_player.dart';
import '../search/search_screen.dart';
import '../settings/settings_screen.dart';

/// Kerangka utama setelah login (atau mode tamu): navigasi bawah + mini player.
/// Mini player terlihat di semua tab selama ada lagu yang dimuat.
class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.auth});

  final AuthService auth;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: <Widget>[
          const HomeScreen(),
          const SearchScreen(),
          const LibraryScreen(),
          SettingsScreen(auth: widget.auth),
        ],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          const MiniPlayer(),
          NavigationBar(
            backgroundColor: AppColors.background,
            indicatorColor: AppColors.green.withOpacity(0.25),
            selectedIndex: _index,
            onDestinationSelected: (int i) => setState(() => _index = i),
            destinations: const <NavigationDestination>[
              NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home_rounded),
                label: 'Beranda',
              ),
              NavigationDestination(
                icon: Icon(Icons.search_rounded),
                label: 'Cari',
              ),
              NavigationDestination(
                icon: Icon(Icons.library_music_outlined),
                selectedIcon: Icon(Icons.library_music_rounded),
                label: 'Perpustakaan',
              ),
              NavigationDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings_rounded),
                label: 'Pengaturan',
              ),
            ],
          ),
        ],
      ),
    );
  }
}
