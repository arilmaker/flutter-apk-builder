import 'package:flutter/material.dart';

import 'app.dart';
import 'services/app_services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final AppServices services = await AppServices.create();
  runApp(RilzMusicApp(services: services));
}
