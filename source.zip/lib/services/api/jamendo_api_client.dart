import 'dart:async';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'jamendo_response_parser.dart';
import 'music_api_exception.dart';

/// Klien HTTP untuk Jamendo API v3.0. Menangani Client ID, timeout, dan retry.
class JamendoApiClient {
  JamendoApiClient({
    required String clientId,
    http.Client? httpClient,
    this.baseUrl = 'https://api.jamendo.com/v3.0',
    this.timeout = const Duration(seconds: 12),
    this.maxRetries = 2,
    this.retryDelay = const Duration(milliseconds: 600),
  })  : _clientId = clientId.trim(),
        _http = httpClient ?? http.Client();

  final String _clientId;
  final http.Client _http;
  final String baseUrl;
  final Duration timeout;
  final int maxRetries;
  final Duration retryDelay;

  bool get isConfigured => _clientId.isNotEmpty;

  /// Mengambil daftar track dari endpoint /tracks/.
  Future<TrackPage> fetchTracks(
    Map<String, String> query, {
    required int offset,
    required int limit,
  }) async {
    if (!isConfigured) throw const MusicApiException.missingClientId();

    final Uri uri = Uri.parse('$baseUrl/tracks/').replace(
      queryParameters: <String, String>{
        'client_id': _clientId,
        'format': 'json',
        'limit': '$limit',
        'offset': '$offset',
        ...query,
      },
    );

    final String body = await _getWithRetry(uri);
    return JamendoResponseParser.parseTracks(
      body,
      offset: offset,
      requestedLimit: limit,
    );
  }

  Future<String> _getWithRetry(Uri uri) async {
    int attempt = 0;
    while (true) {
      try {
        return await _getOnce(uri);
      } on MusicApiException catch (e) {
        if (!e.isRetryable || attempt >= maxRetries) rethrow;
      }
      attempt++;
      await Future<void>.delayed(retryDelay * attempt);
    }
  }

  Future<String> _getOnce(Uri uri) async {
    try {
      final http.Response response =
          await _http.get(uri).timeout(timeout);

      if (response.statusCode == 401 || response.statusCode == 403) {
        throw const MusicApiException(
          'Client ID Jamendo ditolak. Periksa JAMENDO_CLIENT_ID.',
        );
      }
      if (response.statusCode >= 500) {
        throw const MusicApiException(
          'Server Jamendo sedang bermasalah. Coba lagi beberapa saat.',
          isRetryable: true,
        );
      }
      if (response.statusCode != 200) {
        throw MusicApiException(
          'Permintaan ke Jamendo gagal (HTTP ${response.statusCode}).',
        );
      }
      return response.body;
    } on TimeoutException {
      throw const MusicApiException(
        'Koneksi ke Jamendo terlalu lama. Periksa jaringan lalu coba lagi.',
        isRetryable: true,
      );
    } on SocketException {
      throw const MusicApiException(
        'Tidak ada koneksi internet. Anda bisa memutar lagu offline dari Unduhan.',
        isRetryable: true,
      );
    } on http.ClientException {
      throw const MusicApiException(
        'Gagal menghubungi Jamendo. Coba lagi.',
        isRetryable: true,
      );
    }
  }

  void close() => _http.close();
}
