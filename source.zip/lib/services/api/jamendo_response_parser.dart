import 'dart:convert';

import '../../data/models/track.dart';
import 'music_api_exception.dart';

/// Hasil satu halaman track dari API.
class TrackPage {
  const TrackPage({
    required this.tracks,
    required this.offset,
    required this.hasMore,
  });

  final List<Track> tracks;
  final int offset;
  final bool hasMore;
}

/// Memvalidasi dan mengurai JSON respons Jamendo. Murni (tanpa I/O) agar mudah diuji.
abstract final class JamendoResponseParser {
  /// [requestedLimit] dipakai untuk menentukan apakah masih ada halaman berikutnya.
  static TrackPage parseTracks(
    String body, {
    required int offset,
    required int requestedLimit,
  }) {
    final Object? decoded = _decode(body);
    if (decoded is! Map<String, dynamic>) {
      throw const MusicApiException('Format respons API tidak dikenali.');
    }

    final Object? headers = decoded['headers'];
    if (headers is! Map<String, dynamic>) {
      throw const MusicApiException('Respons API tidak memiliki header.');
    }

    if (headers['status'] != 'success') {
      final String detail = (headers['error_message'] as String?)?.trim() ?? '';
      throw MusicApiException(
        detail.isEmpty
            ? 'Jamendo mengembalikan error (kode ${headers['code'] ?? '-'}).'
            : 'Jamendo mengembalikan error: $detail',
      );
    }

    final Object? results = decoded['results'];
    if (results is! List<dynamic>) {
      throw const MusicApiException('Respons API tidak berisi daftar hasil.');
    }

    final List<Track> tracks = <Track>[];
    for (final Object? item in results) {
      if (item is! Map<String, dynamic>) continue;
      try {
        tracks.add(Track.fromJson(item));
      } on FormatException {
        // Lewati satu item yang rusak, jangan gagalkan seluruh halaman.
        continue;
      }
    }

    final int received = results.length;
    return TrackPage(
      tracks: tracks,
      offset: offset,
      hasMore: received >= requestedLimit,
    );
  }

  static Object? _decode(String body) {
    if (body.trim().isEmpty) {
      throw const MusicApiException('Respons API kosong.', isRetryable: true);
    }
    try {
      return jsonDecode(body);
    } on FormatException {
      throw const MusicApiException('Respons API bukan JSON yang valid.');
    }
  }
}
