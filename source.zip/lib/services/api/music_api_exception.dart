/// Error dari layanan musik yang sudah berbentuk pesan untuk pengguna.
class MusicApiException implements Exception {
  const MusicApiException(this.message, {this.isRetryable = false});

  /// Client ID kosong atau belum diatur lewat --dart-define.
  const MusicApiException.missingClientId()
      : message =
            'Client ID Jamendo belum diatur. Jalankan dengan --dart-define=JAMENDO_CLIENT_ID=... (lihat README).',
        isRetryable = false;

  final String message;

  /// True bila kegagalan bersifat sementara (timeout, jaringan, 5xx).
  final bool isRetryable;

  @override
  String toString() => message;
}
