import 'dart:async';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../core/config/app_config.dart';
import '../data/models/track.dart';
import '../data/repositories/download_repository.dart';
import '../data/repositories/library_repository.dart';
import '../data/repositories/music_repository.dart';
import 'api/jamendo_api_client.dart';
import 'audio/audio_engine.dart';
import 'audio/player_controller.dart';
import 'download/download_manager.dart';
import 'download/download_service.dart';
import 'storage/key_value_store.dart';

/// Tempat semua service dan repository dibuat sekali. Dibuat di main() dan dibagikan ke UI.
class AppServices {
  AppServices._({
    required this.music,
    required this.library,
    required this.downloads,
    required this.downloadManager,
    required this.player,
    required JamendoApiClient apiClient,
  }) : _apiClient = apiClient;

  final MusicRepository music;
  final LibraryRepository library;
  final DownloadRepository downloads;
  final DownloadManager downloadManager;
  final PlayerController player;
  final JamendoApiClient _apiClient;

  bool get isJamendoConfigured => AppConfig.hasJamendoClientId;

  static Future<AppServices> create({
    KeyValueStore? store,
    AudioEngine? engine,
  }) async {
    final KeyValueStore kv = store ?? SharedPrefsKeyValueStore();

    final JamendoApiClient apiClient =
        JamendoApiClient(clientId: AppConfig.jamendoClientId);
    final MusicRepository music = JamendoMusicRepository(apiClient);

    final LibraryRepository library = LibraryRepository(kv);
    final DownloadService downloadService = DownloadService(
      baseDirectory: () => getApplicationDocumentsDirectory(),
    );
    final DownloadRepository downloads = DownloadRepository(kv, downloadService);
    final DownloadManager downloadManager = DownloadManager(
      service: downloadService,
      repository: downloads,
    );

    final PlayerController player = PlayerController(
      engine: engine ?? JustAudioEngine(),
      resolveSource: (Track track) async {
        final String? localPath = await downloads.localPathFor(track);
        if (localPath != null) return PlaybackSource.local(localPath);
        final String? url = track.audioUrl;
        if (url != null && url.isNotEmpty) return PlaybackSource.remote(url);
        return null;
      },
      onTrackStarted: (Track track) => unawaited(library.recordPlayed(track)),
    );

    return AppServices._(
      music: music,
      library: library,
      downloads: downloads,
      downloadManager: downloadManager,
      player: player,
      apiClient: apiClient,
    );
  }

  /// Membersihkan resource saat aplikasi ditutup: player, unduhan, dan HTTP client.
  void dispose() {
    player.dispose();
    downloadManager.dispose();
    _apiClient.close();
  }

  /// Dipakai tes/UI untuk memastikan folder dokumen tersedia.
  static Future<Directory> documentsDirectory() => getApplicationDocumentsDirectory();
}
