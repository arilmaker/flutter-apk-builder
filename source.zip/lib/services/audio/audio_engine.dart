import 'dart:async';

import 'package:just_audio/just_audio.dart';

/// Status engine yang disederhanakan agar UI dan tes tidak bergantung pada tipe just_audio.
enum EngineStatus { idle, loading, buffering, ready, completed }

/// Abstraksi engine audio. Implementasi nyata memakai just_audio; tes memakai fake.
abstract interface class AudioEngine {
  Stream<EngineStatus> get status;
  Stream<bool> get playing;
  Stream<Duration> get position;
  Stream<Duration?> get duration;

  /// Pesan error dari engine (mis. URL gagal dimuat, koneksi putus saat streaming).
  Stream<String> get errors;

  /// Memuat sumber remote (URL). Mengembalikan durasi bila diketahui.
  Future<Duration?> loadUrl(String url);

  /// Memuat file lokal (hasil unduhan).
  Future<Duration?> loadFile(String path);

  Future<void> play();
  Future<void> pause();
  Future<void> seek(Duration position);
  Future<void> stop();
  Future<void> dispose();
}

/// Implementasi engine dengan package just_audio.
class JustAudioEngine implements AudioEngine {
  JustAudioEngine() : _player = AudioPlayer() {
    _subscriptions.addAll(<StreamSubscription<dynamic>>[
      _player.playerStateStream.listen((PlayerState state) {
        _statusController.add(_mapStatus(state.processingState));
      }),
      _player.playingStream.listen(_playingController.add),
      _player.positionStream.listen(_positionController.add),
      _player.durationStream.listen(_durationController.add),
      _player.playbackEventStream.listen(
        (PlaybackEvent _) {},
        onError: (Object error, StackTrace _) {
          _errorController.add(_describe(error));
        },
      ),
    ]);
  }

  final AudioPlayer _player;
  final List<StreamSubscription<dynamic>> _subscriptions =
      <StreamSubscription<dynamic>>[];

  final StreamController<EngineStatus> _statusController =
      StreamController<EngineStatus>.broadcast();
  final StreamController<bool> _playingController =
      StreamController<bool>.broadcast();
  final StreamController<Duration> _positionController =
      StreamController<Duration>.broadcast();
  final StreamController<Duration?> _durationController =
      StreamController<Duration?>.broadcast();
  final StreamController<String> _errorController =
      StreamController<String>.broadcast();

  @override
  Stream<EngineStatus> get status => _statusController.stream;

  @override
  Stream<bool> get playing => _playingController.stream;

  @override
  Stream<Duration> get position => _positionController.stream;

  @override
  Stream<Duration?> get duration => _durationController.stream;

  @override
  Stream<String> get errors => _errorController.stream;

  @override
  Future<Duration?> loadUrl(String url) => _loadGuarded(() => _player.setUrl(url));

  @override
  Future<Duration?> loadFile(String path) =>
      _loadGuarded(() => _player.setFilePath(path));

  Future<Duration?> _loadGuarded(Future<Duration?> Function() load) async {
    try {
      return await load();
    } on PlayerException catch (e) {
      throw StateError('Gagal memuat audio (${e.code}): ${e.message ?? 'tidak diketahui'}');
    } on PlayerInterruptedException {
      // Dibatalkan karena track lain sudah dimuat; bukan error bagi pengguna.
      return null;
    }
  }

  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> stop() => _player.stop();

  @override
  Future<void> dispose() async {
    for (final StreamSubscription<dynamic> sub in _subscriptions) {
      await sub.cancel();
    }
    _subscriptions.clear();
    await _player.dispose();
    await _statusController.close();
    await _playingController.close();
    await _positionController.close();
    await _durationController.close();
    await _errorController.close();
  }

  static EngineStatus _mapStatus(ProcessingState state) {
    switch (state) {
      case ProcessingState.idle:
        return EngineStatus.idle;
      case ProcessingState.loading:
        return EngineStatus.loading;
      case ProcessingState.buffering:
        return EngineStatus.buffering;
      case ProcessingState.ready:
        return EngineStatus.ready;
      case ProcessingState.completed:
        return EngineStatus.completed;
    }
  }

  static String _describe(Object error) {
    if (error is PlayerException) {
      return 'Pemutaran gagal (${error.code}). Coba putar ulang.';
    }
    return 'Pemutaran gagal. Periksa koneksi lalu coba lagi.';
  }
}
