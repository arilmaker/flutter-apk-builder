import '../../data/models/track.dart';

/// Antrean pemutaran murni (tanpa audio). Menyimpan daftar dan posisi aktif.
class PlaybackQueue {
  final List<Track> _tracks = <Track>[];
  int _index = -1;

  List<Track> get tracks => List<Track>.unmodifiable(_tracks);
  int get index => _index;
  int get length => _tracks.length;
  bool get isEmpty => _tracks.isEmpty;
  Track? get current => (_index >= 0 && _index < _tracks.length) ? _tracks[_index] : null;
  bool get hasNext => _index >= 0 && _index < _tracks.length - 1;
  bool get hasPrevious => _index > 0;

  void setQueue(List<Track> tracks, {int startIndex = 0}) {
    _tracks
      ..clear()
      ..addAll(tracks);
    if (_tracks.isEmpty) {
      _index = -1;
      return;
    }
    _index = startIndex.clamp(0, _tracks.length - 1);
  }

  /// Pindah ke track berikutnya. Mengembalikan null bila sudah di akhir.
  Track? next() {
    if (!hasNext) return null;
    _index++;
    return current;
  }

  /// Pindah ke track sebelumnya. Mengembalikan null bila sudah di awal.
  Track? previous() {
    if (!hasPrevious) return null;
    _index--;
    return current;
  }

  Track? jumpTo(int newIndex) {
    if (newIndex < 0 || newIndex >= _tracks.length) return null;
    _index = newIndex;
    return current;
  }

  /// Menghapus track dari antrean. Indeks aktif disesuaikan agar tetap menunjuk lagu yang sama.
  /// Bila yang dihapus adalah lagu aktif, indeks menunjuk lagu berikutnya (atau sebelumnya di akhir).
  void removeAt(int removeIndex) {
    if (removeIndex < 0 || removeIndex >= _tracks.length) return;
    _tracks.removeAt(removeIndex);
    if (_tracks.isEmpty) {
      _index = -1;
    } else if (removeIndex < _index) {
      _index--;
    } else if (removeIndex == _index) {
      _index = _index.clamp(0, _tracks.length - 1);
    }
  }

  void clear() {
    _tracks.clear();
    _index = -1;
  }
}
