import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../data/models/track.dart';
import 'audio_engine.dart';
import 'playback_queue.dart';

/// Sumber audio yang sudah diselesaikan: URL stream dari API, atau file lokal hasil unduhan.
class PlaybackSource {
  const PlaybackSource.remote(this.value) : isLocal = false;
  const PlaybackSource.local(this.value) : isLocal = true;

  final String value;
  final bool isLocal;
}

/// Menentukan sumber audio untuk sebuah track. Mengembalikan null bila track tidak bisa diputar.
typedef SourceResolver = Future<PlaybackSource?> Function(Track track);

/// Dipanggil saat sebuah track mulai diputar (untuk mencatat riwayat).
typedef TrackStartedCallback = void Function(Track track);

/// Pengendali pemutaran: antrean, next/previous, seek, dan status untuk UI.
/// Harus di-[dispose] saat aplikasi ditutup.
class PlayerController extends ChangeNotifier {
  PlayerController({
    required AudioEngine engine,
    required SourceResolver resolveSource,
    TrackStartedCallback? onTrackStarted,
  })  : _engine = engine,
        _resolveSource = resolveSource,
        _onTrackStarted = onTrackStarted {
    _subscriptions.addAll(<StreamSubscription<dynamic>>[
      _engine.status.listen(_onEngineStatus),
      _engine.playing.listen((bool value) => _update(() => _isPlaying = value)),
      _engine.position.listen((Duration value) => _update(() => _position = value)),
      _engine.duration.listen((Duration? value) => _update(() => _duration = value)),
      _engine.errors.listen((String message) => _update(() {
            _errorMessage = message;
            _status = EngineStatus.idle;
            _isPlaying = false;
          })),
    ]);
  }

  final AudioEngine _engine;
  final SourceResolver _resolveSource;
  final TrackStartedCallback? _onTrackStarted;
  final PlaybackQueue _queue = PlaybackQueue();
  final List<StreamSubscription<dynamic>> _subscriptions =
      <StreamSubscription<dynamic>>[];

  EngineStatus _status = EngineStatus.idle;
  bool _isPlaying = false;
  Duration _position = Duration.zero;
  Duration? _duration;
  String? _errorMessage;
  int _loadToken = 0;
  bool _disposed = false;

  /// Track yang sedang dimuat/diputar, dipakai untuk mini player.
  Track? get currentTrack => _queue.current;
  List<Track> get queue => _queue.tracks;
  int get queueIndex => _queue.index;
  bool get hasNext => _queue.hasNext;
  bool get hasPrevious => _queue.hasPrevious;
  bool get hasQueue => !_queue.isEmpty;

  bool get isPlaying => _isPlaying;
  bool get isBuffering =>
      _status == EngineStatus.loading || _status == EngineStatus.buffering;
  bool get isCompleted => _status == EngineStatus.completed;
  Duration get position => _position;
  Duration? get duration => _duration;
  String? get errorMessage => _errorMessage;

  /// Memulai antrean baru dari [startIndex].
  Future<void> playQueue(List<Track> tracks, {int startIndex = 0}) async {
    if (tracks.isEmpty) return;
    _queue.setQueue(tracks, startIndex: startIndex);
    await _loadCurrent();
  }

  Future<void> playAt(int index) async {
    if (_queue.jumpTo(index) == null) return;
    await _loadCurrent();
  }

  Future<void> togglePlayPause() async {
    if (!hasQueue) return;
    if (_errorMessage != null) {
      await _loadCurrent();
      return;
    }
    if (_isPlaying) {
      await _engine.pause();
    } else if (isCompleted) {
      await _engine.seek(Duration.zero);
      await _engine.play();
    } else {
      await _engine.play();
    }
  }

  Future<void> next() async {
    if (_queue.next() == null) return;
    await _loadCurrent();
  }

  /// Seperti pemutar musik umumnya: bila sudah lewat 3 detik, kembali ke awal lagu dulu.
  Future<void> previous() async {
    if (!hasQueue) return;
    if (_position > const Duration(seconds: 3)) {
      await _engine.seek(Duration.zero);
      return;
    }
    if (_queue.previous() == null) {
      await _engine.seek(Duration.zero);
      return;
    }
    await _loadCurrent();
  }

  Future<void> seek(Duration position) async {
    if (!hasQueue) return;
    await _engine.seek(position);
  }

  /// Menghapus track dari antrean. Bila track yang sedang diputar dihapus, lagu berikutnya dimuat.
  Future<void> removeFromQueue(int index) async {
    final bool removingCurrent = index == _queue.index;
    _queue.removeAt(index);
    if (_queue.isEmpty) {
      await stop();
      return;
    }
    if (removingCurrent) {
      await _loadCurrent();
    } else {
      _update(() {});
    }
  }

  /// Menghentikan pemutaran dan mengosongkan antrean.
  Future<void> stop() async {
    _loadToken++;
    _queue.clear();
    _errorMessage = null;
    _position = Duration.zero;
    _duration = null;
    _isPlaying = false;
    _status = EngineStatus.idle;
    await _engine.stop();
    _notify();
  }

  Future<void> _loadCurrent() async {
    final Track? track = _queue.current;
    if (track == null) return;

    final int token = ++_loadToken;
    _errorMessage = null;
    _position = Duration.zero;
    _duration = null;
    _status = EngineStatus.loading;
    _notify();

    try {
      final PlaybackSource? source = await _resolveSource(track);
      if (token != _loadToken) return;
      if (source == null) {
        _fail('Lagu ini tidak menyediakan audio yang bisa diputar.');
        return;
      }

      final Duration? loaded = source.isLocal
          ? await _engine.loadFile(source.value)
          : await _engine.loadUrl(source.value);
      if (token != _loadToken) return;

      _duration = loaded ?? (track.durationSeconds > 0
          ? Duration(seconds: track.durationSeconds)
          : null);
      _status = EngineStatus.ready;
      // play() di just_audio baru selesai saat pemutaran berhenti, jadi tidak di-await.
      // Error pemutaran dilaporkan lewat stream errors, jadi di sini cukup ditelan.
      unawaited(_engine.play().catchError((Object _) {}));
      _onTrackStarted?.call(track);
      _notify();
    } on StateError catch (e) {
      if (token != _loadToken) return;
      _fail(e.message.toString());
    } catch (_) {
      if (token != _loadToken) return;
      _fail('Gagal memuat lagu. URL audio tidak bisa diakses.');
    }
  }

  void _fail(String message) {
    _errorMessage = message;
    _status = EngineStatus.idle;
    _isPlaying = false;
    _notify();
  }

  void _onEngineStatus(EngineStatus value) {
    _update(() {
      _status = value;
      if (value == EngineStatus.completed) {
        _isPlaying = false;
      }
    });
    if (value == EngineStatus.completed && _queue.hasNext) {
      unawaited(next());
    }
  }

  void _update(VoidCallback change) {
    change();
    _notify();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _loadToken++;
    for (final StreamSubscription<dynamic> sub in _subscriptions) {
      unawaited(sub.cancel());
    }
    _subscriptions.clear();
    unawaited(_engine.dispose());
    super.dispose();
  }
}
