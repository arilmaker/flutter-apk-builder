import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'auth_user.dart';

/// Error yang sudah berbentuk pesan ramah untuk ditampilkan ke pengguna.
class AuthException implements Exception {
  const AuthException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Mengelola sesi: Google Sign-In, mode tamu, dan pemulihan sesi.
class AuthService extends ChangeNotifier {
  AuthService({GoogleSignIn? googleSignIn})
      : _google = googleSignIn ?? _defaultGoogleSignIn();

  /// Web OAuth Client ID. Diisi lewat:
  /// `flutter run --dart-define=GOOGLE_WEB_CLIENT_ID=xxxx.apps.googleusercontent.com`
  static const String _webClientId =
      String.fromEnvironment('GOOGLE_WEB_CLIENT_ID');

  static GoogleSignIn _defaultGoogleSignIn() {
    final String? id = _webClientId.isEmpty ? null : _webClientId;
    return GoogleSignIn(
      scopes: const <String>['email', 'profile'],
      clientId: kIsWeb ? id : null,
      serverClientId: kIsWeb ? null : id,
    );
  }

  final GoogleSignIn _google;

  AuthUser? _user;
  bool _isRestoring = true;
  bool _isBusy = false;

  AuthUser? get user => _user;
  bool get isSignedIn => _user != null;
  bool get isRestoring => _isRestoring;
  bool get isBusy => _isBusy;

  /// Coba pulihkan sesi Google yang tersimpan. Gagal diam-diam = belum login.
  Future<void> restoreSession() async {
    try {
      final GoogleSignInAccount? account = await _google.signInSilently();
      if (account != null) _user = _fromAccount(account);
    } catch (_) {
      // Tidak ada sesi tersimpan; pengguna akan melihat layar login.
    } finally {
      _isRestoring = false;
      notifyListeners();
    }
  }

  Future<void> signInWithGoogle() => _guard(() async {
        final GoogleSignInAccount? account = await _google.signIn();
        // null = dibatalkan pengguna, bukan error.
        if (account != null) _user = _fromAccount(account);
      });

  void continueAsGuest() {
    _user = const AuthUser.guest();
    notifyListeners();
  }

  /// Keluar dari akun Google, atau dari mode tamu tanpa menyentuh plugin Google.
  Future<void> signOut() => _guard(() async {
        if (_user == null || !_user!.isGuest) {
          await _google.signOut();
        }
        _user = null;
      });

  Future<void> _guard(Future<void> Function() action) async {
    if (_isBusy) return;
    _isBusy = true;
    notifyListeners();
    try {
      await action();
    } on PlatformException catch (e) {
      throw AuthException(_friendlyMessage(e));
    } catch (e) {
      throw AuthException('Terjadi kesalahan saat login: $e');
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  AuthUser _fromAccount(GoogleSignInAccount account) => AuthUser(
        id: account.id,
        displayName: account.displayName ?? account.email,
        email: account.email,
        photoUrl: account.photoUrl,
      );

  String _friendlyMessage(PlatformException e) {
    if (e.code == 'sign_in_failed') {
      return 'Login Google gagal (ApiException 10). Pastikan SHA-1 dan '
          'package name sudah terdaftar di Google Cloud Console. Lihat README.';
    }
    return 'Login Google gagal (${e.code}).';
  }
}
