/// Model pengguna yang sudah lepas dari tipe plugin (agar mudah diuji).
class AuthUser {
  const AuthUser({
    required this.id,
    required this.displayName,
    required this.email,
    this.photoUrl,
    this.isGuest = false,
  });

  const AuthUser.guest()
      : id = 'guest',
        displayName = 'Tamu',
        email = '',
        photoUrl = null,
        isGuest = true;

  final String id;
  final String displayName;
  final String email;
  final String? photoUrl;
  final bool isGuest;
}
