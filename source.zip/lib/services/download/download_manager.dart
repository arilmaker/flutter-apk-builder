import 'package:flutter/foundation.dart';

import '../../data/models/downloaded_track.dart';
import '../../data/models/track.dart';
import '../../data/repositories/download_repository.dart';
import 'download_service.dart';

/// Menjalankan unduhan di latar dan memberi tahu UI tentang progresnya.
class DownloadManager extends ChangeNotifier {
  DownloadManager({
    required DownloadService service,
    required DownloadRepository repository,
    DateTime Function()? clock,
  })  : _service = service,
        _repository = repository,
        _clock = clock ?? DateTime.now;

  final DownloadService _service;
  final DownloadRepository _repository;
  final DateTime Function() _clock;

  final Map<String, DownloadProgress> _progress = <String, DownloadProgress>{};
  final Map<String, DownloadCancelToken> _tokens = <String, DownloadCancelToken>{};

  /// Pesan error terakhir per track, untuk ditampilkan di UI.
  final Map<String, String> _errors = <String, String>{};

  bool isDownloading(String trackId) => _tokens.containsKey(trackId);

  /// Jumlah unduhan yang sedang berjalan. Dipakai layar Unduhan untuk tahu kapan daftar perlu dimuat ulang.
  int get activeCount => _tokens.length;
  DownloadProgress? progressFor(String trackId) => _progress[trackId];
  String? errorFor(String trackId) => _errors[trackId];

  /// Mulai mengunduh [track]. Tidak melakukan apa-apa bila sudah berjalan.
  Future<void> start(Track track) async {
    if (!track.canDownload) {
      _errors[track.id] = 'Lagu ini tidak mengizinkan unduhan.';
      notifyListeners();
      return;
    }
    if (isDownloading(track.id)) return;

    final DownloadCancelToken token = DownloadCancelToken();
    _tokens[track.id] = token;
    _errors.remove(track.id);
    _progress[track.id] = const DownloadProgress(0, null);
    notifyListeners();

    try {
      final String path = await _service.download(
        track,
        cancelToken: token,
        onProgress: (DownloadProgress p) {
          _progress[track.id] = p;
          notifyListeners();
        },
      );
      final int size = await _fileSize(path);
      await _repository.add(DownloadedTrack(
        track: track,
        filePath: path,
        sizeBytes: size,
        completedAt: _clock(),
      ));
    } on DownloadCancelledException {
      // Pembatalan oleh pengguna: bukan error.
    } on DownloadException catch (e) {
      _errors[track.id] = e.message;
    } catch (_) {
      _errors[track.id] = 'Unduhan gagal karena kesalahan tak terduga.';
    } finally {
      _tokens.remove(track.id);
      _progress.remove(track.id);
      notifyListeners();
    }
  }

  void cancel(String trackId) {
    _tokens[trackId]?.cancel();
  }

  Future<void> remove(String trackId) async {
    await _repository.remove(trackId);
    notifyListeners();
  }

  Future<int> _fileSize(String path) async {
    try {
      final int size = await _service.fileSize(path);
      return size;
    } catch (_) {
      return 0;
    }
  }
}
