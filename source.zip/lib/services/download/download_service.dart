import 'dart:async';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../../data/models/track.dart';

/// Progres unduhan. [total] null bila server tidak mengirim Content-Length.
class DownloadProgress {
  const DownloadProgress(this.received, this.total);

  final int received;
  final int? total;

  double? get fraction =>
      (total == null || total! <= 0) ? null : (received / total!).clamp(0.0, 1.0);
}

/// Dibatalkan oleh pengguna.
class DownloadCancelledException implements Exception {
  const DownloadCancelledException();
  @override
  String toString() => 'Unduhan dibatalkan.';
}

/// Kegagalan unduhan yang sudah berbentuk pesan untuk pengguna.
class DownloadException implements Exception {
  const DownloadException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Token pembatalan. Memanggil [cancel] akan menutup koneksi yang sedang berjalan.
class DownloadCancelToken {
  bool _cancelled = false;
  http.Client? _client;

  bool get isCancelled => _cancelled;

  void cancel() {
    _cancelled = true;
    _client?.close();
  }

  void attach(http.Client client) => _client = client;
}

/// Mengunduh file audio hasil dari field `audiodownload`. Hanya untuk track yang
/// [Track.canDownload] bernilai true; tidak ada bypass lisensi di sini.
class DownloadService {
  DownloadService({
    required Future<Directory> Function() baseDirectory,
    this.stallTimeout = const Duration(seconds: 30),
  }) : _baseDirectory = baseDirectory;

  final Future<Directory> Function() _baseDirectory;
  final Duration stallTimeout;

  /// Mengunduh [track] ke folder aplikasi. Mengembalikan path file akhir.
  Future<String> download(
    Track track, {
    void Function(DownloadProgress progress)? onProgress,
    DownloadCancelToken? cancelToken,
    http.Client? httpClient,
  }) async {
    if (!track.canDownload) {
      throw const DownloadException(
        'Lagu ini tidak mengizinkan unduhan. Fitur unduh dinonaktifkan untuk lagu ini.',
      );
    }

    final Uri uri = Uri.parse(track.downloadUrl!);
    final http.Client client = httpClient ?? http.Client();
    cancelToken?.attach(client);

    final Directory dir = await _ensureDir();
    final File target = File('${dir.path}/${_safeFileName(track.id)}.mp3');
    final File partial = File('${target.path}.part');

    IOSink? sink;
    try {
      if (cancelToken?.isCancelled ?? false) throw const DownloadCancelledException();

      final http.StreamedResponse response = await client.send(http.Request('GET', uri));
      if (cancelToken?.isCancelled ?? false) throw const DownloadCancelledException();
      if (response.statusCode != 200) {
        throw DownloadException('Server unduhan menolak permintaan (HTTP ${response.statusCode}).');
      }

      final int? total = response.contentLength;
      int received = 0;
      sink = partial.openWrite();

      await for (final List<int> chunk
          in response.stream.timeout(stallTimeout)) {
        if (cancelToken?.isCancelled ?? false) throw const DownloadCancelledException();
        sink.add(chunk);
        received += chunk.length;
        onProgress?.call(DownloadProgress(received, total));
      }

      await sink.flush();
      await sink.close();
      sink = null;

      if (received == 0) {
        throw const DownloadException('Unduhan kosong. Coba lagi nanti.');
      }
      if (await target.exists()) await target.delete();
      await partial.rename(target.path);
      return target.path;
    } on DownloadCancelledException {
      await _cleanup(sink, partial);
      rethrow;
    } on TimeoutException {
      await _cleanup(sink, partial);
      throw const DownloadException('Unduhan terhenti karena koneksi lambat. Coba lagi.');
    } on SocketException {
      await _cleanup(sink, partial);
      throw const DownloadException('Tidak ada koneksi internet. Unduhan dibatalkan.');
    } on http.ClientException {
      await _cleanup(sink, partial);
      if (cancelToken?.isCancelled ?? false) throw const DownloadCancelledException();
      throw const DownloadException('Gagal mengunduh lagu. Coba lagi.');
    } on FileSystemException catch (e) {
      await _cleanup(sink, partial);
      // errno 28 = ENOSPC (ruang penyimpanan habis) di Android/Linux.
      if (e.osError?.errorCode == 28) {
        throw const DownloadException(
          'Ruang penyimpanan tidak cukup. Hapus unduhan lain lalu coba lagi.',
        );
      }
      throw const DownloadException('Gagal menyimpan file unduhan.');
    } finally {
      if (httpClient == null) client.close();
    }
  }

  Future<Directory> _ensureDir() async {
    final Directory base = await _baseDirectory();
    final Directory dir = Directory('${base.path}/downloads');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<void> _cleanup(IOSink? sink, File partial) async {
    try {
      await sink?.close();
    } catch (_) {
      // Abaikan: file sementara akan dihapus di bawah.
    }
    try {
      if (await partial.exists()) await partial.delete();
    } catch (_) {
      // Tidak fatal.
    }
  }

  /// Menghapus file unduhan dari disk. Aman dipanggil bila file sudah tidak ada.
  Future<void> deleteFile(String path) async {
    final File file = File(path);
    if (await file.exists()) await file.delete();
  }

  Future<int> fileSize(String path) async {
    final File file = File(path);
    if (!await file.exists()) return 0;
    return file.length();
  }

  static String _safeFileName(String id) =>
      id.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
}
