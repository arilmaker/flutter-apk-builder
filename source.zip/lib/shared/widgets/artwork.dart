import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';

/// Artwork track dari URL API. Menampilkan placeholder bila URL kosong atau gagal dimuat.
class Artwork extends StatelessWidget {
  const Artwork({super.key, this.url, this.size = 56, this.radius = 12});

  final String? url;
  final double size;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final Widget placeholder = Container(
      width: size,
      height: size,
      color: AppColors.surface,
      alignment: Alignment.center,
      child: Icon(Icons.music_note_rounded, color: AppColors.green, size: size * 0.45),
    );

    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: (url == null || url!.isEmpty)
          ? placeholder
          : Image.network(
              url!,
              width: size,
              height: size,
              fit: BoxFit.cover,
              cacheWidth: (size * 3).round(),
              errorBuilder: (_, __, ___) => placeholder,
              loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? progress) {
                return progress == null ? child : placeholder;
              },
            ),
    );
  }
}
