import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/track.dart';
import '../../services/api/jamendo_response_parser.dart';
import '../../services/api/music_api_exception.dart';
import 'state_views.dart';
import 'track_actions_sheet.dart';
import 'track_tile.dart';

/// Daftar track dengan paginasi, loading, error + retry, dan empty state.
/// Tap pada lagu memutar seluruh daftar yang sudah dimuat, mulai dari lagu tersebut.
class PagedTrackList extends StatefulWidget {
  const PagedTrackList({
    super.key,
    required this.loadPage,
    required this.emptyIcon,
    required this.emptyTitle,
    this.emptySubtitle,
    this.header,
    this.pageSize = 20,
  });

  /// Memuat satu halaman. Menerima [offset] dan mengembalikan [TrackPage].
  final Future<TrackPage> Function(int offset) loadPage;
  final IconData emptyIcon;
  final String emptyTitle;
  final String? emptySubtitle;
  final Widget? header;
  final int pageSize;

  @override
  State<PagedTrackList> createState() => _PagedTrackListState();
}

class _PagedTrackListState extends State<PagedTrackList> {
  final List<Track> _tracks = <Track>[];
  int _nextOffset = 0;
  bool _hasMore = true;
  bool _loading = false;
  bool _loadedOnce = false;
  String? _error;
  int _generation = 0;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    _generation++;
    _tracks.clear();
    _nextOffset = 0;
    _hasMore = true;
    _loadedOnce = false;
    _error = null;
    await _loadMore();
  }

  Future<void> _loadMore() async {
    if (_loading || !_hasMore) return;
    final int generation = _generation;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final TrackPage page = await widget.loadPage(_nextOffset);
      if (!mounted || generation != _generation) return;
      setState(() {
        _tracks.addAll(page.tracks);
        _nextOffset = page.offset + widget.pageSize;
        _hasMore = page.hasMore;
      });
    } on MusicApiException catch (e) {
      if (!mounted || generation != _generation) return;
      setState(() => _error = e.message);
    } catch (_) {
      if (!mounted || generation != _generation) return;
      setState(() => _error = 'Terjadi kesalahan tak terduga. Coba lagi.');
    } finally {
      if (mounted && generation == _generation) {
        setState(() {
          _loading = false;
          _loadedOnce = true;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final player = AppScope.of(context).player;

    if (!_loadedOnce && _loading) {
      return Column(children: <Widget>[
        if (widget.header != null) widget.header!,
        const Expanded(child: LoadingView(message: 'Memuat lagu…')),
      ]);
    }

    if (_tracks.isEmpty && _error != null) {
      return Column(children: <Widget>[
        if (widget.header != null) widget.header!,
        Expanded(child: ErrorView(message: _error!, onRetry: _reload)),
      ]);
    }

    if (_tracks.isEmpty) {
      return Column(children: <Widget>[
        if (widget.header != null) widget.header!,
        Expanded(
          child: EmptyView(
            icon: widget.emptyIcon,
            title: widget.emptyTitle,
            subtitle: widget.emptySubtitle,
          ),
        ),
      ]);
    }

    return ListenableBuilder(
      listenable: player,
      builder: (BuildContext context, _) {
        final String? activeId = player.currentTrack?.id;
        final int extra = (widget.header != null ? 1 : 0) + 1;
        return ListView.builder(
          itemCount: _tracks.length + extra,
          itemBuilder: (BuildContext context, int index) {
            if (widget.header != null && index == 0) return widget.header!;
            final int trackIndex = index - (widget.header != null ? 1 : 0);

            if (trackIndex == _tracks.length) {
              return _Footer(
                loading: _loading,
                hasMore: _hasMore,
                error: _error,
                onMore: _loadMore,
              );
            }

            final Track track = _tracks[trackIndex];
            return TrackTile(
              track: track,
              isActive: track.id == activeId,
              onTap: () => player.playQueue(_tracks, startIndex: trackIndex),
              onMore: () => showTrackActions(context, track),
            );
          },
        );
      },
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer({
    required this.loading,
    required this.hasMore,
    required this.error,
    required this.onMore,
  });

  final bool loading;
  final bool hasMore;
  final String? error;
  final VoidCallback onMore;

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Center(child: CircularProgressIndicator(color: AppColors.green)),
      );
    }
    if (error != null) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: <Widget>[
          Text(error!, textAlign: TextAlign.center),
          const SizedBox(height: 8),
          OutlinedButton(onPressed: onMore, child: const Text('Coba lagi')),
        ]),
      );
    }
    if (!hasMore) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Center(
          child: Text('Semua hasil sudah ditampilkan',
              style: TextStyle(color: AppColors.textSecondary)),
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Center(
        child: OutlinedButton(onPressed: onMore, child: const Text('Muat lebih banyak')),
      ),
    );
  }
}
