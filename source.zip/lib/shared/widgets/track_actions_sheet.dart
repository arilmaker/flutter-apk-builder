import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/track.dart';
import '../../features/playlist/add_to_playlist_sheet.dart';
import '../../services/app_services.dart';

/// Menu aksi untuk satu track: favorit, unduhan offline, dan tambah ke playlist.
Future<void> showTrackActions(BuildContext context, Track track) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppColors.surface,
    builder: (BuildContext sheetContext) =>
        _TrackActionsSheet(track: track, hostContext: context),
  );
}

class _TrackActionsSheet extends StatefulWidget {
  const _TrackActionsSheet({required this.track, required this.hostContext});

  final Track track;

  /// Context halaman pemanggil. Dipakai untuk membuka sheet lain setelah sheet ini ditutup.
  final BuildContext hostContext;

  @override
  State<_TrackActionsSheet> createState() => _TrackActionsSheetState();
}

class _TrackActionsSheetState extends State<_TrackActionsSheet> {
  @override
  Widget build(BuildContext context) {
    final services = AppScope.of(context);
    final Track track = widget.track;

    return SafeArea(
      child: ListenableBuilder(
        listenable: services.downloadManager,
        builder: (BuildContext context, _) {
          return FutureBuilder<bool>(
            future: services.library.isFavorite(track.id),
            builder: (BuildContext context, AsyncSnapshot<bool> favSnap) {
              final bool isFavorite = favSnap.data ?? false;
              return FutureBuilder<bool>(
                future: services.downloads.find(track.id).then((item) => item != null),
                builder: (BuildContext context, AsyncSnapshot<bool> dlSnap) {
                  final bool downloaded = dlSnap.data ?? false;
                  final bool downloading = services.downloadManager.isDownloading(track.id);
                  final progress = services.downloadManager.progressFor(track.id);
                  final String? error = services.downloadManager.errorFor(track.id);

                  return Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      ListTile(
                        title: Text(track.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(track.artistName,
                            style: const TextStyle(color: AppColors.textSecondary)),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: Icon(
                          isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                          color: AppColors.green,
                        ),
                        title: Text(isFavorite ? 'Hapus dari favorit' : 'Tambah ke favorit'),
                        onTap: () async {
                          await services.library.toggleFavorite(track);
                          if (context.mounted) setState(() {});
                        },
                      ),
                      ListTile(
                        leading: const Icon(Icons.playlist_add_rounded, color: AppColors.green),
                        title: const Text('Tambah ke playlist'),
                        onTap: () {
                          Navigator.of(context).pop();
                          showAddToPlaylistSheet(widget.hostContext, track);
                        },
                      ),
                      _downloadTile(
                        services: services,
                        track: track,
                        downloaded: downloaded,
                        downloading: downloading,
                        progressFraction: progress?.fraction,
                        error: error,
                      ),
                    ],
                  );
                },
              );
            },
          );
        },
      ),
    );
  }

  Widget _downloadTile({
    required AppServices services,
    required Track track,
    required bool downloaded,
    required bool downloading,
    required double? progressFraction,
    required String? error,
  }) {
    if (!track.canDownload) {
      return const ListTile(
        leading: Icon(Icons.block_rounded, color: AppColors.textSecondary),
        title: Text('Unduh tidak tersedia'),
        subtitle: Text(
          'Lagu ini tidak mengizinkan unduhan.',
          style: TextStyle(color: AppColors.textSecondary),
        ),
        enabled: false,
      );
    }
    if (downloaded) {
      return ListTile(
        leading: const Icon(Icons.delete_outline_rounded, color: AppColors.green),
        title: const Text('Hapus unduhan'),
        subtitle: const Text('Tersedia offline'),
        onTap: () async {
          await services.downloadManager.remove(track.id);
          if (mounted) setState(() {});
        },
      );
    }
    if (downloading) {
      return ListTile(
        leading: const SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.green),
        ),
        title: Text(progressFraction == null
            ? 'Mengunduh…'
            : 'Mengunduh ${(progressFraction * 100).round()}%'),
        trailing: IconButton(
          tooltip: 'Batalkan unduhan',
          icon: const Icon(Icons.close_rounded),
          onPressed: () => services.downloadManager.cancel(track.id),
        ),
      );
    }
    return ListTile(
      leading: const Icon(Icons.download_rounded, color: AppColors.green),
      title: const Text('Unduh untuk offline'),
      subtitle: error == null
          ? null
          : Text(error, style: const TextStyle(color: Colors.redAccent)),
      onTap: () {
        services.downloadManager.start(track);
      },
    );
  }
}
