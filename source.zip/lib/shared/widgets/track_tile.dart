import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../data/models/track.dart';
import 'artwork.dart';

/// Baris track yang dipakai di seluruh daftar: artwork, judul, artis, dan tombol menu.
class TrackTile extends StatelessWidget {
  const TrackTile({
    super.key,
    required this.track,
    required this.onTap,
    this.onMore,
    this.trailingBadge,
    this.isActive = false,
  });

  final Track track;
  final VoidCallback onTap;
  final VoidCallback? onMore;
  final Widget? trailingBadge;

  /// True bila track ini sedang diputar; judulnya diberi warna aksen.
  final bool isActive;

  @override
  Widget build(BuildContext context) {
    final String duration = formatDuration(Duration(seconds: track.durationSeconds));
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
      leading: Artwork(url: track.artworkUrl),
      title: Text(
        track.name,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontWeight: FontWeight.w600,
          color: isActive ? AppColors.mint : null,
        ),
      ),
      subtitle: Text(
        '${track.artistName}${duration.isEmpty ? '' : ' • $duration'}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: AppColors.textSecondary),
      ),
      onTap: onTap,
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (trailingBadge != null) trailingBadge!,
          if (onMore != null)
            IconButton(
              tooltip: 'Opsi lagu',
              icon: const Icon(Icons.more_vert_rounded),
              onPressed: onMore,
            ),
        ],
      ),
    );
  }
}

/// Format durasi menjadi m:ss atau h:mm:ss. Mengembalikan string kosong bila durasi nol.
String formatDuration(Duration d) {
  if (d.inSeconds <= 0) return '';
  final int hours = d.inHours;
  final int minutes = d.inMinutes.remainder(60);
  final String seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  if (hours > 0) {
    return '$hours:${minutes.toString().padLeft(2, '0')}:$seconds';
  }
  return '$minutes:$seconds';
}
