import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:rilzmusic/data/repositories/music_repository.dart';
import 'package:rilzmusic/services/api/jamendo_api_client.dart';
import 'package:rilzmusic/services/api/music_api_exception.dart';

const String _okBody =
    '{"headers":{"status":"success","code":0,"error_message":"","results_count":1},'
    '"results":[{"id":"55","name":"Pagi","artist_name":"A","audio":"https://s.test/55.mp3",'
    '"audiodownload_allowed":false}]}';

void main() {
  test('Client ID kosong menolak request tanpa mengirim apa pun', () async {
    int calls = 0;
    final JamendoMusicRepository repo = JamendoMusicRepository(JamendoApiClient(
      clientId: '   ',
      httpClient: MockClient((http.Request _) async {
        calls++;
        return http.Response(_okBody, 200);
      }),
    ));

    await expectLater(
      repo.popular(offset: 0),
      throwsA(isA<MusicApiException>().having(
        (MusicApiException e) => e.message,
        'message',
        contains('JAMENDO_CLIENT_ID'),
      )),
    );
    expect(calls, 0, reason: 'Tidak boleh ada request tanpa Client ID.');
  });

  test('request menyertakan client_id, limit, offset, dan parameter query', () async {
    late Uri captured;
    final JamendoApiClient client = JamendoApiClient(
      clientId: 'TEST_ID',
      httpClient: MockClient((http.Request request) async {
        captured = request.url;
        return http.Response(_okBody, 200);
      }),
    );

    final page = await client.fetchTracks(
      <String, String>{'search': 'pagi', 'order': 'popularity_week'},
      offset: 20,
      limit: 10,
    );

    expect(captured.host, 'api.jamendo.com');
    expect(captured.path, '/v3.0/tracks/');
    expect(captured.queryParameters['client_id'], 'TEST_ID');
    expect(captured.queryParameters['format'], 'json');
    expect(captured.queryParameters['limit'], '10');
    expect(captured.queryParameters['offset'], '20');
    expect(captured.queryParameters['search'], 'pagi');
    expect(page.tracks.single.audioUrl, 'https://s.test/55.mp3');
  });

  test('error 500 dicoba ulang lalu berhasil', () async {
    int calls = 0;
    final JamendoMusicRepository repo = JamendoMusicRepository(JamendoApiClient(
      clientId: 'ID',
      retryDelay: Duration.zero,
      httpClient: MockClient((http.Request _) async {
        calls++;
        return calls == 1 ? http.Response('oops', 500) : http.Response(_okBody, 200);
      }),
    ));

    final page = await repo.popular(offset: 0);

    expect(calls, 2);
    expect(page.tracks, hasLength(1));
  });

  test('error 503 terus-menerus berhenti setelah maxRetries', () async {
    int calls = 0;
    final JamendoMusicRepository repo = JamendoMusicRepository(JamendoApiClient(
      clientId: 'ID',
      maxRetries: 2,
      retryDelay: Duration.zero,
      httpClient: MockClient((http.Request _) async {
        calls++;
        return http.Response('oops', 503);
      }),
    ));

    await expectLater(
      repo.popular(offset: 0),
      throwsA(isA<MusicApiException>().having((e) => e.isRetryable, 'retryable', isTrue)),
    );
    expect(calls, 3, reason: '1 percobaan awal + 2 retry.');
  });

  test('401 tidak diulang dan menjelaskan Client ID ditolak', () async {
    int calls = 0;
    final JamendoMusicRepository repo = JamendoMusicRepository(JamendoApiClient(
      clientId: 'SALAH',
      retryDelay: Duration.zero,
      httpClient: MockClient((http.Request _) async {
        calls++;
        return http.Response('', 401);
      }),
    ));

    await expectLater(
      repo.popular(offset: 0),
      throwsA(isA<MusicApiException>().having((e) => e.message, 'message', contains('ditolak'))),
    );
    expect(calls, 1);
  });

  test('body kosong dari server ditangani sebagai error', () async {
    final JamendoMusicRepository repo = JamendoMusicRepository(JamendoApiClient(
      clientId: 'ID',
      maxRetries: 0,
      httpClient: MockClient((http.Request _) async => http.Response('', 200)),
    ));

    await expectLater(
      repo.search('apa saja', offset: 0),
      throwsA(isA<MusicApiException>()),
    );
  });
}
