import 'package:flutter_test/flutter_test.dart';
import 'package:rilzmusic/services/auth/auth_service.dart';
import 'package:rilzmusic/services/auth/auth_user.dart';

void main() {
  group('AuthUser', () {
    test('guest user is marked as guest', () {
      const AuthUser guest = AuthUser.guest();
      expect(guest.isGuest, isTrue);
      expect(guest.displayName, 'Tamu');
      expect(guest.email, isEmpty);
    });
  });

  group('AuthService', () {
    test('starts signed out and restoring', () {
      final AuthService auth = AuthService();
      expect(auth.isSignedIn, isFalse);
      expect(auth.isRestoring, isTrue);
      expect(auth.isBusy, isFalse);
      auth.dispose();
    });

    test('continueAsGuest signs in as guest and notifies listeners', () {
      final AuthService auth = AuthService();
      int notifications = 0;
      auth.addListener(() => notifications++);

      auth.continueAsGuest();

      expect(auth.isSignedIn, isTrue);
      expect(auth.user?.isGuest, isTrue);
      expect(notifications, 1);
      auth.dispose();
    });
  });
}
