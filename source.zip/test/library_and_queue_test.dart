import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:rilzmusic/data/models/downloaded_track.dart';
import 'package:rilzmusic/data/models/track.dart';
import 'package:rilzmusic/data/repositories/download_repository.dart';
import 'package:rilzmusic/data/repositories/library_repository.dart';
import 'package:rilzmusic/services/audio/playback_queue.dart';
import 'package:rilzmusic/services/download/download_service.dart';
import 'package:rilzmusic/services/storage/key_value_store.dart';

Track _t(String id) => Track(
      id: id,
      name: 'Lagu $id',
      artistName: 'Artis $id',
      durationSeconds: 100,
      audioUrl: 'https://s.test/$id.mp3',
    );

void main() {
  group('LibraryRepository - favorit', () {
    late LibraryRepository repo;
    setUp(() => repo = LibraryRepository(InMemoryKeyValueStore()));

    test('tambah, cek, dan hapus favorit', () async {
      await repo.addFavorite(_t('1'));
      expect(await repo.isFavorite('1'), isTrue);
      expect((await repo.favorites()).map((Track t) => t.id), <String>['1']);

      await repo.removeFavorite('1');
      expect(await repo.isFavorite('1'), isFalse);
      expect(await repo.favorites(), isEmpty);
    });

    test('tidak ada duplikat favorit', () async {
      await repo.addFavorite(_t('1'));
      await repo.addFavorite(_t('1'));
      expect(await repo.favorites(), hasLength(1));
    });

    test('toggleFavorite mengembalikan status terbaru', () async {
      expect(await repo.toggleFavorite(_t('1')), isTrue);
      expect(await repo.toggleFavorite(_t('1')), isFalse);
    });
  });

  group('LibraryRepository - riwayat', () {
    test('lagu yang diputar ulang pindah ke urutan teratas', () async {
      final LibraryRepository repo = LibraryRepository(InMemoryKeyValueStore());
      await repo.recordPlayed(_t('1'));
      await repo.recordPlayed(_t('2'));
      await repo.recordPlayed(_t('1'));

      expect((await repo.history()).map((Track t) => t.id), <String>['1', '2']);
    });

    test('riwayat dibatasi maxHistory dan bisa dihapus', () async {
      final LibraryRepository repo = LibraryRepository(InMemoryKeyValueStore());
      for (int i = 0; i < LibraryRepository.maxHistory + 5; i++) {
        await repo.recordPlayed(_t('$i'));
      }
      expect(await repo.history(), hasLength(LibraryRepository.maxHistory));

      await repo.clearHistory();
      expect(await repo.history(), isEmpty);
    });
  });

  group('LibraryRepository - playlist (CRUD)', () {
    late LibraryRepository repo;
    setUp(() => repo = LibraryRepository(InMemoryKeyValueStore()));

    test('buat, ganti nama, dan hapus playlist', () async {
      final playlist = await repo.createPlaylist('  Malam  ');
      expect(playlist.name, 'Malam', reason: 'Nama harus di-trim.');

      await repo.renamePlaylist(playlist.id, 'Pagi');
      expect((await repo.playlists()).single.name, 'Pagi');

      await repo.deletePlaylist(playlist.id);
      expect(await repo.playlists(), isEmpty);
    });

    test('lagu disimpan di dalam playlist, bukan hanya namanya', () async {
      final playlist = await repo.createPlaylist('Koleksi');
      await repo.addTrackToPlaylist(playlist.id, _t('1'));
      await repo.addTrackToPlaylist(playlist.id, _t('2'));
      await repo.addTrackToPlaylist(playlist.id, _t('1'));

      final saved = (await repo.playlists()).single;
      expect(saved.tracks.map((Track t) => t.id), <String>['1', '2'],
          reason: 'Track ganda tidak boleh masuk dua kali.');
      expect(saved.tracks.first.audioUrl, 'https://s.test/1.mp3',
          reason: 'Data track harus lengkap agar bisa diputar lagi.');
    });

    test('hapus track dari playlist', () async {
      final playlist = await repo.createPlaylist('Koleksi');
      await repo.addTrackToPlaylist(playlist.id, _t('1'));
      await repo.addTrackToPlaylist(playlist.id, _t('2'));
      await repo.removeTrackFromPlaylist(playlist.id, '1');

      expect((await repo.playlists()).single.tracks.map((Track t) => t.id), <String>['2']);
    });

    test('nama kosong dan terlalu panjang ditolak', () async {
      await expectLater(repo.createPlaylist('   '), throwsArgumentError);
      await expectLater(
        repo.createPlaylist('x' * (LibraryRepository.maxPlaylistNameLength + 1)),
        throwsArgumentError,
      );
    });

    test('data tersimpan yang rusak dianggap kosong, bukan crash', () async {
      final InMemoryKeyValueStore store = InMemoryKeyValueStore();
      await store.write('library.playlists.v1', '{ini bukan list}');
      await store.write('library.favorites.v1', '[{"id":""}]');
      final LibraryRepository broken = LibraryRepository(store);

      expect(await broken.playlists(), isEmpty);
      expect(await broken.favorites(), isEmpty);
    });
  });

  group('PlaybackQueue', () {
    test('next, previous, dan batas awal/akhir', () {
      final PlaybackQueue q = PlaybackQueue()..setQueue(<Track>[_t('1'), _t('2')]);
      expect(q.current?.id, '1');
      expect(q.hasPrevious, isFalse);
      expect(q.next()?.id, '2');
      expect(q.next(), isNull);
      expect(q.previous()?.id, '1');
      expect(q.previous(), isNull);
    });

    test('removeAt menjaga indeks aktif tetap pada lagu yang sama', () {
      final PlaybackQueue q = PlaybackQueue()
        ..setQueue(<Track>[_t('1'), _t('2'), _t('3')], startIndex: 2);
      q.removeAt(0);
      expect(q.current?.id, '3');
      expect(q.index, 1);
    });

    test('removeAt pada lagu aktif memilih lagu berikutnya', () {
      final PlaybackQueue q = PlaybackQueue()
        ..setQueue(<Track>[_t('1'), _t('2'), _t('3')], startIndex: 1);
      q.removeAt(1);
      expect(q.current?.id, '3');
    });

    test('removeAt pada lagu terakhir yang aktif memilih lagu sebelumnya', () {
      final PlaybackQueue q = PlaybackQueue()
        ..setQueue(<Track>[_t('1'), _t('2')], startIndex: 1);
      q.removeAt(1);
      expect(q.current?.id, '1');
    });

    test('menghapus semua lagu mengosongkan current', () {
      final PlaybackQueue q = PlaybackQueue()..setQueue(<Track>[_t('1')]);
      q.removeAt(0);
      expect(q.isEmpty, isTrue);
      expect(q.current, isNull);
    });

    test('jumpTo indeks di luar batas diabaikan', () {
      final PlaybackQueue q = PlaybackQueue()..setQueue(<Track>[_t('1'), _t('2')]);
      expect(q.jumpTo(5), isNull);
      expect(q.current?.id, '1');
    });
  });

  group('DownloadRepository', () {
    test('entri yang file-nya sudah hilang dibersihkan dari daftar', () async {
      final Directory dir = await Directory.systemTemp.createTemp('rilz_dl_test');
      addTearDown(() => dir.delete(recursive: true));

      final InMemoryKeyValueStore store = InMemoryKeyValueStore();
      final DownloadService service =
          DownloadService(baseDirectory: () async => dir);
      final DownloadRepository repo = DownloadRepository(store, service);

      final File real = File('${dir.path}/ada.mp3')..writeAsBytesSync(<int>[1, 2, 3]);
      await repo.add(DownloadedTrack(
        track: _t('1'),
        filePath: real.path,
        sizeBytes: 3,
        completedAt: DateTime(2026),
      ));
      await repo.add(DownloadedTrack(
        track: _t('2'),
        filePath: '${dir.path}/hilang.mp3',
        sizeBytes: 0,
        completedAt: DateTime(2026),
      ));

      final List<DownloadedTrack> listed = await repo.list();
      expect(listed.map((DownloadedTrack d) => d.track.id), <String>['1']);
      expect(await repo.localPathFor(_t('1')), real.path);
      expect(await repo.localPathFor(_t('2')), isNull);
    });

    test('remove menghapus file dari disk dan dari indeks', () async {
      final Directory dir = await Directory.systemTemp.createTemp('rilz_dl_remove');
      addTearDown(() => dir.delete(recursive: true));

      final DownloadService service =
          DownloadService(baseDirectory: () async => dir);
      final DownloadRepository repo =
          DownloadRepository(InMemoryKeyValueStore(), service);
      final File file = File('${dir.path}/x.mp3')..writeAsBytesSync(<int>[9]);
      await repo.add(DownloadedTrack(
        track: _t('x'),
        filePath: file.path,
        sizeBytes: 1,
        completedAt: DateTime(2026),
      ));

      await repo.remove('x');

      expect(file.existsSync(), isFalse);
      expect(await repo.list(), isEmpty);
    });
  });

  group('DownloadService', () {
    test('track yang tidak mengizinkan unduhan ditolak tanpa request apa pun', () async {
      final Directory dir = await Directory.systemTemp.createTemp('rilz_dl_guard');
      addTearDown(() => dir.delete(recursive: true));
      final DownloadService service =
          DownloadService(baseDirectory: () async => dir);

      await expectLater(
        service.download(_t('1')),
        throwsA(isA<DownloadException>()
            .having((DownloadException e) => e.message, 'message', contains('tidak mengizinkan'))),
      );
      expect(dir.listSync(), isEmpty);
    });
  });
}
