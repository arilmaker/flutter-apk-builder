import 'package:flutter_test/flutter_test.dart';
import 'package:rilzmusic/data/models/track.dart';
import 'package:rilzmusic/services/audio/audio_engine.dart';
import 'package:rilzmusic/services/audio/player_controller.dart';

import 'support/fake_audio_engine.dart';

Track _track(String id, {String? url = 'https://example.test/a'}) => Track(
      id: id,
      name: 'Lagu $id',
      artistName: 'Artis',
      durationSeconds: 180,
      audioUrl: url == null ? null : '$url$id.mp3',
    );

void main() {
  late FakeAudioEngine engine;
  late List<String> started;
  late PlayerController player;

  setUp(() {
    engine = FakeAudioEngine();
    started = <String>[];
    player = PlayerController(
      engine: engine,
      resolveSource: (Track t) async =>
          t.audioUrl == null ? null : PlaybackSource.remote(t.audioUrl!),
      onTrackStarted: (Track t) => started.add(t.id),
    );
  });

  tearDown(() {
    player.dispose();
  });

  test('playQueue memuat URL track pertama dan mencatat riwayat', () async {
    await player.playQueue(<Track>[_track('1'), _track('2')]);

    expect(player.currentTrack?.id, '1');
    expect(engine.loadedUrls, <String>['https://example.test/a1.mp3']);
    expect(engine.playCalls, 1);
    expect(started, <String>['1']);
    expect(player.errorMessage, isNull);
    expect(player.duration, const Duration(seconds: 180));
  });

  test('next dan previous berpindah lagu dan memuat URL yang benar', () async {
    await player.playQueue(<Track>[_track('1'), _track('2'), _track('3')]);

    await player.next();
    expect(player.currentTrack?.id, '2');
    expect(engine.loadedUrls.last, 'https://example.test/a2.mp3');

    // Posisi di bawah 3 detik: previous berpindah ke lagu sebelumnya.
    await player.previous();
    expect(player.currentTrack?.id, '1');
    expect(engine.loadedUrls.last, 'https://example.test/a1.mp3');
  });

  test('previous saat posisi sudah lewat 3 detik hanya mengulang lagu', () async {
    await player.playQueue(<Track>[_track('1'), _track('2')]);
    await player.next();
    engine.emitPosition(const Duration(seconds: 10));
    await pumpEvents();

    await player.previous();

    expect(player.currentTrack?.id, '2');
    expect(engine.lastSeek, Duration.zero);
  });

  test('next di akhir antrean tidak melakukan apa-apa', () async {
    await player.playQueue(<Track>[_track('1')]);
    await player.next();
    expect(player.currentTrack?.id, '1');
    expect(player.hasNext, isFalse);
    expect(engine.loadedUrls.length, 1);
  });

  test('track tanpa URL menghasilkan pesan error, bukan crash', () async {
    await player.playQueue(<Track>[_track('x', url: null)]);

    expect(player.errorMessage, contains('tidak menyediakan audio'));
    expect(engine.playCalls, 0);
    expect(player.isPlaying, isFalse);
  });

  test('URL gagal dimuat menghasilkan errorMessage dan status tidak playing', () async {
    engine.loadError = StateError('Gagal memuat audio (404): not found');
    await player.playQueue(<Track>[_track('1')]);

    expect(player.errorMessage, contains('Gagal memuat audio'));
    expect(player.isPlaying, isFalse);
  });

  test('error dari stream engine tercermin di state player', () async {
    await player.playQueue(<Track>[_track('1')]);
    engine.emitError('Pemutaran gagal (network). Coba putar ulang.');
    await pumpEvents();

    expect(player.errorMessage, contains('Pemutaran gagal'));
    expect(player.isPlaying, isFalse);
  });

  test('status completed memutar lagu berikutnya otomatis', () async {
    await player.playQueue(<Track>[_track('1'), _track('2')]);
    engine.emitStatus(EngineStatus.completed);
    await pumpEvents();
    await pumpEvents();

    expect(player.currentTrack?.id, '2');
    expect(engine.loadedUrls.last, 'https://example.test/a2.mp3');
  });

  test('status buffering terbaca oleh UI', () async {
    await player.playQueue(<Track>[_track('1')]);
    engine.emitStatus(EngineStatus.buffering);
    await pumpEvents();
    expect(player.isBuffering, isTrue);

    engine.emitStatus(EngineStatus.ready);
    await pumpEvents();
    expect(player.isBuffering, isFalse);
  });

  test('togglePlayPause memanggil pause saat sedang playing', () async {
    await player.playQueue(<Track>[_track('1')]);
    engine.emitPlaying(true);
    await pumpEvents();

    await player.togglePlayPause();
    expect(engine.pauseCalls, 1);
  });

  test('removeFromQueue menghapus lagu yang sedang diputar lalu memuat berikutnya', () async {
    await player.playQueue(<Track>[_track('1'), _track('2'), _track('3')]);
    await player.removeFromQueue(0);

    expect(player.queue.map((Track t) => t.id), <String>['2', '3']);
    expect(player.currentTrack?.id, '2');
    expect(engine.loadedUrls.last, 'https://example.test/a2.mp3');
  });

  test('stop mengosongkan antrean dan menghentikan engine', () async {
    await player.playQueue(<Track>[_track('1')]);
    await player.stop();

    expect(player.hasQueue, isFalse);
    expect(player.currentTrack, isNull);
    expect(engine.stopCalls, 1);
  });

  test('dispose menutup engine dan tidak melempar error setelahnya', () async {
    await player.playQueue(<Track>[_track('1')]);
    player.dispose();
    await pumpEvents();

    expect(engine.disposed, isTrue);
    // Membuat ulang untuk tearDown agar dispose ganda tidak dipanggil.
    player = PlayerController(
      engine: FakeAudioEngine(),
      resolveSource: (Track t) async => null,
    );
  });
}
