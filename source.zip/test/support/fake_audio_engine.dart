import 'dart:async';

import 'package:rilzmusic/services/audio/audio_engine.dart';

/// Engine audio palsu untuk tes. Tidak menyentuh platform sama sekali.
class FakeAudioEngine implements AudioEngine {
  final StreamController<EngineStatus> _status =
      StreamController<EngineStatus>.broadcast();
  final StreamController<bool> _playing = StreamController<bool>.broadcast();
  final StreamController<Duration> _position =
      StreamController<Duration>.broadcast();
  final StreamController<Duration?> _duration =
      StreamController<Duration?>.broadcast();
  final StreamController<String> _errors = StreamController<String>.broadcast();

  final List<String> loadedUrls = <String>[];
  final List<String> loadedFiles = <String>[];
  int playCalls = 0;
  int pauseCalls = 0;
  int stopCalls = 0;
  Duration? lastSeek;
  bool disposed = false;

  /// Durasi yang dikembalikan saat load berhasil.
  Duration? loadResult = const Duration(seconds: 180);

  /// Bila diisi, load akan melempar error ini.
  Object? loadError;

  @override
  Stream<EngineStatus> get status => _status.stream;
  @override
  Stream<bool> get playing => _playing.stream;
  @override
  Stream<Duration> get position => _position.stream;
  @override
  Stream<Duration?> get duration => _duration.stream;
  @override
  Stream<String> get errors => _errors.stream;

  @override
  Future<Duration?> loadUrl(String url) async {
    loadedUrls.add(url);
    if (loadError != null) throw loadError!;
    return loadResult;
  }

  @override
  Future<Duration?> loadFile(String path) async {
    loadedFiles.add(path);
    if (loadError != null) throw loadError!;
    return loadResult;
  }

  @override
  Future<void> play() async => playCalls++;

  @override
  Future<void> pause() async => pauseCalls++;

  @override
  Future<void> seek(Duration position) async => lastSeek = position;

  @override
  Future<void> stop() async => stopCalls++;

  @override
  Future<void> dispose() async {
    disposed = true;
    await _status.close();
    await _playing.close();
    await _position.close();
    await _duration.close();
    await _errors.close();
  }

  // Helper untuk men-simulasikan kejadian dari engine.
  void emitStatus(EngineStatus value) => _status.add(value);
  void emitPlaying(bool value) => _playing.add(value);
  void emitPosition(Duration value) => _position.add(value);
  void emitError(String message) => _errors.add(message);
}

/// Memberi kesempatan event stream diproses.
Future<void> pumpEvents() => Future<void>.delayed(Duration.zero);
