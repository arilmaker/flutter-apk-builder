import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:rilzmusic/data/models/track.dart';
import 'package:rilzmusic/services/api/jamendo_response_parser.dart';
import 'package:rilzmusic/services/api/music_api_exception.dart';
import 'package:rilzmusic/shared/widgets/track_tile.dart';

Map<String, dynamic> _apiTrack({String id = '101', String name = 'Senja'}) => <String, dynamic>{
      'id': id,
      'name': name,
      'duration': 215,
      'artist_name': 'Artis Satu',
      'artist_id': '7',
      'album_name': 'Album Satu',
      'image': 'https://img.example.test/300.jpg',
      'album_image': 'https://img.example.test/album.jpg',
      'audio': 'https://stream.example.test/101.mp3',
      'audiodownload': 'https://dl.example.test/101.mp3',
      'audiodownload_allowed': true,
    };

String _envelope(List<dynamic> results, {String status = 'success', String error = ''}) =>
    jsonEncode(<String, dynamic>{
      'headers': <String, dynamic>{
        'status': status,
        'code': status == 'success' ? 0 : 2000,
        'error_message': error,
        'results_count': results.length,
      },
      'results': results,
    });

void main() {
  group('Track.fromJson', () {
    test('membaca semua field dari respons API', () {
      final Track t = Track.fromJson(_apiTrack());

      expect(t.id, '101');
      expect(t.name, 'Senja');
      expect(t.artistName, 'Artis Satu');
      expect(t.artistId, '7');
      expect(t.durationSeconds, 215);
      expect(t.artworkUrl, 'https://img.example.test/album.jpg');
      expect(t.audioUrl, 'https://stream.example.test/101.mp3');
      expect(t.canDownload, isTrue);
    });

    test('download nonaktif bila audiodownload_allowed bukan true', () {
      final Map<String, dynamic> json = _apiTrack()..['audiodownload_allowed'] = false;
      expect(Track.fromJson(json).canDownload, isFalse);
    });

    test('download nonaktif bila URL unduhan kosong meski diizinkan', () {
      final Map<String, dynamic> json = _apiTrack()..['audiodownload'] = '';
      expect(Track.fromJson(json).canDownload, isFalse);
    });

    test('melempar FormatException bila id atau name kosong', () {
      expect(() => Track.fromJson(_apiTrack(id: '')), throwsFormatException);
      expect(() => Track.fromJson(_apiTrack(name: '   ')), throwsFormatException);
    });

    test('field opsional kosong tidak membuat parsing gagal', () {
      final Track t = Track.fromJson(<String, dynamic>{'id': 1, 'name': 'X'});
      expect(t.id, '1');
      expect(t.artistName, 'Artis tidak diketahui');
      expect(t.audioUrl, isNull);
      expect(t.canDownload, isFalse);
    });
  });

  group('Track storage roundtrip', () {
    test('toJson lalu fromStorageJson menghasilkan track yang sama', () {
      final Track original = Track.fromJson(_apiTrack());
      final Track restored = Track.fromStorageJson(original.toJson());

      expect(restored.id, original.id);
      expect(restored.name, original.name);
      expect(restored.audioUrl, original.audioUrl);
      expect(restored.downloadUrl, original.downloadUrl);
      expect(restored.downloadAllowed, original.downloadAllowed);
      expect(restored.durationSeconds, original.durationSeconds);
    });
  });

  group('formatDuration', () {
    test('format m:ss dan h:mm:ss', () {
      expect(formatDuration(const Duration(seconds: 215)), '3:35');
      expect(formatDuration(const Duration(seconds: 5)), '0:05');
      expect(formatDuration(const Duration(hours: 1, minutes: 2, seconds: 3)), '1:02:03');
      expect(formatDuration(Duration.zero), '');
    });
  });

  group('JamendoResponseParser', () {
    test('mengurai respons sukses dan menandai halaman berikutnya', () {
      final TrackPage page = JamendoResponseParser.parseTracks(
        _envelope(<dynamic>[_apiTrack(id: '1'), _apiTrack(id: '2')]),
        offset: 0,
        requestedLimit: 2,
      );

      expect(page.tracks.map((Track t) => t.id), <String>['1', '2']);
      expect(page.hasMore, isTrue);
    });

    test('hasMore false bila hasil kurang dari limit', () {
      final TrackPage page = JamendoResponseParser.parseTracks(
        _envelope(<dynamic>[_apiTrack()]),
        offset: 0,
        requestedLimit: 20,
      );
      expect(page.hasMore, isFalse);
    });

    test('melewati item yang rusak tanpa menggagalkan halaman', () {
      final TrackPage page = JamendoResponseParser.parseTracks(
        _envelope(<dynamic>[
          _apiTrack(id: '1'),
          <String, dynamic>{'name': 'tanpa id'},
          'bukan object',
          _apiTrack(id: '3'),
        ]),
        offset: 0,
        requestedLimit: 20,
      );
      expect(page.tracks.map((Track t) => t.id), <String>['1', '3']);
    });

    test('respons kosong berisi daftar kosong', () {
      final TrackPage page = JamendoResponseParser.parseTracks(
        _envelope(<dynamic>[]),
        offset: 0,
        requestedLimit: 20,
      );
      expect(page.tracks, isEmpty);
      expect(page.hasMore, isFalse);
    });

    test('status error dari API menjadi MusicApiException dengan pesan', () {
      expect(
        () => JamendoResponseParser.parseTracks(
          _envelope(<dynamic>[], status: 'error', error: 'invalid client_id'),
          offset: 0,
          requestedLimit: 20,
        ),
        throwsA(isA<MusicApiException>().having(
          (MusicApiException e) => e.message,
          'message',
          contains('invalid client_id'),
        )),
      );
    });

    test('body kosong dan JSON rusak ditolak dengan pesan jelas', () {
      expect(
        () => JamendoResponseParser.parseTracks('', offset: 0, requestedLimit: 20),
        throwsA(isA<MusicApiException>()),
      );
      expect(
        () => JamendoResponseParser.parseTracks('{bukan json', offset: 0, requestedLimit: 20),
        throwsA(isA<MusicApiException>()),
      );
    });

    test('respons tanpa header atau results ditolak', () {
      expect(
        () => JamendoResponseParser.parseTracks('{"results":[]}', offset: 0, requestedLimit: 20),
        throwsA(isA<MusicApiException>()),
      );
      expect(
        () => JamendoResponseParser.parseTracks(
          '{"headers":{"status":"success"}}',
          offset: 0,
          requestedLimit: 20,
        ),
        throwsA(isA<MusicApiException>()),
      );
    });
  });
}
